import docker as dk
import sys

# client = Docker Engine similar to CLI docker
client = dk.from_env()

dict_port = {'80/tcp': int(sys.argv[2])}

logContainer = client.containers.run(
"serverapp",
name=sys.argv[1],
detach=True,
auto_remove=True,
ports=dict_port )
