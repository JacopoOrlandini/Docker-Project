import docker
# import datetime
import os

cmd = "docker ps -q | xargs  docker stats --no-stream"
returned_value = os.system(cmd)  # returns the exit code in unix


# client = docker.from_env()
# d = {"status":"running"}
# containers = client.containers.list(filters=d)
# for c in containers:
#     metric = c.stats(stream=False)
#     print metric
#     # delta_total_usage = (float(metric["cpu_stats"]["cpu_usage"]["total_usage"]) - float(metric["precpu_stats"]["cpu_usage"]["total_usage"])) / float((metric["precpu_stats"]["cpu_usage"]["total_usage"]))
#     # delta_system_usage = (float(metric["cpu_stats"]["system_cpu_usage"]) - float(metric["precpu_stats"]["system_cpu_usage"]))/float(metric["precpu_stats"]["system_cpu_usage"])
#     # y = float(delta_total_usage / delta_system_usage)

    
