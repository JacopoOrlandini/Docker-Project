import docker
import random

# Get Engines 
client = docker.from_env()
lCl = docker.APIClient(base_url='unix://var/run/docker.sock')

containers = client.containers.list()
rand = random.randint(0, len(containers)-1)
# Stoppo un container casuale nella lista
containers[rand].stop()
lCl.kill(containers[rand].remove())



