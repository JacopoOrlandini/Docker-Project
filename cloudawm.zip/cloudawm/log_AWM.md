# PROJECT CLOUD AWM

Starting Point :  __AutonomicWorkloadManager__

```
public static void main( String[] args ) throws InterruptedException

  inputParameters()  
  start ResourceManager()
  start RequestHandler()
  start Dispatcher()
  start ResponseHandler()
  start SpeedUpServer()
  start ServiceBroker()
  start CheckUpServer()
  start ConsoleListener()
```


__pythonResourceManager__

I servizi all'interno del resource manager devono essere fittizzi non devono realmente funzionare.

Per costruire una docker image per serverdummy con i file di configurazione sul sito get-started di docker.
* pulisco tutte le immagine con il comando ```docker image rm $(docker image ls -a -q) -f```
* costruisco l'image che andremo ad utilizzare per il container con
docker build -t serverdummy . Attenzione non omettere il punto
Al termine vengono create 2 image una per python2.7-slim, e un image denominata serverdummy.
```
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
serverdummy         latest              dd886eec8625        24 seconds ago      155MB
python              2.7-slim            8559620b5b0d        2 days ago          120MB
```
* per controllare se la port è in utilizzo usare: lsof -i :<IDport>

```
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS                  NAMES
eb4f4ecc8033        serverdummy         "python app.py"     12 seconds ago      Up 11 seconds       0.0.0.0:4100->80/tcp   nifty_perlman
```

* per killare un container se da errore di autorizzazione usare sudo mode.

# Costruzione Virtual Machine docker
nota: Docker non mi permette di creare o rimuovere virtual machine agilmente come Openstack ma permette la costruzione di container in cui far girare l'applicazione. Quindi posso manualmente da CLI allocare diverse macchine virtuali fittizie sul local pc per poi su ognuna di esse creare o rimuovere in base alle esigenze i container.

 * per vedere le macchine virtuali attive al momento sul pc usare :
	$ docker-machine ls

 * per costruire una macchina virtuale uso docker-machine (per far funzionare questo comando devo aver installato virtualbox)
	$ docker-machine create --driver virtualbox <nome_macchina>

* docker-machine create --driver virtualbox myvm1 # Create a VM (Mac, Win7, Linux)
* docker-machine create -d hyperv --hyperv-virtual-switch "myswitch" myvm1 # Win10
* docker-machine env myvm1                # View basic information about your node
* docker-machine ssh myvm1 "docker node ls"         # List the nodes in your swarm
* docker-machine ssh myvm1 "docker node inspect <node ID>"        # Inspect a node
* docker-machine ssh myvm1 "docker swarm join-token -q worker"   # View join token
* docker-machine ssh myvm1   # Open an SSH session with the VM; type "exit" to end
* docker node ls                # View nodes in swarm (while logged on to manager)
* docker-machine ssh myvm2 "docker swarm leave"  # Make the worker leave the swarm
* docker-machine ssh myvm1 "docker swarm leave -f" # Make master leave, kill swarm
* docker-machine ls # list VMs, asterisk shows which VM this shell is talking to
* docker-machine start myvm1            # Start a VM that is currently not running
* docker-machine env myvm1      # show environment variables and command for myvm1
* eval $(docker-machine env myvm1)         # Mac command to connect shell to myvm1
* & "C:\Program Files\Docker\Docker\Resources\bin\docker-machine.exe" env myvm1 | Invoke-* Expression   # Windows command to connect shell to myvm1
* docker stack deploy -c <file> <app>  # Deploy an app; command shell must be set to talk * to manager (myvm1), uses local Compose file
* docker-machine scp docker-compose.yml myvm1:~ # Copy file to node's home dir (only * required if you use ssh to connect to manager and deploy the app)
* docker-machine ssh myvm1 "docker stack deploy -c <file> <app>"   # Deploy an app using * ssh (you must have first copied the Compose file to myvm1)
* eval $(docker-machine env -u)     # Disconnect shell from VMs, use native docker
* docker-machine stop $(docker-machine ls -q)               # Stop all running VMs
* docker-machine rm $(docker-machine ls -q) # Delete all VMs and their dis* k

# Avvio ServerApp
Attenzione che fino a quando il processo avviato sulla classe JavaRunCommand non finisce di eseguire, non viene printato nulla a console.
Il container su cui gira il server tuttavia viene creato e quindi accessibile.
Come si accede al server creato con docker?

* Accedo al server appena creato attraverso uno script python chiamato client.py. Il funzionamento è semplice, aspetta che si crei il container che fa girare il server, quando riesce a fare la chiamata restituisce il codice html.

* Per list tutti i container :  docker container ls -a
* per kill usare python killContainer.py
* Per eliminare tutti i container stopped : docker container prune
Facoltativo
* Per fermare un container : docker container stop id
* Per vedere log di usage usare : docker ps -q | xargs  docker stats --no-stream


Si usa il controller francisController.
