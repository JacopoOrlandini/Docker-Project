package it.unipr.dsg.matrix;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import Jama.EigenvalueDecomposition;
import Jama.Matrix;
import it.unipr.dsg.log.DataCollector;

/**
 * Static class containing some utils for using Matrixes in Java.
 * It is based on the <a href="http://math.nist.gov/javanumerics/jama/">JAMA</a> library.
 * 
 * @author Valter Venusti - December 2015
 */
public class DsgMatrixUtils {

	private static String debug = "DSG MATRIX UTILS - ";
	
	private static DataCollector dataColl = DataCollector.getInstance();
		
    /**
     * Bring two matrixes (m1 and m2) and put the first over the second in a new matrix of
     * dimension (m1.row + m2.row) &times m1.col 
     *
     * @param m1 the first matrix
     * @param m2 the second matrix
     * @throws IllegalArgumentException if the two matrixes have a different number of columns
     * @return A new matrix of the form M = [m1; m2] (MATLAB syntax)
     */
	public static Matrix Vstack(Matrix m1, Matrix m2) throws IllegalArgumentException{
	
		if(m1.getColumnDimension() != m2.getColumnDimension()){
			throw new IllegalArgumentException("Vstack: le due matrici devono avere lo stesso numero di colonne " +
					"(m1.col = "+m1.getColumnDimension()+" - m2.col = "+m2.getColumnDimension()+")");
		}
			
		
		Matrix m3 = new Matrix(m1.getRowDimension()+m2.getRowDimension(), m1.getColumnDimension());
		
		for(int i = 0; i < m1.getRowDimension(); i++){
			for(int j = 0; j < m1.getColumnDimension(); j++){
				
				m3.set(i, j, m1.get(i, j));
			}
		}
		for(int i = 0; i < m2.getRowDimension(); i++){
			for(int j = 0; j < m2.getColumnDimension(); j++){
				
				m3.set(i+m1.getRowDimension(), j, m2.get(i, j));
			}
		}
		
		return m3;
	}
	
    /**
     * Bring two matrixes (m1 and m2) and put the first next to the second in a new matrix of
     * dimension m1.row &times (m1.col + m2.col)
     *
     * @param m1 the first matrix
     * @param m2 the second matrix
     * @throws IllegalArgumentException if the two matrixes have a different number of rows
     * @return A new matrix of the form M = [m1 m2] (MATLAB syntax)
     */
	public static Matrix Hstack(Matrix m1, Matrix m2){
		
		if(m1.getRowDimension() != m2.getRowDimension()){
			throw new IllegalArgumentException("Hstack: le due matrici devono avere lo stesso numero di righe " +
					"(m1.row = "+m1.getRowDimension()+" - m2.row = "+m2.getRowDimension()+")");
		}
			
		
		Matrix m3 = new Matrix(m1.getRowDimension(), m1.getColumnDimension()+m2.getColumnDimension());
		
		for(int i = 0; i < m1.getRowDimension(); i++){
			for(int j = 0; j < m1.getColumnDimension(); j++){
				
				m3.set(i, j, m1.get(i, j));
			}
		}
		for(int i = 0; i < m2.getRowDimension(); i++){
			for(int j = 0; j < m2.getColumnDimension(); j++){
				
				m3.set(i, j+m1.getColumnDimension(), m2.get(i, j));
			}
		}
		
		return m3;
	}
	
    /**
     * Method for calculating the optimal control through the resolution of the Riccati equation.<br>
     * The method used for the resolution of the Riccati equation is the Laub's method exposed in the article
     * "A Schur method for solving Algebraic Riccati Equation".<br>
     * For the Hessenberg decomposition and the reduction the the Real Schur Form (RSF) has been used the 
     * <a href="http://math.nist.gov/javanumerics/jama/">JAMA</a> library.<br>
     * <br>
     * The system is of the form x(k+1) = A*x(k)+B*u(k)<br><br>
     * The optimal control is u(k) = -K*x(k) where K = ((B<sup>T</sup>*P*B + R)<sup>-1</sup>)*(B<sup>T</sup>*P*A)<br><br>
     * P is the solution of the Discrete Algebraic Riccati Equation (DARE):<br>
     * A<sup>T</sup>*P*A - P - A<sup>T</sup>*P*B*(B<sup>T</sup>*P*B + R)<sup>-1</sup>*B<sup>T</sup>*P*A + Q = 0<br><br>
     * The cost function is:<br>
     * J = sum(from i = 0 to infinite)(x<sub>i</sub>*Q*x<sub>i</sub><sup>T</sup> + u<sub>i</sub>*R*u<sub>i</sub><sup>T</sup>)
     * 
     *
     * @param A the state matrix
     * @param B the input matrix
     * @param Q the state cost matrix
     * @param R the input cost matrix
     * @return A map containing three elements: the K matrix, the P matrix, the eigenvalues of the feedback matrix (A-B*K)<br><br>
     * Map.get("K") for K matrix<br>
     * Map.get("P") for P matrix<br>
     * Map.get("eigsReal") for the real parts of the eigenvalues<br>
     * Map.get("eigsImag") for the imaginary parts of the eigenvalues
     * 
     * @see <a href='https://github.com/scipy/scipy/blob/v0.14.0/scipy/linalg/_solvers.py#L215'>Python Riccati Implementation</a>
     * @see <a href='http://ieeexplore.ieee.org/xpls/abs_all.jsp?arnumber=1102178&tag=1'>Laub's work</a>
     * @see <a href='http://www.math.usm.edu/lambers/mat610/sum10/lecture15.pdf'>Eigenvalue problem</a>
     */
	public static Map<String, Matrix> dlqr(Matrix A, Matrix B, Matrix Q, Matrix R) {
		
		Map<String, Matrix> returnMap = null;
		
		try{
			
			Matrix G = B.times(R.inverse()).times(B.transpose());
			
			//Discrete time Z matrix
			Matrix Z11 = A.inverse();
			//Z11.print(10, 5);
			Matrix Z12 = A.inverse().times(G);
			Matrix Z21 = Q.times(A.inverse());
			Matrix Z22 = A.transpose().plus(Q.times(A.inverse().times(G)));
			
			Matrix Z = Vstack(Hstack(Z11,Z12),Hstack(Z21,Z22));
			
			//System.out.println("pippo");
			//Z.inverse().print(10, 5);
			
			EigenvalueDecomposition RSF = Z.eig();
			Matrix U = RSF.getV();
			
			//U.print(10,  5);
			
			int m = U.getRowDimension();
			int n = U.getColumnDimension();
			
			int halfRowInt = m/2;
			int halfColumnInt = n/2;
			
			Matrix u11 = new Matrix(halfRowInt, halfColumnInt);
			for(int i = 0; i < u11.getRowDimension(); i++){
				for(int j = 0; j < u11.getColumnDimension(); j++){
					
					u11.set(i, j, U.get(i, j));
				}
			}
			
			Matrix u21 = new Matrix(U.getRowDimension()-halfRowInt, halfColumnInt);
			int begin = halfRowInt;
			for(int i = 0; i < u21.getRowDimension(); i++){
				for(int j = 0; j < u21.getColumnDimension(); j++){
					
					u21.set(i, j, U.get(i+begin, j));
				}
			}
			
//			u11.print(10, 5);
//			u21.print(10, 5);
			
			Matrix P = u21.times(u11.inverse()); 
			Matrix K1 = (B.transpose().times(P).times(B).plus(R)).inverse();
			Matrix K2 = B.transpose().times(P).times(A);
			Matrix K = K1.times(K2);
			
			Matrix eigsReal = new Matrix(A.minus(B.times(K)).eig().getRealEigenvalues(), 1);
			Matrix eigsImag = new Matrix(A.minus(B.times(K)).eig().getImagEigenvalues(), 1);
			
			returnMap = new HashMap<String, Matrix>();
			returnMap.put("P", P);
			returnMap.put("K", K);
			returnMap.put("eigsReal", eigsReal);
			returnMap.put("eigsImag", eigsImag);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return returnMap;
	}
	
	/**
	 * Compute the new state of a system in which the feedback has been calculated with
	 * the resolution of the Francis equation (problem of Output Regulation).<br>
	 * The optimal control for a system in the form:<br><br>
	 * x(k+1) = A*x(k) + B*u(k) + P*w(k)<br>
	 * w(k+1) = S*w(k)<br>
	 * y(k) = C*x(k) + D*w(k)<br>
	 * <br>
	 * is u(k) = -K(x(k) - Pigreco*w(k)) + Lambda*w(k)<br>
	 * <br>
	 * where Pigreco and Lambda satisfies:<br><br>
	 * C*Pigreco + D = 0<br>
	 * Pigreco*S = A*Pigreco + B*Lambda + P
	 * <br><br>
	 * The controlled system is:<br><br>
	 * x(k+1) = (A-B*K)*x(k) + (B*K*Pigreco + B*Lambda+ P)*w(k)
	 * 
	 * @param A - The system matrix
	 * @param B - The input matrix
	 * @param K - The gain matrix
	 * @param oldState - The current state of the system
	 * @param newRequests - The number of requests assumed to arrive in the next sampling time
	 * @param Francis_PiGreco - The Pigreco matrix of Francis Equations
	 * @param Francis_Lambda - The Lambda matrix of Francis Equations
	 * @param Francis_P_Esosystem - The P matrix of the system
	 * @return the gain matrix K
	 */
	public static Matrix francisRegulatorFeedback(Matrix A, Matrix B, Matrix K, Matrix oldState, Matrix newRequests,
			Matrix Francis_PiGreco, Matrix Francis_Lambda, Matrix Francis_P_Esosystem){
		
		Matrix newState = null;
		
		try{
			
			Matrix feedbackOnState = ((A.minus(B.times(K))).times(oldState));
			Matrix BKPigreco = B.times(K).times(Francis_PiGreco);
			Matrix BLambda = B.times(Francis_Lambda);
			Matrix Sum = BKPigreco.plus(BLambda).plus(Francis_P_Esosystem);
			Matrix feedbackOnInput = Sum.times(newRequests);
			newState = feedbackOnState.plus(feedbackOnInput);
			
		}catch(Exception e){ e.printStackTrace(); }
		
		return newState;
	}

	/**
     * Method for calculating the optimal control through the resolution of the Riccati equation.<br>
     * The method used for the resolution of the Riccati equation is the Laub's method exposed in the article
     * "A Schur method for solving Algebraic Riccati Equation".<br>
	 * For the resolution this method calls a python script that returns the gain matrix K.<br>
     * <br>
     * The system is of the form x(k+1) = A*x(k)+B*u(k)<br><br>
     * The optimal control is u(k) = -K*x(k) where K = ((B<sup>T</sup>*P*B + R)<sup>-1</sup>)*(B<sup>T</sup>*P*A)<br><br>
     * P is the solution of the Discrete Algebraic Riccati Equation (DARE):<br>
     * A<sup>T</sup>*P*A - P - A<sup>T</sup>*P*B*(B<sup>T</sup>*P*B + R)<sup>-1</sup>*B<sup>T</sup>*P*A + Q = 0<br><br>
     * The cost function is:<br>
     * J = sum(from i = 0 to infinite)(x<sub>i</sub>*Q*x<sub>i</sub><sup>T</sup> + u<sub>i</sub>*R*u<sub>i</sub><sup>T</sup>)
     *
	 * @param T - the sampling time in seconds (e.g. T=300 means a sampling time of 300 seconds)
	 * @param Te - the execution time of a task in the cloud
	 * @param alpha - weight associated to an active Virtual Machine in the system
	 * @param beta - weight associated to a request not yet served
	 * @param gamma - weight associated to the allocation or deallocation of a new Virtual Machine
	 * @param delta - weight associated to the number of physical active servers
	 * @param M - max number of Virtual Machine for server
	 * @return The gain matrix K.
	 * @see CloudSystem class
	 */
	public static Matrix dlqrPython(double T, double Te, double alpha, double beta, double gamma, 
			double delta, double M) {
		
		String s = null;
		Matrix K = null;
		
		try {
			
			if(Te == 0){
				printDebug(debug + "Te is null. Set Te to 0.001...");
				Te = 0.001;
			}
			String command = "python riccati_solver.py " + T + " " + Te + " " +
					alpha + " " + beta + " " + gamma + " " + delta + " " + M;
			printDebug(debug + "Launching " + command);
			Process p = Runtime.getRuntime().exec(command);
            
			BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(p.getInputStream()));
    
           BufferedReader stdError = new BufferedReader(new
                InputStreamReader(p.getErrorStream()));
           
           if((s = stdError.readLine()) != null){
        	   debug(command + "\n\n\n" + s);
        	   return null;
           }

           // read the output from the command
           double[][] P = new double[1][2];
           int counter = 0;
           while ((s = stdInput.readLine()) != null) {
        	   String trimmed = s.trim();
        	   P[0][counter] = Double.parseDouble(trimmed);
        	   counter++;
           }
    	   K = new Matrix(P);
            
//           // read any errors from the attempted command
//           while ((s = stdError.readLine()) != null) {
//               System.out.println(s);
//           }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return K;
	}
	
	
	private static void debug(String s){
		
		try {
			File file = new File("/opt/FrancisError/francisError"+new Date().getTime()+".log");
			PrintWriter writer = new PrintWriter(file);
						
			writer.println(s);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) { 
			System.err.println(debug + "Path Not Found!!");
			e.printStackTrace();
		}
	}
	
	private static void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}
	
}
