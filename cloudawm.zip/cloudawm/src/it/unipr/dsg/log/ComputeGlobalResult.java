package it.unipr.dsg.log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

public class ComputeGlobalResult {

	/** SINGLETON STUFF **/
	private static ComputeGlobalResult instance = null;

	private ComputeGlobalResult() {}
	
	public static synchronized ComputeGlobalResult getInstance() {
		if(instance == null)
			instance = new ComputeGlobalResult();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/
	
	/** STRING PATH **/
	private static String clusterDataPath = "/home/SdE/GraphData/";
	
	private static String vmPath = "vmGraphTime";
	private static String speedUpPath = "speedUpGraphTime";
	private static String offloadingPath = "offloadingProbGraphTime";
	private static String timeOnCloudPath = "timeOnCloud";
	private static String otherInfoPath = "otherInfo";
	
	private static String dispatcherToVMPath = "dispatcherToVMCommTime";
	private static String dispatchingTimePath = "dispatchingTime";
	private static String VMToRespHandThreadPath = "VMToRespHandThreadCommTime";
	
	private static String phiValuePath = "phiValue";
	private static String elleValuePath = "elleValue";
	/** STRING PATH **/
	
	/** PUBLIC FUNCTIONS **/
	public void writeGlobalResultFiles(int howManyFiles) {
		System.out.println("WRITE_GLOBAL_RESULT: howManyFiles = " + howManyFiles);

		Vector<String> paths = new Vector<String>();
		paths.add(vmPath);
		paths.add(speedUpPath);
		paths.add(offloadingPath);
		paths.add(timeOnCloudPath);
		paths.add(otherInfoPath);
		
		paths.add(dispatcherToVMPath);
		paths.add(dispatchingTimePath);
		paths.add(VMToRespHandThreadPath);
		
		paths.add(phiValuePath);
		paths.add(elleValuePath);
		
		for(String s : paths){
			System.out.println("Collect data for " + s + " Files..");
			Vector< Vector<Double> > graphData = new Vector< Vector<Double> >();
			for(int i=0; i<howManyFiles; i++) {
				String path = clusterDataPath + s + "_" + (i+1) + ".txt";
				graphData.add(collectDataFromFile(path));
			}
			
			System.out.println("Compute Data for " + s + " Files...");
			Vector<Double> vmAvg = computeAvg(graphData);
			Vector<Double> vmStdDev = computeStdDev(graphData, vmAvg);
			
			System.out.println("Write AVG and STD-DEV on new File...");
			writeDataToFile(vmAvg, vmStdDev, s);
		}
		System.out.println("----- END -----");
	}
	/** PUBLIC FUNCTIONS **/
	
	/** PRIVATE FUNCTIONS **/
	private static Vector<Double> collectDataFromFile(String filePath) {
		Vector<Double> vector = new Vector<Double>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(filePath));
			// Read and remove first line of file
			reader.readLine();
			String currentLine = "";
			while( (currentLine = reader.readLine()) != null ) {
				String[] stringData = currentLine.split("\\t");
				if( stringData.length >= 2 ) {
//					System.out.println("stringData[] size = " + stringData.length);
//					for(int i=0; i<stringData.length; i++)
//						System.out.println("stringData[" + i + "] = " + stringData[i]);
					vector.add(Double.parseDouble(stringData[1]));
				}
			}
			reader.close();
		} catch (IOException e) { e.printStackTrace(); }
		return vector;
	}
	
	private static Vector<Double> computeAvg(Vector< Vector<Double> > allData) {
		Vector<Double> vector = new Vector<Double>();
		for(int i=0; i<allData.get(0).size(); i++) {
			double sum = 0;
			for(Vector<Double> v : allData) sum += v.get(i);
			double avg = sum / (double) allData.size();
			vector.add(avg);
		}
		return vector;
	}
	
	private static Vector<Double> computeStdDev(Vector< Vector<Double> > allData, Vector<Double> avg) {
		Vector<Double> vector = new Vector<Double>();
		for(int i=0; i<allData.get(0).size(); i++) {
			double sum = 0;
			for(Vector<Double> v : allData)  sum += Math.pow( (v.get(i) - avg.get(i)), 2);
			double stdDev = Math.sqrt( sum / (double) allData.size() );
			vector.add(stdDev);
		}
		return vector;
	}
	
	private static void writeDataToFile(Vector<Double> avg, Vector<Double> stdDev, String path) {
		try {
			File file = new File(clusterDataPath + path + "_final.txt");
			PrintWriter writer = new PrintWriter(file);
			
			writer.println("#TIME\tAVG\tSTD_DEV");
			writer.flush();
			
			for(int i=0; i<avg.size(); i++) {
				writer.println( (i) + "\t" + avg.get(i) + "\t" + stdDev.get(i) );
				writer.flush();
			}
			writer.close();
		} catch (FileNotFoundException e) { e.printStackTrace(); }
	}
	/** PRIVATE FUNCTIONS **/
}
