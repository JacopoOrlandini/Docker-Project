package it.unipr.dsg.log;

import it.unipr.dsg.awm.controller.QoSModeler;

/**
 * Class used to collect the parameters of the system.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @author modified by Fderico Torreggiani - 2017
 *
 */

public class TestParameters {
	/** SINGLETON STUFF **/
	private static TestParameters instance = null;

	private TestParameters() {
	}

	public static synchronized TestParameters getInstance() {
		if (instance == null)
			instance = new TestParameters();
		return instance;
	} // getInstance() {..}

	/** SINGLETON STUFF **/

	/** GLOBAL VARIABLES **/
	// For ResourceManager Thread
	private int minVM = 1;
	private int maxVM = 10;
	private int delta = 4;
	private int samplingPeriod = 5; // minutes
	// private double setPoint = 0.6;

	// For Riccati and Francis controllers
	private double alpha = 100;
	private double beta = 0.005;
	private double gamma = 5000;
	private double deltaR = 10000;
	private double M = 9;
	private double Te = 2;

	// For MPC controller
	private double alphaMPC = 1;
	private double betaMPC = 500;
	private double gammaMPC = 50;
	private double deltaMPC = 100;
	private double MMPC = 6;
	private double TeMPC = 2;

	private int futureFinitehorizon = 15;

	// For Threshold Controller
	private String openstackMetric;
	private double scaleUpThreshold;
	private double scaleDownThreshold;

	// For QuadThreshold Controller
	private double scaleUpPreThreshold;
	private double scaleDownPreThreshold;
	private double incrementPerc;
	private double decrementPerc;
	private int durationPeriodInIntervals;

	// For MoreThresholdController
	private double scaleUpThreshold_1;
	private double scaleUpThreshold_2;
	private double scaleUpThreshold_3;
	private double scaleDownThreshold_1;
	private double scaleDownThreshold_2;
	private double scaleDownThreshold_3;

	// For simulations
	private int howManySimulation = 0;

	public enum SimulationType {
		None, MobDev, HttpClient
	};

	private SimulationType simulation;

	public enum ControllerType {
		None, Integral, Francis, Threshold, QuadThreshold, MoreThresholdController, ModelPredictiveController
	};

	private ControllerType controller = ControllerType.Integral;

	/** GLOBAL VARIABLES **/

	/** GETTING FUNCTIONS **/
	public int getMinVM() {
		return this.minVM;
	}

	public int getMaxVM() {
		return this.maxVM;
	}

	public int getDelta() {
		return this.delta;
	}

	public int getSamplingPeriod() {
		return samplingPeriod;
	}

	public String getOpenstackMetric() {
		return openstackMetric;
	}

	public double getScaleUpThreshold() {
		return scaleUpThreshold;
	}

	public double getScaleDownThreshold() {
		return scaleDownThreshold;
	}

	public double getAlpha() {
		return alpha;
	}

	public double getBeta() {
		return beta;
	}

	public double getGamma() {
		return gamma;
	}

	public double getDeltaR() {
		return deltaR;
	}

	public double getM() {
		return M;
	}

	public double getTe() {
		return Te;
	}
	
	public double getAlphaMPC() {
		return alphaMPC;
	}

	public double getBetaMPC() {
		return betaMPC;
	}

	public double getGammaMPC() {
		return gammaMPC;
	}

	public double getDeltaMPC() {
		return deltaMPC;
	}

	public double getMMPC() {
		return MMPC;
	}

	public double getTeMPC() {
		return TeMPC;
	}

	public double getScaleUpPreThreshold() {
		return scaleUpPreThreshold;
	}

	public double getScaleDownPreThreshold() {
		return scaleDownPreThreshold;
	}

	public double getIncrementPerc() {
		return incrementPerc;
	}

	public double getDecrementPerc() {
		return decrementPerc;
	}

	public int getDurationPeriodInIntervals() {
		return durationPeriodInIntervals;
	}

	public SimulationType getSimulation() {
		return simulation;
	}

	public int getHowManySimulation() {
		return this.howManySimulation;
	}

	public ControllerType getWhichController() {
		return this.controller;
	}

	public double getScaleUpThreshold_1() {
		return scaleUpThreshold_1;
	}

	public double getScaleUpThreshold_2() {
		return scaleUpThreshold_2;
	}

	public double getScaleUpThreshold_3() {
		return scaleUpThreshold_3;
	}

	public double getScaleDownThreshold_1() {
		return scaleDownThreshold_1;
	}

	public double getScaleDownThreshold_2() {
		return scaleDownThreshold_2;
	}

	public double getScaleDownThreshold_3() {
		return scaleDownThreshold_3;
	}

	/** getting the future finite horizon for the model predictive controller */
	public int getFutureFiniteHorizon() {
		return this.futureFinitehorizon;
	}

	/**
	 * @return The controller used in String format
	 */
	public String getPrintableController() {
		switch (this.controller) {
		case Integral:
			return "Integral Controller";
		case Francis:
			return "Francis Controller";
		case Threshold:
			return "Threshold Controller";
		case None:
			return "None";
		case QuadThreshold:
			return "QuadThreshold";
		case MoreThresholdController:
			return "MoreThresholdController";
		case ModelPredictiveController:
			return "ModelPredictiveController";
		}
		return "Controller Undetectable";
	}

	/**
	 * @return The simulation started in String format
	 */
	public String getPrintableSimulation() {
		switch (this.simulation) {
		case HttpClient:
			return "Http Client Simulation";
		case MobDev:
			return "Mobile Device Simulation";
		case None:
			return "No Simulation";
		}
		return "Simulation Undetectable";
	}

	/**
	 * @return A string containing the most important parameters of a simulation
	 */
	public String getPrintableParameters() {
		String result = "TEST PARAMETERS\n";
		result += "minVM = " + this.getMinVM() + "\n";
		result += "maxVM = " + this.getMaxVM() + "\n";
		result += "delta = " + this.getDelta() + "\n";
		result += "howManySimulation = " + this.getHowManySimulation() + "\n";
		result += "controller = " + this.getPrintableController() + "\n";
		result += "simulation = " + this.getPrintableSimulation() + "\n";
		result += "samplingPeriod = " + this.getSamplingPeriod() + "\n";
		result += "setPoint = " + QoSModeler.getInstance().getSetPoint() + "\n";
		result += "alpha_model = " + this.getAlpha() + "\n";
		result += "beta_model = " + this.getBeta() + "\n";
		result += "gamma_model = " + this.getGamma() + "\n";
		result += "delta_model = " + this.getDeltaR() + "\n";
		result += "M_model = " + this.getM() + "\n";
		result += "Initial_Te_Model = " + this.getTe() + "\n";
		result += "openStackMetric = " + this.getOpenstackMetric() + "\n";
		result += "scaleUpThreshold = " + this.getScaleUpThreshold() + "\n";
		result += "scaleDownThreshold = " + this.getScaleDownThreshold() + "\n";
		result += "scaleUpPreThreshold = " + this.getScaleUpPreThreshold() + "\n";
		result += "scaleDownPreThreshold = " + this.getScaleDownPreThreshold() + "\n";
		result += "incrementPerc = " + this.getIncrementPerc() + "\n";
		result += "decrementPerc = " + this.getDecrementPerc() + "\n";
		result += "durationPeriodInIntervals = " + this.getDurationPeriodInIntervals() + "\n";
		return result;
	}

	/** GETTING FUNCTIONS **/

	/** SETTING FUNCTIONS **/
	public void setMinVM(int value) {
		this.minVM = value;
	}

	public void setMaxVM(int value) {
		this.maxVM = value;
	}

	public void setDelta(int value) {
		this.delta = value;
	}

	public void setSamplingPeriod(int samplingPeriod) {
		this.samplingPeriod = samplingPeriod;
	}

	public void setOpenstackMetric(String openstackMetric) {
		this.openstackMetric = openstackMetric;
	}

	public void setScaleUpThreshold(double scaleUpThreshold) {
		this.scaleUpThreshold = scaleUpThreshold;
	}

	public void setScaleDownThreshold(double scaleDownThreshold) {
		this.scaleDownThreshold = scaleDownThreshold;
	}

	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}

	public void setBeta(double beta) {
		this.beta = beta;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public void setDeltaR(double deltaR) {
		this.deltaR = deltaR;
	}

	public void setM(double m) {
		M = m;
	}

	public void setTe(double te) {
		Te = te;
	}
	
	public void setAlphaMPC(double alpha) {
		this.alphaMPC = alpha;
	}

	public void setBetaMPC(double beta) {
		this.betaMPC = beta;
	}

	public void setGammaMPC(double gamma) {
		this.gammaMPC = gamma;
	}

	public void setDeltaMPC(double deltaR) {
		this.deltaMPC = deltaR;
	}

	public void setMMPC(double m) {
		MMPC = m;
	}

	public void setTeMPC(double te) {
		TeMPC = te;
	}

	public void setScaleUpPreThreshold(double scaleUpPreThreshold) {
		this.scaleUpPreThreshold = scaleUpPreThreshold;
	}

	public void setScaleDownPreThreshold(double scaleDownPreThreshold) {
		this.scaleDownPreThreshold = scaleDownPreThreshold;
	}

	public void setIncrementPerc(double incrementPerc) {
		this.incrementPerc = incrementPerc;
	}

	public void setDecrementPerc(double decrementPerc) {
		this.decrementPerc = decrementPerc;
	}

	public void setDurationPeriodInIntervals(int durationPeriodInIntervals) {
		this.durationPeriodInIntervals = durationPeriodInIntervals;
	}

	public void setSimulation(SimulationType simulation) {
		this.simulation = simulation;
	}

	public void setHowManySimulation(int value) {
		this.howManySimulation = value;
	}

	public void setScaleUpThreshold_1(double scaleUpThreshold_1) {
		this.scaleUpThreshold_1 = scaleUpThreshold_1;
	}

	public void setScaleUpThreshold_2(double scaleUpThreshold_2) {
		this.scaleUpThreshold_2 = scaleUpThreshold_2;
	}

	public void setScaleUpThreshold_3(double scaleUpThreshold_3) {
		this.scaleUpThreshold_3 = scaleUpThreshold_3;
	}

	public void setScaleDownThreshold_1(double scaleDownThreshold_1) {
		this.scaleDownThreshold_1 = scaleDownThreshold_1;
	}

	public void setScaleDownThreshold_2(double scaleDownThreshold_2) {
		this.scaleDownThreshold_2 = scaleDownThreshold_2;
	}

	public void setScaleDownThreshold_3(double scaleDownThreshold_3) {
		this.scaleDownThreshold_3 = scaleDownThreshold_3;
	}

	public void setFutureFiniteHorizon(int futurefinitehorizon) {
		this.futureFinitehorizon = futurefinitehorizon;
	}

	/**
	 * Sets the controller starting from its index.<br>
	 * 
	 * <ul>
	 * <li>0: Integral Controller</li>
	 * <li>3: Francis Controller</li>
	 * <li>4: Threshold Controller</li>
	 * <li>5: Quad Threshold Controller</li>
	 * <li>7: Model Predictive Controller</li>
	 * </ul>
	 * 
	 * @param value
	 *            - The index of the controller
	 */
	public void setWhichController(int value) {
		switch (value) {
		case 0:
			System.out.println("TEST_PARAMETERS: controller = Integral");
			this.controller = ControllerType.Integral;
			break;
		case 3:
			System.out.println("TEST_PARAMETERS: controller = Francis");
			this.controller = ControllerType.Francis;
			break;
		case 4:
			System.out.println("TEST_PARAMETERS: controller = Threshold");
			this.controller = ControllerType.Threshold;
			break;
		case 5:
			System.out.println("TEST_PARAMETERS: controller = QuadThreshold");
			this.controller = ControllerType.QuadThreshold;
			break;
		case 6:
			System.out.println("TEST_PARAMETERS: controller = MoreThresholdController");
			this.controller = ControllerType.MoreThresholdController;
			break;
		case 7:
			System.out.println("TEST_PARAMETERS: controller = ModelPredictiveController");
			this.controller = ControllerType.ModelPredictiveController;
			break;
		default:
			System.out.println("TEST_PARAMETERS: controller = None");
			this.controller = ControllerType.None;
			break;
		}
	}

	/**
	 * Sets the simulation type starting from its name in String format.
	 * 
	 * @param simulation
	 */
	public void setSimulation(String simulation) {
		switch (simulation) {
		case "MobDevSimulation":
			System.out.println("TEST_PARAMETERS: simulation = MobDev");
			this.simulation = SimulationType.MobDev;
			break;
		case "HttpClientSimulation":
			System.out.println("TEST_PARAMETERS: simulation = HttpClient");
			this.simulation = SimulationType.HttpClient;
			break;
		default:
			System.out.println("TEST_PARAMETERS: simulation = None");
			this.simulation = SimulationType.None;
			break;
		}
	}
	/** SETTING FUNCTIONS **/

}
