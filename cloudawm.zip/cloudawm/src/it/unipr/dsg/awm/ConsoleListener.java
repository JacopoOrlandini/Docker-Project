package it.unipr.dsg.awm;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import it.unipr.dsg.awm.controller.QoSModeler;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
//import it.unipr.dsg.clientsimulation.SimulationInfo;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.LogWriter;

/**
 * This class is used to query the system during the execution.
 * It listens specified commands on the standard input.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class ConsoleListener extends Thread{

	/**
	 * Variable used for debug.
	 */
	private static String debug = "CONSOLE LISTENER - ";
	
	/**
	 * The {@link AssignedRequest} Singleton Object.
	 */
	private AssignedRequest assignedRequests = AssignedRequest.getInstance();
	/**
	 * The {@link QueuedRequest} Singleton Object.
	 */
	private QueuedRequest queuedRequests = QueuedRequest.getInstance();
	/**
	 * The {@link VirtualMachineStack} Singleton Object.
	 */
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	/**
	 * The {@link DataCollector} Singleton Object.
	 */
	private DataCollector dataColl = DataCollector.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();
	/**
	 * The {@link SimulationInfo} Singleton Object.
	 */
//	private SimulationInfo simInfo = SimulationInfo.getInstance();
	
	/**
	 * Does nothing...
	 */
	public ConsoleListener() {}
	
	/**
	 * Prints on standard output:
	 * 		- the total number of requests arrived in the Cloud
	 * 		- the number of requests not yet dispatched
	 * 		- the total number of requests completed
	 * 		- the number of requests waiting for a response from VMs
	 */
	private void printRequests(){
		System.out.println("Queued Requests Size: " + queuedRequests.getRequestQueueSize());
		System.out.println("Queued Requests Arrived: " + queuedRequests.getArrivedTasks());
		System.out.println("Assigned Requests Size: " + assignedRequests.getAssignedRequestSize());
		System.out.println("Assigned Requests Completed: " + assignedRequests.getCompletedTasks());
	}
	
	/**
	 * Prints all VMs in the Cloud.
	 */
	private void printVMs(){
		int counter = 0;
		System.out.println("Num\tIP\tStatus\tServices");
		for(VirtualMachine vm : vmStack.getAllVMs()){
			counter++;
			System.out.println(counter + "\t" + vm.getMyIP() + "\t" + vm.getVMStatus() + "\t" + vm.getServicesAsInlineString());
		}
	}
	
	/**
	 * Prints the results of the controller used to auto-scale the system.
	 */
	private void printControllerResults(){
		System.out.println("Controller results:");
		System.out.println(dataColl.getControllerResultPrintableData());
	}
	
	/**
	 * Prints the requests arrived in the Cloud grouped in groups of the duration of the sampling
	 * period of the controller used.
	 */
	private void printRequestArrivals(){
		System.out.println("Requests Per Sample:");
		System.out.println(dataColl.getRequestsPerSamplePrintableData());
	}
	
	/**
	 * Prints the values of the measurements of the set point of the Integral Controller
	 */
	private void printSetPointValues(){
		System.out.println("Set Point values:");
		System.out.println(dataColl.getSetPointValuePrintableData());
	}
	
	/**
	 * Prints the number of simulated devices not yet terminated.
	 */
/*	private void printClients(){
		System.out.println("Number of devices: " + simInfo.getNumberOfDevices());
	}
*/	
	/**
	 * Print the values of the measurements returned by the Ceilometer API.
	 */
	private void printOpenStackMetric(){
		System.out.println("OpenStack metric:");
		System.out.println(dataColl.getOpenStackMatricMeasurementPrintableData());
	}
	
	// TODO: da togliere
	private void printDebugController(){
		System.out.println("Debug Controller:");
		System.out.println(dataColl.getDebugControllerPrintableData());
	}
	
	private void printDebugVMCreator(){
		System.out.println("Debug Virtual Machine Controller:");
		System.out.println(dataColl.getDebugVirtualMachineCreatorPrintableData());
	}
	
	private void printExecTimes(){
		System.out.println("Execution times:");
		System.out.println(qos.getExecutionTimesPrintableData());
	}	
	
	private void printTimeOnCloud(){
		System.out.println("Time on cloud:");
		System.out.println(qos.getTimeOnCloudPrintableData());
	}	
	private void printTimeOnCloudFaceDetection(){
		System.out.println("Time on cloud Face Detection:");
		System.out.println(qos.getTimeOnCloudFaceDetectionPrintableData());
	}	
	private void printTimeOnCloudInverseMatrix(){
		System.out.println("Time on cloud Inverse Matrix:");
		System.out.println(qos.getTimeOnCloudInverseMatrixPrintableData());
	}	
	private void printActiveProcesses(){
		System.out.println("Active Processes:");
		System.out.println(dataColl.getActiveProcessesPrintableData());
	}	

	/**
	 * Elaborate a string inserted by the user.
	 * @param input The string inserted
	 */
	private void elab(String input){
		
		System.out.println(debug + "Hai inserito " + input);
		
		switch(input){
		case "req":
			printRequests();
			break;
		case "vm":
			printVMs();
			break;
		case "c":
			printControllerResults();
			break;
		case "r":
			printRequestArrivals();
			break;
		case "s":
			printSetPointValues();
			break;
//		case "h":
//			printClients();
//			break;	
		case "o":
			printOpenStackMetric();
			break;
		case "d":
			printDebugController();
			break;
		case "v":
			printDebugVMCreator();
			break;
		case "e":
			printExecTimes();
			break;
		case "t":
			printTimeOnCloud();
			break;
		case "tf":
			printTimeOnCloudFaceDetection();
			break;
		case "ti":
			printTimeOnCloudInverseMatrix();
			break;
		case "sd":
			LogWriter.getInstance().publicWriteDebugControllerLogFile();
			break;
		case "sv":
			LogWriter.getInstance().publicWriteDebugVirtualMachineCreatorLogFile();
			break;
		case "a":
			printActiveProcesses();
			break;
		}
	}

	/**
	 * Commands available are:<br>
	 * 
	 * <ul>
	 * <li>req: prints on standard output the number of requests arrived and served</li>
	 * <li>vm: prints the current number of VM with status</li>
	 * <li>c: prints the controller results</li>
	 * <li>r: prints the number of requests arrived in each sample</li>
	 * <li>s: prints the value of the quantity measured by the Integral Controller</li>
	 * <li>h: prints the number of devices not yet terminated</li>
	 * <li>o: prints the measurements of {@link it.unipr.dsg.awm.controller.ThresholdController} and {@link it.unipr.dsg.awm.controller.QuadThresholdController}</li>
	 * <li>d: prints the debug of the controller</li>
	 * <li>e: prints the execution times for each sampling period</li>
	 * <li>t: prints the response times for each sampling period</li>
	 * </ul>
	 */
	public void run(){
		
		System.out.println(debug + "START!!!");

		while(true){
			
			try{
				InputStreamReader reader = new InputStreamReader(System.in);
				BufferedReader myInput = new BufferedReader(reader);
				
				String inputString = myInput.readLine();
				elab(inputString);
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
	}
}
