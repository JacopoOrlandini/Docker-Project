package it.unipr.dsg.awm;

import it.unipr.dsg.awm.controller.QoSModeler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This class is a separate Thread and is responsible to respond at 
 * any query of SpeedUp time on the Cloud.
 * It is used in Mobile Cloud Computing (MCC)
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class SpeedUpServer extends Thread {
	
	private static String debug = "SPEEDUP_SERVER - ";
	
	/** 
	 * Listen port of the server
	 */
	private int portNumber = 5682;
	
	private QoSModeler qos = QoSModeler.getInstance();
		
	SpeedUpServer() {}
	
	
	public void run() {
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(portNumber, 500);
		} catch (IOException e) { e.printStackTrace(); }
		
		while(true) {
			try {
				Socket socket = serverSocket.accept();
				
				BufferedReader incomingData = new BufferedReader(new InputStreamReader(socket.getInputStream()));
								
				// Client Elab Time
				String tmpStr = incomingData.readLine();
				double clientElabTime = Double.parseDouble(tmpStr);
				
				double speedUp = 0;
				// CLoud Execution Time
				double avgOnCloudTime = qos.getAvgTimeOnCloud();

				if(avgOnCloudTime == 0) {
					speedUp = 0;
				} else {
					speedUp = clientElabTime / avgOnCloudTime;
				}
				
				System.out.println(debug + "speedUp = " + speedUp);
				PrintWriter outcomingData = new PrintWriter(socket.getOutputStream(), true);
				outcomingData.println(String.valueOf(speedUp));
				
			} catch (IOException e) { 
				e.printStackTrace();
				try { serverSocket.close(); } catch (IOException e1) { e1.printStackTrace(); }
			}
		}
	} // public void run() {..}
	
} // public class SpeedUpServer
