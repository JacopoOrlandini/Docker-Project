package it.unipr.dsg.awm.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * This class implements the interface {@link Storer} and manage the data from a Db
 * represented as a JSON file.
 * 
 * @author Valter Venusti - December 2015
 *
 */

public class JSONStorer implements Storer{

	/**
	 * Does nothing...
	 */
	public JSONStorer() {}
	
	/**
	 * Read a file and returns the content in String format.
	 */
	@Override
	public String getFileInStringFormat(String filename){
		
		File name = new File(filename);
		if (name.isFile()) {
			try {
				BufferedReader input = new BufferedReader(new FileReader(name));
				StringBuffer buffer = new StringBuffer();
				String text;
				while ((text = input.readLine()) != null)
					buffer.append(text);
				input.close();

				return buffer.toString();
			} catch (IOException ioException) {
				ioException.printStackTrace();
			}
		}
		return null;

	}

}
