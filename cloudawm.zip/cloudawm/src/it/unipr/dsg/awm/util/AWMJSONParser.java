package it.unipr.dsg.awm.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import it.unipr.dsg.awm.CheckUpServer;

/**
 * This class implements a parser for a Db stored in a file written in JSON format.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class AWMJSONParser {

	private String db;
	
	/**
	 * Set the Db to a default location. In version 1.0 it is "json/db.json".
	 */
	public AWMJSONParser(){
		
		setDb("json/db.json");
	}

	/**
	 * Set the location of the Db from the parameter passed.
	 * @param dbFilename - the path to the JSON file.
	 */
	public AWMJSONParser(String dbFilename) {

		setDb(dbFilename);
	}

	/**
	 * Return the Db path.
	 * @return the Db path in a String format.
	 */
	public String getDb() {
		return db;
	}

	/**
	 * Set the location of the Db from the parameter passed.
	 * @param db - the path to the JSON file.
	 */
	public void setDb(String db) {
		this.db = db;
	}
	
	/**
	 * Returns the ID of the VM to allocate.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getIndexVMToStart()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("VMInstancesData").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("toStart").toString();
		
	}
	
	/**
	 * Returns the port number used to contact the "checkUp" service on the VMs.
	 * @return the port as int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getCheckUpPort()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("VMInstancesData").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("checkUpPort").toString();
		
	}
	
	/**
	 * Returns all the characteristics of the VM images written in the db.
	 * @return a map in which the key is the ID of VM images and 
	 * the values is a map of characteristics in which the key and the value are String.
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public Map<String, HashMap<String, String>> parseVMData() 
			throws ParseException,FileNotFoundException,IOException{
		
		HashMap<String, HashMap<String, String>> hMap = new HashMap<String, HashMap<String, String>>();
		
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("VMInstancesData").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
				
		for(Object o : servicesMap.keySet()){
			
			if(!o.toString().equals("toStart") && !o.toString().equals("checkUpPort")){
				
				//Create handler's map
				Object ObjHandler = parser.parse(servicesMap.get(o).toString());
				JSONObject handMap = (JSONObject) ObjHandler;
				
				HashMap<String, String> handlers = new HashMap<String, String>();
				for(Object o1 : handMap.keySet()){
					handlers.put(o1.toString(), handMap.get(o1).toString());
				}
				
				hMap.put(o.toString(), handlers);
			}
		}
		
		return hMap;
		
	}
	
	/**
	 * Returns the time for which the {@link CheckUpServer} has to wait before making another
	 * requests.
	 * @return the waiting time in seconds
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getWaitingSecondsCheckUpServer()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("General").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("WaitingSecondsCheckUpServer").toString();
		
	}
	
	/**
	 * Returns the ID of the controller to use.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getIndexControllerToUse()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("Controller").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("toUse").toString();
		
	}
	
	/**
	 * Returns the Controllers defined in the db.
	 * @return a map in which the key is the controller ID and the value is a map of the characteristics of the controller.
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public Map<String, HashMap<String, String>> parseControllers() 
			throws ParseException,FileNotFoundException,IOException{
		
		HashMap<String, HashMap<String, String>> hMap = new HashMap<String, HashMap<String, String>>();
		
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("Controller").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
				
		for(Object o : servicesMap.keySet()){
			
			if(!o.toString().equals("toUse") && !o.toString().equals("samplingPeriodInMinutes")){
				
				//Create handler's map
				Object ObjHandler = parser.parse(servicesMap.get(o).toString());
				JSONObject handMap = (JSONObject) ObjHandler;
				
				HashMap<String, String> handlers = new HashMap<String, String>();
				for(Object o1 : handMap.keySet()){
					handlers.put(o1.toString(), handMap.get(o1).toString());
				}
				
				hMap.put(o.toString(), handlers);
			}
		}
		
		return hMap;
		
	}
	
	/**
	 * Returns the period of sampling.
	 * @return the period of sampling in minutes
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getSamplingPeriodInMinutes()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("Controller").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("samplingPeriodInMinutes").toString();
		
	}
	
	/**
	 * Returns the minimum number of Virtual Machines in the system.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getMinVM()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("General").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("MinVM").toString();		
	}
	
	/**
	 * Returns the maximum number of Virtual Machines allowed in the system.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getMaxVM()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("General").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("MaxVM").toString();
	}

	/**
	 * Returns the total number of simulations to do.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getHowManySimulations()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("General").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("HowManySimulation").toString();
	}
	
	/**
	 * Returns the ID of the simulation to start.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public String getSimulation()
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get("General").toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap.get("Simulation").toString();
	}
	
	/**
	 * Returns all JSON information contained in the voice passed as parameter.
	 * @return a map of the informations
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public JSONObject getFromVoice(String voice)
			throws ParseException,FileNotFoundException,IOException{
	
		JSONParser parser = new JSONParser();
		Storer storer = new JSONStorer();
		
		Object JSONobj = parser.parse(storer.getFileInStringFormat(getDb()));
		JSONObject jMap = (JSONObject) JSONobj;
		
		Object servicesObj = parser.parse(jMap.get(voice).toString());
		JSONObject servicesMap = (JSONObject) servicesObj;
		
		return servicesMap;
	}
	
	/**
	 * Takes a string in JSON format and transform it in a map without following the recursive fields
	 * @param toParse - the string to parse
	 * @return a map without the recursive fields
	 * @throws ParseException - if errors occur during parsing the string
	 */
	public JSONObject parseFromString(String toParse) 
			throws ParseException{
		
		JSONParser parser = new JSONParser();
		Object JSONobj = parser.parse(toParse);
		JSONObject jMap = (JSONObject) JSONobj;
		
		return jMap;
	}

	
}
