package it.unipr.dsg.awm;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * This class is a Singleton Object and is used to remember the ID assigned in the Cloud.
 * Everyone can take a new ID simply calling the method {@link #getNextValidId() getNextValidId}.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class IdAllocator {
	/**
	 * Debug string.
	 */
	private static String debug = "ID_ALLOCATOR - ";
	
	/**
	 * The array of IDs assigned.
	 */
	private CopyOnWriteArrayList<Long> ids;
	/**
	 * Last ID assigned. This variable is used for optimization reasons.
	 */
	private long lastId;
	
	/** SINGLETON STUFF **/
	private static IdAllocator instance = null;

	private IdAllocator() {
		this.ids = new CopyOnWriteArrayList<Long>();
		this.lastId = 0;
	}
	
	public static synchronized IdAllocator getInstance() {
		if(instance == null)
			instance = new IdAllocator();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/
	
	/**
	 * Get the next valid ID
	 * 
	 * @return long
	 */
	public synchronized long getNextValidId(){
	
		try{
			long returnValue = this.lastId;
			
			while(!this.ids.addIfAbsent(returnValue)){
				
				if(this.lastId >= Long.MAX_VALUE) this.lastId = 0;
				else this.lastId = (this.lastId+1);
				returnValue = this.lastId;
			}
			
			System.out.println(debug + " Taken id " + returnValue);
			return returnValue;
		}catch(Exception e){
			return -1;
		}
	}

	/**
	 * Remove a specific ID.
	 * @param id The ID to remove.
	 */
	public synchronized void removeId(long id){
		
		int size_before = this.ids.size();
		int index = this.ids.indexOf(id);
		if(index != -1){
			this.ids.remove(index);
			int size_after = this.ids.size();
			if(size_after < size_before) System.out.println(debug + " Removed id " + id);
			else System.out.println(debug + " Error in removing id " + id);
		}
	}
}
