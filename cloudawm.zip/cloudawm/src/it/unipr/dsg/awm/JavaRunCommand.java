package it.unipr.dsg.awm;

import java.io.*;

public class JavaRunCommand extends Thread{
	String code = "";
	public Process p = null;
	
	public JavaRunCommand(String in) {
		code = in;
		
	}
	@Override
	public void run(){
		String s;
        try {
        	// using the Runtime exec method:
        	p = Runtime.getRuntime().exec("python "+code+".py");
            System.out.println("processo id : "+ p);
            BufferedReader stdInput = new BufferedReader(new 
                 InputStreamReader(p.getInputStream()));

            BufferedReader stdError = new BufferedReader(new 
                 InputStreamReader(p.getErrorStream()));
            // read the output from the command
            while ((s = stdInput.readLine()) != null) {
                
            }
            
            // read any errors from the attempted command
            while ((s = stdError.readLine()) != null) {
            	System.out.println(s);
            }

            
        }
        catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
            System.exit(-1);
        }
	}


}
