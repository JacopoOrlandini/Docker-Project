package it.unipr.dsg.awm.servicebroker;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;

import it.unipr.dsg.awm.CheckUpServer;
import it.unipr.dsg.awm.util.AWMJSONParser;

/**
 * This class has 2 functions. 
 * The first function is to maintain a map that binds VM and application activated on VM.
 * The second function is to offer some utilities to have a better experience with the db.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class ServiceBroker extends Thread {
	private static String debug = "SERVICE BROKER - ";
	private int serverPort = 5683;
		
	/**
	 * Does nothing...
	 */
	public ServiceBroker() {}
	
	/* STATIC FUNCTIONS */
	/**
	 * Static function that returns all the characteristics of the VM images written in the db.
	 * @return a map in which the key is the ID of VM images and 
	 * the values is a map of characteristics in which the key and the value are String.
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static Map<String, HashMap<String, String>> getVMInstances() 
			throws ParseException,FileNotFoundException,IOException {

			return new AWMJSONParser().parseVMData();
	}
	
	/**
	 * Static function that returns the ID of VM image to use to allocate the Virtual Machines.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
    public static String getIndexVMToStart() 
			throws ParseException,FileNotFoundException,IOException{
		
		return new AWMJSONParser().getIndexVMToStart();
	}
	
	/**
	 * Static function that returns the port number used to contact the "checkUp" service on the VMs.
	 * @return the port as int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getCheckUpPort() 
			throws ParseException,FileNotFoundException,IOException{
		
		String port = new AWMJSONParser().getCheckUpPort();
		
		return Integer.parseInt(port);
	}
	
	/**
	 * Static function that returns the time for which the {@link CheckUpServer} has to wait before making another
	 * requests.
	 * @return the waiting time in seconds
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getWaitingSecondsCheckUpServer(){
		
		try{
		
			String sec = new AWMJSONParser().getWaitingSecondsCheckUpServer();
	
			return Integer.parseInt(sec);
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * Static function that returns the minimum number of Virtual Machines in the system.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getMinVM(){
		
		try{
		
			String minVM = new AWMJSONParser().getMinVM();
	
			return Integer.parseInt(minVM);
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * Static function that returns the maximum number of Virtual Machines allowed in the system.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getMaxVM(){
		
		try{
		
			String maxVM = new AWMJSONParser().getMaxVM();
	
			return Integer.parseInt(maxVM);
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * Static function that returns the ID of the controller to use.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static String getIndexControllerToUse() 
			throws ParseException,FileNotFoundException,IOException{
		
		return new AWMJSONParser().getIndexControllerToUse();
	}
	
	/**
	 * Static function that returns the Controllers defined in the db.
	 * @return a map in which the key is the controller ID and the value is a map of the characteristics of the controller.
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static Map<String, HashMap<String, String>> getControllers() 
			throws ParseException,FileNotFoundException,IOException {

			return new AWMJSONParser().parseControllers();
	}
	
	/**
	 * Static function that returns the period of sampling.
	 * @return the period of sampling as int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getSamplingPeriodInMinutes() 
			throws ParseException,FileNotFoundException,IOException{
		
		String samplingPeriodInMinutes = new AWMJSONParser().getSamplingPeriodInMinutes();
		
		return Integer.parseInt(samplingPeriodInMinutes);
	}
	
	/**
	 * Static function that returns the total number of simulations to do.
	 * @return int
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static int getHowManySimulations(){
		
		try{
		
			String hms = new AWMJSONParser().getHowManySimulations();
	
			return Integer.parseInt(hms);
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * Static function that returns the ID of the simulation to start.
	 * @return the ID in String format
	 * @throws ParseException - if errors occur during reading the db
	 * @throws FileNotFoundException - if not able to find the db
	 * @throws IOException - if errors during reading the db
	 */
	public static String getSimulation() 
			throws ParseException,FileNotFoundException,IOException{
		
		return new AWMJSONParser().getSimulation();
	}
	/* END OF STATIC FUNCTIONS */
	
	/**
	 * Simply starts a new thread for any new registration or cancellation request 
	 * received from VMs.
	 */
	public void run() {
		System.out.println(debug + "START!!!");
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(serverPort, 500);
		} catch (IOException e1) { 
			System.err.println(debug + "Could not listen on port " + serverPort);
        	System.exit(-1);
        }
		
		int threadId = 0;
    	while(true) {
    		try {
    			System.out.println(debug + "Listening on port " + this.serverPort + "...");
				Socket socket = serverSocket.accept();
				
				System.out.println(debug + "<===== New APP REQUEST Received!!!");
				ServiceBrokerThread serviceBrokerThread = new ServiceBrokerThread(threadId, socket);
				serviceBrokerThread.start();
				
				threadId++;
			} catch (IOException e) {
				e.printStackTrace();
				try { serverSocket.close(); } catch (IOException e1) { e1.printStackTrace(); }
			}
    	} // while(true) {..}
	} // public void run() {..}
	
}
