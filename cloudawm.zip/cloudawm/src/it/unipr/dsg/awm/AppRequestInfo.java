package it.unipr.dsg.awm;

import java.net.Socket;
import java.util.Date;

/**
 * Class representing a request in CloudAWM 1.0
 * 
 * @author Valter Venusti - December 2015
 */

public class AppRequestInfo {

	/**
	 * The unique ID of the request 
	 */
	private long id;

	/**
	 * Socket used for the communication with the Web Service REST.
	 * Socket used to send the response received from the VMs.
	 */
	private final Socket socketInfo;
	/**
	 * IP address of the VM to which the request has been sent.
	 */
	private String vmIP = null;
	
	/**
	 * Time of the creation of the request. Set in the constructor.
	 */
	private Date startTime;
	/**
	 * Time used to calculate how much the request has been on the Cloud.
	 * Set every time the getCurrentTimeLife() method is called.
	 */
	private Date finishTime;
	
	/**
	 * Time of starting of the elaboration on the VM.
	 * Assigned when the request enters in the {@link AssignedRequest} queue.
	 */
	private Date startExecutionTime;
	/**
	 * Time used to calculate the execution time on the VM.
	 * Set every time the getExecutionTime() is called.
	 */
	private Date finishExecutionTime;	
	
	/**
	 * The Singleton object {@link IDAllocator}
	 */
	private IdAllocator idAllocator = IdAllocator.getInstance();
	
	/**
	 * The application name to which the request belongs
	 */
	private String applicationName = "";
	/**
	 * The message contained in the request
	 */
	private String postString = "";
	
	/**
	 * Counter of the number of errors occurred while trying to dispatch the request.
	 * Incremented every time the request is taken from the {@link QueuedRequest} queue and put again in
	 * the queue because an error occurred.
	 */
	private int errorNumbers = 0;
	
	
	/**
	 * The constructor.
	 * 
	 * @param s The Socket established between the sender of request and CloudAWM.
	 */
	public AppRequestInfo(Socket s){
		this.socketInfo = s;
		this.id = -1;
		startTime();
	}
	
	/**
	 * Get the ID of the request.
	 * @return the id of the request.
	 */
	public long getId() {
		return id;
	}

	/**
	 * Set the ID of the request. If the request already has a valid ID, it is removed using 
	 * the method removeId of {@link IdAllocator}.
	 * @param id the new ID of the request.
	 */
	public void setId(long id) {
		if(this.id != -1) idAllocator.removeId(this.id);
		this.id = id;
	}
	
	/**
	 * Get the socket established between the sender of request and CloudAWM.
	 * @return a {@link Socket} object.
	 */
	public Socket getSocketInfo() {	return this.socketInfo; }
	
	/**
	 * Return the IP address of the VM to which the request has been sent.
	 * @return String
	 */
	public String getVM_IP() { return this.vmIP; }
	
	/**
	 * Set the IP address of the VM to which the request has been sent.
	 * @param ip IP address in String format
	 */
	public void setVM_IP(String ip) { this.vmIP = ip; }
	
	/**
	 * Get the time in milliseconds from the creation of the request.
	 * @return difference from timestamps in milliseconds
	 */
	public long getCurrentTimeLife() {
		this.finishTime = new Date();
		long timeLife = finishTime.getTime() - startTime.getTime();
		return timeLife;
	}
	
	/**
	 * Set the instant of the creation of the request.
	 */
	public void startTime() { this.startTime = new Date(); }
	/**
	 * Set the instant of beginning of the execution on the VM.
	 */
	public void startExecutionTime() { this.startExecutionTime = new Date(); }

	/**
	 * Get the time in milliseconds from the beginning of the execution on the VM.
	 * @return long
	 */
	public long getExecutionTime() {
		this.finishExecutionTime = new Date();
		long executionTime = finishExecutionTime.getTime() - startExecutionTime.getTime();
		return executionTime;
	}
	
	/**
	 * Get the name of the application to which the request belongs.
	 * @return String
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Set the application name.
	 * @param applicationName The application name in String format.
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Get the message contained in the request.
	 * @return String
	 */
	public String getPostString() {
		return postString;
	}

	/**
	 * Set the message contained in the request.
	 * @param postString the message in String format.
	 */
	public void setPostString(String postString) {
		this.postString = postString;
	}

	/**
	 * Get the number of errors occurred from the creation of the request.
	 * @return int
	 */
	public int getErrorNumbers() {
		return errorNumbers;
	}

	/**
	 * Set the number of errors occurred for this request.
	 * @param errorNumbers The new value of the number of errors.
	 */
	public void setErrorNumbers(int errorNumbers) {
		this.errorNumbers = errorNumbers;
	}


}
