package it.unipr.dsg.awm.requesthandler;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This class is responsible to receive all the requests that arrive in the Cloud and put them
 * in the blocking queue of the {@link it.unipr.dsg.awm.dispatcher.Dispatcher Dispatcher}
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class RequestHandler extends Thread {
	private static String debug = "REQUEST_HANDLER_THREAD - ";
	
	private int portNumber = 5679;
	
	/**
	 * Does nothing...
	 */
	public RequestHandler() {}
	
	/**
	 * This method simply listen on port 5679 and starts a new thread for any new requests arrived.
	 */
    public void run() {
    	// Socket for listen request arriving from NodeJS
		ServerSocket serverSocket = null;
		
    	try {
    		System.out.println(debug + "START!! Server for listen NodeJS.");
			serverSocket = new ServerSocket(portNumber, 500);
		} catch (IOException e1) { 
			System.err.println(debug + "Could not listen on port " + portNumber);
        	System.exit(-1);
        }
		
    	int threadId = 0;
    	while(true) {
    		try {
//				System.out.println(debug + "Waiting connection from (<=====) NodeJs...");
				Socket socket = serverSocket.accept();
				
				System.out.println(debug + "<===== New REQUEST from NodeJS!!!");
				RequestHandlerThread reqHandlerThread = new RequestHandlerThread(threadId, socket);
				reqHandlerThread.start();

				threadId++;
			} catch (IOException e) {
				e.printStackTrace();
				try { serverSocket.close(); } catch (IOException e1) { e1.printStackTrace(); }
			}
    	} // while(true) {..}
    } // public void run() {..}
    
} // public class ListenerSocketMultiThread extends Thread {..}