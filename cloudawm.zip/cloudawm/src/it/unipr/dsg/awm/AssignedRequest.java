package it.unipr.dsg.awm;

import java.util.Vector;

import it.unipr.dsg.awm.controller.QoSModeler;

/**
 * Class containing all requests assigned to VMs for which has not been yet sent a response from the VMs.
 * It is coded as a Singleton Object.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 */

public class AssignedRequest {
	/**
	 * String used for printing out the debug when necessary.
	 */
	private static String debug = "ASSIGNED_REQUEST - ";
	
	/**
	 * The set of the assigned requests is a {@link Vector} of {@link AppRequestInfo}.
	 */
	private Vector<AppRequestInfo> assignedRequest = new Vector<AppRequestInfo>();
	/**
	 * Number of completed task since the start of the system.
	 */
	private int completedTasks = 0;

	/**
	 * The {@link IdAllocator} Singleton Object
	 */
	private IdAllocator idAllocator = IdAllocator.getInstance();
	/**
	 * The {@link QoSModeler} Singleton Object
	 */
	private QoSModeler qos = QoSModeler.getInstance();
	
	/** SINGLETON STUFF **/
	
	private static AssignedRequest instance = null;

	private AssignedRequest() {}
	
	public static synchronized AssignedRequest getInstance() {
		if(instance == null)
			instance = new AssignedRequest();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/

	/**
	 * Search a request in the set.
	 * @param id the id of the request to search in String format
	 * @return the {@link AppRequestInfo} object
	 */
	public AppRequestInfo searchRequestByID(String id) {
		synchronized(assignedRequest) {
			AppRequestInfo result = null;
			for(int i=0; i<assignedRequest.size(); i++) {
				if( assignedRequest.get(i).getId() == Long.parseLong(id) ) {
					result = assignedRequest.get(i);
					break;
				}
			}
			return result;
		}
	} 
	
	/**
	 * Get the number of requests still in the queue
	 * @return int
	 */
	public int getAssignedRequestSize() {
		synchronized(assignedRequest) {
			return assignedRequest.size();
		}
    } 
	
	/**
	 * Get a specific request.
	 * @param index The position of the requests within the vector of requests.
	 * @return an {@link AppRequestInfo}
	 */
	public AppRequestInfo getRequestInfo(int index) {
		synchronized(assignedRequest) {
			return assignedRequest.get(index);
		}
	}
	
	/**
	 * Remove a request from the vector.
	 * It also remove the id of the request from the {@link IdAllocator} object and increments the number of
	 * completed tasks.
	 * @param request The {@link AppRequestInfo} object of the request to remove
	 */
	public void removeRequest(AppRequestInfo request) {
		
		qos.addWindowedTimeOnCloud(request.getCurrentTimeLife()/1000.0);
		if(request.getApplicationName().trim().equals("FaceDetection"))
			qos.addTimeOnCloudFaceDetection(request.getCurrentTimeLife()/1000.0);
		else
			qos.addTimeOnCloudinverseMatrix(request.getCurrentTimeLife()/1000.0);
		
		synchronized(assignedRequest) {
			for(int i=0; i<assignedRequest.size(); i++) {
				if( assignedRequest.get(i).getId() == request.getId()) {
					assignedRequest.remove(i);
					completedTasks++;
					idAllocator.removeId(request.getId());
				}
			}
			System.out.println(debug + "completedTasks (GLOBAL) = " + completedTasks);
		}
	} 

	/**
	 * Add a request to the vector of assigned requests.
	 * @param currentRequest The {@link AppRequestInfo} object to add.
	 */
	public void addRequest(AppRequestInfo currentRequest) {
		synchronized(assignedRequest) {
			assignedRequest.addElement(currentRequest);
			
			currentRequest.startExecutionTime();
			qos.addStationingTime(currentRequest.getCurrentTimeLife()/1000.0);
		}
	} 

	/**
	 * Get the number of completed task since the start of the system.
	 * @return int
	 */
	public int getCompletedTasks() {
		synchronized(assignedRequest) {
			return completedTasks;
		}
	}
	
	/**
	 * Clear the vector of requests and reset the number of completed tasks.
	 */
	public void resetAllVariables() {
		synchronized(this.assignedRequest) {
			this.assignedRequest.clear();
			this.completedTasks = 0;
		}
	}
	
//    public List<Long> getCurrentStationingTimes(){
//    	ArrayList<Long> stationingTime = new ArrayList<Long>();
//    	synchronized(this.assignedRequest){
//	    	for(AppRequestInfo request : this.assignedRequest){
//	    		stationingTime.add(request.getCurrentTimeLife());
//	    	}
//    	}
//    	return stationingTime;
//    }
}
