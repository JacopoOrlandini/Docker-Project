package it.unipr.dsg.awm.controller;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.TestParameters;

/**
 * This class is a Singleton Object and is responsible to collect the informations necessary to manage
 * the quality of service within the system.
 * 
 * @author Valter Venusti - December 2015
 *
 */

public class QoSModeler{
	
	private static String debug = "QOS MODELER - ";
	
	/** SINGLETON STUFF **/
	private static QoSModeler instance = null;

	private QoSModeler() {}
	
	public static synchronized QoSModeler getInstance() {
		if(instance == null)
			instance = new QoSModeler();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/

	//Window in minutes to calculate the avgWindowedTimeOnCloud
//	private int windowInMinutes = 15;
	//Set Point for the Integral Controller and Proportional Integral Controller 
	private double setPoint = 0.6;
	
	private TestParameters testParam = TestParameters.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	
	private ConcurrentHashMap<Date, Double> windowedTimeOnCloud = new ConcurrentHashMap<Date, Double>();
	private ConcurrentHashMap<Date, Double> stationingTimes = new ConcurrentHashMap<Date, Double>();
	private ConcurrentHashMap<Date, Double> executionTimes = new ConcurrentHashMap<Date, Double>();
	private Vector<Double> timeOnCloudAvg = new Vector<Double>();
	private Vector<Double> timeOnCloudStdDev = new Vector<Double>();
	private Vector<Double> executionTimesAvg = new Vector<Double>();
	private Vector<Double> executionTimesStdDev = new Vector<Double>();
	private Vector<Date> requestsArrivals = new Vector<Date>();
	
	private Vector<Double> timeOnCloudFaceDetection = new Vector<Double>();
	private Vector<Double> timeOnCloudFaceDetectionAvg = new Vector<Double>();
	private Vector<Double> timeOnCloudFaceDetectionStdDev = new Vector<Double>();

	private Vector<Double> timeOnCloudInverseMatrix = new Vector<Double>();
	private Vector<Double> timeOnCloudInverseMatrixAvg = new Vector<Double>();
	private Vector<Double> timeOnCloudInverseMatrixStdDev = new Vector<Double>();
	

	/**
	 * This function is responsible to calculate the average and the standard deviation of inserted
	 * response times every time it is called.
	 */
	public void collectNewData(){
		this.computeNewAvgAndStdDev(this.windowedTimeOnCloud, this.timeOnCloudAvg, this.timeOnCloudStdDev);
		this.computeNewAvgAndStdDev(this.executionTimes, this.executionTimesAvg, this.executionTimesStdDev);
		this.computeNewAvgAndStdDev(this.timeOnCloudFaceDetection, 
				this.timeOnCloudFaceDetectionAvg, this.timeOnCloudFaceDetectionStdDev);
		this.computeNewAvgAndStdDev(this.timeOnCloudInverseMatrix, 
				this.timeOnCloudInverseMatrixAvg, this.timeOnCloudInverseMatrixStdDev);
	}

	/** ADDING FUNCTIONS **/
	/**
	 * Add the arrival time of a request
	 * @param d - the time of arrival
	 */
	public void addRequestArrival(Date d){ this.requestsArrivals.add(d); }
	/**
	 * Add a "TimeOnCloud". It means a response time.
	 * This function is called when a request leave the Cloud.
	 * @param time
	 */
	public void addWindowedTimeOnCloud(double time){ this.windowedTimeOnCloud.put(new Date(), time); }
	/**
	 * Adds the waiting time of a request. 
	 * The time during it has been in the blocking queue of the {@link it.unipr.dsg.awm.dispatcher.Dispatcher}
	 * @param value - a time value in seconds.
	 */
	public void addStationingTime(double value){ this.stationingTimes.put(new Date(), value); }
	
	/**
	 * Adds the execution time of a request on a Virtual Machine.
	 * @param value - the execution time in seconds
	 */
	public void addExecutionTimeValue(double value) {
		synchronized(this.executionTimes) {
			this.executionTimes.put(new Date(), value);
		}
	}
	/**
	 * Adds a response time for a request belonging to the FaceDetection application.
	 * @param value - a time value in seconds
	 */
	public void addTimeOnCloudFaceDetection(double value){
		synchronized(this.timeOnCloudFaceDetection) {
			this.timeOnCloudFaceDetection.add(value);
		}
	}
	/**
	 * Adds a response time for a request belonging to the InverseMatrix application.
	 * @param value - a time value in seconds
	 */
	public void addTimeOnCloudinverseMatrix(double value){
		synchronized(this.timeOnCloudInverseMatrix) {
			this.timeOnCloudInverseMatrix.add(value);
		}
	}
	/** GETTING FUNCTIONS **/
	
	/**
	 * Returns the mean response time of the Cloud in a window in the past.
	 * The window is defined in milliseconds.
	 * @param windowInMilliseconds - The window in the past
	 * @return a double value
	 */
	public double getAvgWindowedTimeOnCloud(int windowInMilliseconds){
		double sum = 0;
		int counter = 0;
		Date date = new Date(new Date().getTime() - windowInMilliseconds);
		for(Iterator<Entry<Date, Double>> it = this.windowedTimeOnCloud.entrySet().iterator();
		          it.hasNext(); ){

	        Entry<Date, Double> entry = it.next();
	        
	        if(entry.getKey().after(date)){
	        	sum += entry.getValue();
	        	counter++;
	        }
		}
		if(counter == 0) return 0;
		else return sum / counter;
	}
	
	/**
	 * Returns the mean waiting time within the blocking queue of the {@link it.unipr.dsg.awm.dispatcher.Dispatcher}
	 * in a window in the past.
	 * The window is defined in milliseconds.
	 * @param windowInMilliseconds - The window in the past
	 * @return a double value
	 */
	public double getAvgWindowedStationingTime(int windowInMilliseconds){
		double sum = 0;
		int counter = 0;
		Date date = new Date(new Date().getTime() - windowInMilliseconds);
		for(Iterator<Entry<Date, Double>> it = this.stationingTimes.entrySet().iterator();
		          it.hasNext(); ){

	        Entry<Date, Double> entry = it.next();
	        
	        if(entry.getKey().after(date)){
	        	sum += entry.getValue();
	        	counter++;
	        }
		}
		if(counter == 0) return 0;
		else return sum / counter;
	}
	
	/**
	 * Returns the mean execution time in a window in the past.
	 * The window is defined in milliseconds.
	 * @param windowInMilliseconds - The window in the past
	 * @return a double value
	 */	public double getAvgWindowedExecutionTime(int windowInMilliseconds){
		double sum = 0;
		int counter = 0;
		Date date = new Date(new Date().getTime() - windowInMilliseconds);
		for(Iterator<Entry<Date, Double>> it = this.executionTimes.entrySet().iterator();
		          it.hasNext(); ){

	        Entry<Date, Double> entry = it.next();
	        
	        if(entry.getKey().after(date)){
	        	sum += entry.getValue();
	        	counter++;
	        }
		}
		if(counter == 0) return 0;
		else return sum / counter;
	}
		
	/**
	 * Returns the mean response time since the start of the system.
	 * @return a double value
	 */
	public double getAvgTimeOnCloud(){
		double sum = 0;
		int counter = 0;
		for(Iterator<Entry<Date, Double>> it = this.windowedTimeOnCloud.entrySet().iterator();
		          it.hasNext(); ){

	        Entry<Date, Double> entry = it.next();
	        
	        sum += entry.getValue();
	        counter++;
		}
		if(counter == 0) return 0;
		else return sum / counter;
	}

	/**
	 * Returns the number of requests arrived in a window in the past.
	 * The window is defined in milliseconds.
	 * @param windowInMilliseconds - The window
	 * @return an integer value
	 */
	public int getWindowedRequestsArrivals(int windowInMilliseconds){
		int counter = 0;
		Date date = new Date(new Date().getTime() - windowInMilliseconds);
		for(int i = 0; i < this.requestsArrivals.size(); i++){
	        
	        if(this.requestsArrivals.get(i).after(date)){
	        	counter++;
	        }
		}
		return counter;
	}
	
	/**
	 * Returns the current Quality Of Service (QoS) measurement.
	 * This method is static but in future we hope not.
	 * We think it will be very simple to change the QoS, maybe also at runtime,
	 * according to a simple configuration file, maybe in JSON format.
	 * @return a double value.
	 */
	public double getQoSCurrentMeasurement(){
			
		double samplingPeriodInSeconds = testParam.getSamplingPeriod() * 60;
		double Te = getAvgWindowedTimeOnCloud(testParam.getSamplingPeriod() * 60 * 1000);
		if(Te == 0) Te = 0.001;
		double willBeServed = ( (double) samplingPeriodInSeconds / Te) *
				vmStack.getNumOfActiveVM();
		double estimatedRequests = getWindowedRequestsArrivals(testParam.getSamplingPeriod() * 60 * 1000);
		double willNotBeServed = estimatedRequests - willBeServed;
		double num = willNotBeServed;
		double den = estimatedRequests;
		System.out.println(debug + "Number of VMs: " + vmStack.getNumOfActiveVM() + " Time On Cloud: " +
				getAvgWindowedTimeOnCloud(testParam.getSamplingPeriod() * 60 * 1000));
		System.out.println(debug + "Future requests not served: " + num + 
				" Future requests: " + den);
		System.out.println(debug + "Set Point: " + this.setPoint);
		return num/den;
	}
	
	/**
	 * Returns the set point used for Integral and Proportional Integral Controller
	 * @return a double value
	 */
	public double getSetPoint() { return setPoint; }
	/** GETTING FUNCTIONS **/

	/** SETTING FUNCTIONS **/
	/**
	 * Permits to set the set point for Integral Controller and Proportional Integral Controller
	 * @param setPoint - The desiderated value of the set point.
	 */
	public void setSetPoint(double setPoint) { this.setPoint = setPoint; }
	/** SETTING FUNCTIONS **/
	
	
	/** GET...PRINTABLE DATA **/
	/**
	 * Returns statistical data of the response time on the CLoud in a comprehensible format.
	 * @return Statistical data in String format
	 */
	public String getTimeOnCloudPrintableData(){
		synchronized(this.timeOnCloudAvg) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.timeOnCloudAvg.size(); i++)
				result += (i+1) + "\t" + this.timeOnCloudAvg.get(i) + "\t" 
									   + this.timeOnCloudStdDev.get(i) + "\n";
			return result;
		}
	}
	
	/**
	 * Returns statistical data of the execution time on the CLoud in a comprehensible format.
	 * @return Statistical data in String format
	 */
	public String getExecutionTimesPrintableData(){
		synchronized(this.executionTimes) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.executionTimesAvg.size(); i++)
				result += (i+1) + "\t" + this.executionTimesAvg.get(i) + "\t" 
									   + this.executionTimesStdDev.get(i) + "\n";
			return result;
		}
	}
	
	/**
	 * Returns statistical data of the response time on the Cloud in a comprehensible format.
	 * This function refers only to the response time of the FaceDetection application.
	 * @return Statistical data in String format
	 */
	public String getTimeOnCloudFaceDetectionPrintableData(){
		synchronized(this.timeOnCloudFaceDetection) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.timeOnCloudFaceDetectionAvg.size(); i++)
				result += (i+1) + "\t" + this.timeOnCloudFaceDetectionAvg.get(i) + "\t" 
									   + this.timeOnCloudFaceDetectionStdDev.get(i) + "\n";
			return result;
		}
	}
	/**
	 * Returns statistical data of the response time on the Cloud in a comprehensible format.
	 * This function refers only to the response time of the InverseMatrix application.
	 * @return Statistical data in String format
	 */
	public String getTimeOnCloudInverseMatrixPrintableData(){
		synchronized(this.timeOnCloudInverseMatrix) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.timeOnCloudInverseMatrixAvg.size(); i++)
				result += (i+1) + "\t" + this.timeOnCloudInverseMatrixAvg.get(i) + "\t" 
									   + this.timeOnCloudInverseMatrixStdDev.get(i) + "\n";
			return result;
		}
	}
	
	/**
	 * Returns all data of the response time on the Cloud in a comprehensible format.
	 * This function refers only to the response time of the FaceDetection application.
	 * @return Statistical data in String format
	 */
	public String getAllTimeOnCloudFaceDetectionPrintableData() {
		String result = "";
		result += "#K\t\n";
		int i = 0;
		synchronized(this.timeOnCloudFaceDetection) {
			for(Double d : this.timeOnCloudFaceDetection){
				result += (i+1)  + "\t" + d + "\n";
				i++;
			}
		}

		return result;
	}
	/**
	 * Returns all data of the response time on the Cloud in a comprehensible format.
	 * This function refers only to the response time of the FaceDetection application.
	 * @return Statistical data in String format
	 */
	public String getAllTimeOnCloudInverseMatrixPrintableData() {
		String result = "";
		result += "#K\t\n";
		int i = 0;
		synchronized(this.timeOnCloudInverseMatrix) {
			for(Double d : this.timeOnCloudInverseMatrix){
				result += (i+1)  + "\t" + d + "\n";
				i++;
			}
		}

		return result;
	}
	
	/** GET...PRINTABLE DATA **/
	
	/**
	 * Clears all the vectors of data filled during the execution.
	 */
	public void resetAllVariables(){
		
		this.requestsArrivals.clear();
		this.windowedTimeOnCloud.clear();
		this.timeOnCloudAvg.clear();
		this.timeOnCloudStdDev.clear();
	}
	
	/** PRIVATE FUNCTIONS **/
	private void computeNewAvgAndStdDev(Map<Date, Double> dataVector, 
										Vector<Double> avgVector, 
										Vector<Double> stdDevVector) {
		synchronized(dataVector) {
			double avgValue = computeAvgOfVector(dataVector);
			avgVector.add( avgValue );
			stdDevVector.add( computeStdDevOfVector(dataVector, avgValue));
		}
	}
	/** ** MEAN AND STD-DEV FUNCTION ** **/
	private double computeAvgOfVector(Map<Date, Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Iterator<Entry<Date, Double>> it = vector.entrySet().iterator();
			          it.hasNext(); ){

		        Entry<Date, Double> entry = it.next();
		        sum += entry.getValue();
			}
			double mean = sum / (double) vector.size();
			return mean;
		}
	}

	
	private double computeStdDevOfVector(Map<Date, Double> vector, double mean) {
		synchronized(vector) {
			double sum = 0;
			for(Iterator<Entry<Date, Double>> it = vector.entrySet().iterator();
			          it.hasNext(); ){

		        Entry<Date, Double> entry = it.next();
		    	sum += Math.pow( (entry.getValue() - mean), 2);
			}
			double stdDev = Math.sqrt( sum / (double) vector.size() );
			return stdDev;
		}
	}
	/** ** MEAN AND STD-DEV FUNCTION ** **/
	

	private void computeNewAvgAndStdDev(Vector<Double> dataVector, 
			Vector<Double> avgVector, 
			Vector<Double> stdDevVector) {
		synchronized(dataVector) {
			double avgValue = computeAvgOfVector(dataVector);
			avgVector.add( avgValue );
			stdDevVector.add( computeStdDevOfVector(dataVector, avgValue));
		}
	}
	/** ** MEAN AND STD-DEV FUNCTION ** **/
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = sum / (double) vector.size();
			return mean;
		}
	}


	private double computeStdDevOfVector(Vector<Double> vector, double mean) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += Math.pow( (d - mean), 2);
			double stdDev = Math.sqrt( sum / (double) vector.size() );
			return stdDev;
		}
	}
	/** ** MEAN AND STD-DEV FUNCTION ** **/
	
	/** PRIVATE FUNCTIONS **/
	
}
