package it.unipr.dsg.awm.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import Jama.Matrix;
import it.unipr.dsg.awm.AssignedRequest;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;
import it.unipr.dsg.matrix.CloudSystem;
import it.unipr.dsg.matrix.DsgMatrixUtils;

/**
 * This class implements the problem of Output Regulation of a system of the form
 * coded by the {@link CloudSystem} class.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class FrancisController extends Controller {

	private static String debug = "FRANCIS CONTROLLER - ";
	
	private CloudSystem system;
	
	private QoSModeler qos = QoSModeler.getInstance();
	private AssignedRequest assignedRequest = AssignedRequest.getInstance();
	private QueuedRequest queuedRequest = QueuedRequest.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();

	private int totRequest = 0;
	
	/***************/
	/**
	 * The constructor without parameters instantiate a system taking the parameters from the
	 * {@link TestParameters} class.
	 */
	public FrancisController(){
		this.system = new CloudSystem(testParam.getSamplingPeriod()*60, testParam.getTe(), testParam.getAlpha(),
				testParam.getBeta(), testParam.getGamma(), testParam.getDeltaR(), testParam.getM());
	}
	
	/** 
	 * @param alpha - The weight of an active VM in the system
	 * @param beta - The weight of a request not yet served
	 * @param gamma - The weight of activation or deactivation of a VM
	 * @param delta - The weight of a new physical server
	 * @param M - The maximum number of VM per server
	 * 
	 * alpha: 	peso in Mb del container docker?
	 * beta: 	scala decimale, quante richieste pendenti ho ? 
	 * gamma: 	...
	 * 	Sono parametri già impostati ? come faccio a capire come funzionano?
	 * I parametri sembrano settati secondo una logica esterna al progetto java.
	 */
	public FrancisController(double alpha, double beta, double gamma, double delta, double M) {
		this.system = new CloudSystem(testParam.getSamplingPeriod()*60, 2, alpha, beta, gamma, delta, M);
	}

	/**
	 * @param T - The sampling period
	 * @param Te - The estimated mean response time on the Cloud
	 * @param alpha - The weight of an active VM in the system
	 * @param beta - The weight of a request not yet served
	 * @param gamma - The weight of activation or deactivation of a VM
	 * @param delta - The weight of a new physical server
	 * @param M - The maximum number of VM per server
	 */
	public FrancisController(double T, double Te, double alpha, double beta, double gamma, double delta, double M) {

		this.system = new CloudSystem(T, Te, alpha, beta, gamma, delta, M);
	}
    /***************/

	/**
	 * This method solves the problem of Output Regulation.
	 * It, first, solves the Discrete-Time Algebraic Riccati Equation and then 
	 * solves the Output Regulation by means of the Francis-Byrnes-Isidori equations.
	 * 
	 * @return the number of Virtual Machine to allocate or deallocate.
	 */
	@Override
	public int nextVMDelta() {
		
		/**
		 * Implementato nuovo metodo per aggiornare -> Te 
		 */
		double Te = 0;
		Process p = null;
		String s;
		double a = 0;
		try {
			p = Runtime.getRuntime().exec("python "+"getAvgTime"+".py");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

        try {
        	// using the Runtime exec method:
            BufferedReader stdInput = new BufferedReader(new 
                 InputStreamReader(p.getInputStream()));

            BufferedReader stdError = new BufferedReader(new 
                 InputStreamReader(p.getErrorStream()));
            // read the output from the command
            while ((s = stdInput.readLine()) != null) {
            	a = Double.parseDouble(s);
            }
            // read any errors from the attempted command
            while ((s = stdError.readLine()) != null) {
            	System.out.println(s);
            }
        }
        catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
        }
        try {
			p.waitFor();
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}

		if (a != 0) {
			Te = a;
		}else Te = 0.001;
		
		this.system.setTe(Te);
		dataColl.addTeValue(this.system.getTe());
		
		double setPointMeasurement = qos.getQoSCurrentMeasurement();
		dataColl.addSetPointValue(setPointMeasurement);
		
		Matrix K = DsgMatrixUtils.dlqrPython(this.system.getT(), this.system.getTe(), this.system.getAlpha(), 
				this.system.getBeta(), this.system.getGamma(), this.system.getDelta(), this.system.getM());
		
//		Map<String, Matrix> dlqr = DsgMatrixUtils.dlqr(this.system.getA(), this.system.getB(), 
//				this.system.getQ(), this.system.getR());
		
		if(K == null){
			printDebug(debug + "Controller result is null...");
			return 0;
		}else{
		
			printDebug(debug + "Correctly calculated the Riccati gain matrix...");
			
			//int currentVMs = vmStack.getSize();
			// Avvio script per retrive number of running container
						Process p1 = null;
						try {
							p1 = Runtime.getRuntime().exec("python "+"getNumContainer"+".py");
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						s = "";
						int currentVMs = 0;	//default 0
				        try {
				        	// using the Runtime exec method:
				            BufferedReader stdInput = new BufferedReader(new 
				                 InputStreamReader(p1.getInputStream()));

				            BufferedReader stdError = new BufferedReader(new 
				                 InputStreamReader(p1.getErrorStream()));
				            // read the output from the command
				            while ((s = stdInput.readLine()) != null) {
				            	try {
				            		currentVMs = Integer.parseInt(s);
								} catch (Exception e) {
									System.err.println(e);
								}
				            }
				            
				            // read any errors from the attempted command
				            while ((s = stdError.readLine()) != null) {
				            	System.out.println(s);
				            }

				            
				        }
				        catch (IOException e) {
				            System.out.println("exception happened - here's what I know: ");
				            e.printStackTrace();
				        }
				        try {
							p1.waitFor();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
			int currentRequests = this.assignedRequest.getAssignedRequestSize() + 
					this.queuedRequest.getRequestQueueSize();
			
			//Fake currentRequest 
			currentRequests = this.totRequest;
			printDebug(debug + "currentVms: " + currentVMs + " currentRequests: " + currentRequests);
			printDebug(debug + "T: " + this.system.getT() + " Te: " + this.system.getTe());
			
			double[][] xk = new double[2][1];
			xk[0][0] = currentVMs;
			xk[1][0] = currentRequests;
			Matrix Xk = new Matrix(xk);
			
			double[][] etak = new double[1][1];
			etak[0][0] = this.totRequest;	// richieste in una finestra temporale infinita
			Matrix Etak = new Matrix(etak);
			//dataColl.addRequestsPerSample(etak[0][0]);
			
			printDebug(debug + "K1: " + K.get(0, 0) + "K2: " + K.get(0, 1));
			printDebug(debug + "etaK: " + etak[0][0]);
			
			Matrix Xkk = DsgMatrixUtils.francisRegulatorFeedback(this.system.getA(), this.system.getB(), 
					K, Xk, Etak, 
					this.system.getPigreco(), this.system.getLambda(), this.system.getPexosystem());
			
			int controllerResult = currentVMs;
			if(Xkk == null) printDebug(debug + "Francis equation returned null...");
			if(Xkk != null) controllerResult = (int) Math.ceil(Xkk.get(0, 0));
			
			controllerResult = super.checkVMLimits(controllerResult);
			
	    	printDebug(debug + "Controller Result is: " + controllerResult);
	    	printDebug(debug + "Next VM Delta is: " + (controllerResult - currentVMs));
			
			return (controllerResult - currentVMs);
		}
	}

	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}
	public void setRequest(int a ) {
		this.totRequest = a;
	}

	@Override
	public void resetVariables() {}

}
