package it.unipr.dsg.awm.controller;

import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RejectedExecutionException;

import com.mathworks.engine.EngineException;
import com.mathworks.engine.MatlabEngine;

import it.unipr.dsg.awm.AssignedRequest;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

/**
 * This class implements and solve the optimization problem described by the
 * model: <br>
 * minimize J = sum(i=0 to
 * n){alpha*p<sub>i</sub><sup>2</sup>+beta*r<sub>i</sub><sup>2</sup>+gamma*u<sub>i</sub><sup>2</sup>
 * +(delta/M<sup>2</sup>)*p<sub>i</sub><sup>2</sup>} <br>
 * subject to: <br>
 * p(k+1) == p(k) + u(k)<br>
 * r(k+1) == (-T/Te)*p(k+1) + r(k) + eta(k)<br>
 * 0<=p(k)<=Pmax <br>
 * r(k)>=0<br>
 * with p,u in N , r in R<br>
 * where:<br>
 * <ul>
 * <li>p is the number of active processes
 * <li>r is the number of requests not yet served
 * <li>u is the control <br>
 * <li>T - the sampling time in seconds (e.g. T=300 means a sampling time of 300
 * seconds)
 * <li>Te - the execution time of a task in the cloud
 * <li>alpha - weight associated to an active Virtual Machine in the system
 * <li>beta - weight associated to a request not yet served
 * <li>gamma - weight associated to the allocation or deallocation of a new
 * Virtual Machine
 * <li>delta - weight associated to the number of physical active servers
 * <li>M - max number of Virtual Machine for server
 * </ul>
 * 
 * 
 * @author Federico Torreggiani - August 2017
 *
 */

public class ModelPredictiveController extends Controller {

	private static String debug = "MODEL PREDICTIVE CONTROLLER - ";

	private double alpha = 0;
	private double beta = 0;
	private double gamma = 0;
	private double delta = 0;
	private double T = 0;
	private double Te = 0;

	private int Pmax = 0;
	private int M = 0;

	private int p_curr;
	private double r_curr;

	private int finiteFutureHorizon = 15;
	private int windowInMinutes = 15;

	private QoSModeler qos = QoSModeler.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private AssignedRequest assignedRequest = AssignedRequest.getInstance();
	private QueuedRequest queuedRequest = QueuedRequest.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();

	private String optimizationFunctionPath = "/opt/CloudAWM/MatLabCode/";

	/**
	 * The constructor without parameters instantiate the elements taking the
	 * parameters from the {@link TestParameters} class.
	 */
	public ModelPredictiveController() {

		setP_curr(vmStack.getSize());
		int currentRequests = /*this.assignedRequest.getAssignedRequestSize() + this.queuedRequest.getRequestQueueSize()
				+ */qos.getWindowedRequestsArrivals(testParam.getSamplingPeriod() * 60 * 1000);
		setR_curr(currentRequests);
		setFiniteFutureHorizon(testParam.getFutureFiniteHorizon());
		setAlpha(testParam.getAlphaMPC());
		setBeta(testParam.getBetaMPC());
		setGamma(testParam.getGammaMPC());
		setDelta(testParam.getDeltaMPC());
		setPmax(testParam.getMaxVM());
		setM((int) testParam.getMMPC());
		setT(testParam.getSamplingPeriod());
		setTe(testParam.getTeMPC());
	}

	/**
	 * constructor<br>
	 * 
	 * @param p_curr
	 *            - The current active VMs
	 * @param r_curr
	 *            - The current number of reqests to be served
	 * @param finiteHorizonSteps
	 *            - The finite future horizon for the optimization problem
	 *            evaluation
	 * @param alpha
	 *            - The weight of an active VM in the system
	 * @param beta
	 *            - The weight of a request not yet served
	 * @param gamma
	 *            - The weight of activation or deactivation of a VM
	 * @param delta
	 *            - The weight of a new physical server
	 * @param Pmax
	 *            - The maximum number of VM
	 * @param M
	 *            - The maximum number of VM per server
	 * @param T
	 *            - The smapling period
	 * @param Te
	 *            - The average response time
	 */
	public ModelPredictiveController(int p_curr, double r_curr, int finiteFutureHorizon, double alpha, double beta,
			double gamma, double delta, int Pmax, int M, double T, double Te) {

		setP_curr(p_curr);
		setR_curr(r_curr);
		setFiniteFutureHorizon(finiteFutureHorizon);
		setAlpha(alpha);
		setBeta(beta);
		setGamma(gamma);
		setDelta(delta);
		setPmax(Pmax);
		setM(M);
		setT(T);
		setTe(Te);

	}

	/**
	 * This method solves the optimization problem definied by the Model
	 * Predictive Control. It solves the optimization problem calling the MATLAB
	 * function {@code opitmizationF.m}
	 * 
	 * @return the number of Virtual Machine to allocate or deallocate.
	 */
	@Override
	public int nextVMDelta() {
		double u = 0;
		double elapsedTime = -1;

		setP_curr(this.vmStack.getSize());
//		setR_curr(this.assignedRequest.getAssignedRequestSize() + this.queuedRequest.getRequestQueueSize());
		setR_curr(qos.getWindowedRequestsArrivals(testParam.getSamplingPeriod() *60 *1000));
		dataColl.addP(this.p_curr);
		dataColl.addR(this.r_curr);

		if (this.alpha == 0 || this.beta == 0 || this.gamma == 0 || this.delta == 0 || this.finiteFutureHorizon == 0
				|| this.Pmax == 0 || this.M == 0 || this.T == 0) {
			printDebug(
					debug + " One or more of the input parameter results equals to 0 --> deltaVM will forced to 0 !\n");
			printMPCParameter();
			return 0;
		}

		setTe(this.qos.getAvgWindowedTimeOnCloud(this.windowInMinutes * 60 * 1000));
		if (this.Te == 0) {
			printDebug(debug + "Te is zero. Set Te to 0.001...");
			setTe(0.001);
		}
		dataColl.addTeValue(getTe());

		double setPointMeasurement = qos.getQoSCurrentMeasurement();
		dataColl.addSetPointValue(setPointMeasurement);

		printDebug(debug + "currentVms: " + this.p_curr + " currentRequests: " + this.r_curr);
		printDebug(debug + "T: " + this.T + " Te: " + this.Te);

		double[] x = new double[] { (double) this.p_curr, this.r_curr, (double) this.finiteFutureHorizon, this.alpha,
				this.beta, this.gamma, this.delta, (double) this.Pmax, (double) this.M, this.T, this.Te };

		try {
			MatlabEngine en = MatlabEngine.startMatlab();

			try {
				en.eval("addpath('" + optimizationFunctionPath + "')");
				Date start = new Date();
				u = en.feval("optimizationF", x);
				elapsedTime = (new Date().getTime() - start.getTime()); 
				en.eval("rmpath('" + optimizationFunctionPath + "')");
			} catch (RejectedExecutionException | ExecutionException e) {
				e.printStackTrace();
				System.out.println(debug + "ERROR: MATLAB function execution exception !");
			}

			en.close();
		} catch (EngineException | IllegalArgumentException | IllegalStateException | InterruptedException e) {
			e.printStackTrace();
			System.out.println(debug + "ERROR: MATLAB Engine exception !");
		}

		int nextVMdelta = 0;
		nextVMdelta = (int) u;

		printDebug(debug + "U --> " + u);
		printDebug(debug + "nextVMdelta --> " + nextVMdelta);

		printMPCParameter();

		int nextActiveVM = 0;
		nextActiveVM = this.p_curr + nextVMdelta;
		nextActiveVM = super.checkVMLimits(nextActiveVM);

		printDebug(debug + "The number of active VMs will be : " + nextActiveVM);
		printDebug(debug + "Next VM Delta is: " + (nextActiveVM - this.p_curr));
		
		//save evaluation time for the objective function
		dataColl.addMPCEvaluationTime(elapsedTime);
		System.out.println(debug + "Objective function compute time : " + elapsedTime);

		return (nextActiveVM - this.p_curr);
	}

	@Override
	public void resetVariables() {

	}

	private void printDebug(String s) {
		System.out.println(s);
		dataColl.addControllerString(s);
	}

	public int getP_curr() {
		return p_curr;
	}

	public void setP_curr(int p_curr) {
		this.p_curr = p_curr;
	}

	public double getR_curr() {
		return r_curr;
	}

	public void setR_curr(double r_curr) {
		this.r_curr = r_curr;
	}

	public int getFiniteFutureHorizon() {
		return finiteFutureHorizon;
	}

	public void setFiniteFutureHorizon(int finiteFutureHorizon) {
		this.finiteFutureHorizon = finiteFutureHorizon;
	}

	public double getAlpha() {
		return alpha;
	}

	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}

	public double getBeta() {
		return beta;
	}

	public void setBeta(double beta) {
		this.beta = beta;
	}

	public double getGamma() {
		return gamma;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public int getPmax() {
		return Pmax;
	}

	public void setPmax(int pmax) {
		Pmax = pmax;
	}

	public int getM() {
		return M;
	}

	public void setM(int m) {
		M = m;
	}

	public double getT() {
		return T;
	}

	public void setT(double t) {
		T = t * 60;
	}

	public double getTe() {
		return Te;
	}

	public void setTe(double te) {
		Te = te;
	}

	/** Print the Model Predictive Controller model input parameters */
	private void printMPCParameter() {
		System.out.println(debug + "\nInput parameters:\n" + "alpha : " + this.alpha + "\n" + "beta : " + this.beta
				+ "\n" + "gamma : " + this.gamma + "\n" + "delta : " + this.delta + "\n" + "maxVM : " + this.Pmax + "\n"
				+ "M : " + this.M + "\n" + "T : " + this.T + "\n" + "Finite Horizon window: " + this.finiteFutureHorizon
				+ "\n");
	}

}
