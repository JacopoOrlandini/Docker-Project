package it.unipr.dsg.awm.controller;

import java.util.Vector;

import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.openstack.OSFactory;

import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

/**
 * This class implements the algorithm proposed by Hasan et al. in <br>
 * <br>
 * Masum Z. Hasan, Edgar Magana, Alexander Clemm, Sree Lakshmi D. Gudreddi,
 * "Integrated and Autonomic Cloud Resource Scaling", 2012 IEEE/IFIP 3rd Workshop on 
 * Cloud Management (CloudMan)
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class QuadThresholdController extends Controller{

	private static String debug = "QUAD THRESHOLD CONTROLLER - ";
	
	private OSClientV3 demoUser;
	private int samplingPeriodInSeconds = 5 * 60;
	
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	private String OpenStackMetric;
	private double scaleUpThreshold;
	private double scaleDownThreshold;
	private double scaleUpPreThreshold;
	private double scaleDownPreThreshold;
	private double incrementPerc;
	private double decrementPerc;
	private int durationPeriodInIntervals;
	
	private int upStart = 0;
	private int upEnd = 0;
	private int middleStart = 0;
	private int middleEnd = 0;
	private int lowStart = 0;
	private int lowEnd = 0;
	private int durationUp = 0;
	private int durationMiddle = 0;
	private int durationLow = 0;
	
	private enum ScalingPolicies {SCALEUP, SCALEDOWN, SCALEMIDDLE, NOSCALE};
	private ScalingPolicies SCALE = ScalingPolicies.NOSCALE; 
	
	/**
	 * Initializes the parameters of the algoritmh taking them from the 
	 * {@link TestParameters} class.
	 */
	public QuadThresholdController() {
		
		Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");
		this.demoUser = OSFactory.builderV3()
				 .endpoint("http://160.78.27.68:5000/v3")
				 .credentials("demo","demo-pass" , domainIdentifier)
				 .scopeToProject(Identifier.byName("demo") , Identifier.byName("default"))
				 .authenticate();
		
		this.OpenStackMetric = testParam.getOpenstackMetric();
		this.scaleUpThreshold = testParam.getScaleUpThreshold();
		this.scaleDownThreshold = testParam.getScaleDownThreshold();
		this.scaleUpPreThreshold = testParam.getScaleUpPreThreshold();
		this.scaleDownPreThreshold = testParam.getScaleDownPreThreshold();
		this.incrementPerc = testParam.getIncrementPerc();
		this.decrementPerc = testParam.getDecrementPerc();
		this.durationPeriodInIntervals = testParam.getDurationPeriodInIntervals();
		this.samplingPeriodInSeconds = testParam.getSamplingPeriod() * 60;
		
//		printDebug(debug + " Up: " + scaleUpThreshold + " UpPre: " + scaleUpPreThreshold + 
//				" Down: " + scaleDownThreshold + " DownPre: "+ scaleDownPreThreshold + 
//				" Inc: " + incrementPerc + " Dec: " + decrementPerc);
	}

	/**
	 * Executes the algorithm
	 */
	@Override
	public int nextVMDelta() {
		
		Vector<Double> utils = super.getOpenStackPMT(this.demoUser, this.OpenStackMetric, this.samplingPeriodInSeconds);
		
		double mean_utils = computeAvgOfVector(utils);
		mean_utils = mean_utils / 100.0;
		dataColl.addOpenStackMetricMeasurementValue(mean_utils);
		
		printDebug(debug + "Num of avgs: " + utils.size() + " Avg: " + mean_utils);
		
		int nextVMDelta = 0;
		int currentVMs = vmStack.getSize();

		/** CISCO ALGORITHM **/
		nextVMDelta = 0;
		double PMT = mean_utils;

		if(PMT > this.scaleUpThreshold && this.upStart == 0) {
			this.upStart = 1;
			this.upEnd = 0;
			this.durationUp = 0;
		}
		if(this.upStart == 1){
			if(PMT > this.scaleUpPreThreshold) this.durationUp++;
			if(this.durationUp == this.durationPeriodInIntervals) this.upEnd = 1;
			if(PMT <= this.scaleUpPreThreshold){
				this.upStart = 0;
				this.durationUp = 0;
			}
		}
		//Scale Middle Behavior
		if(PMT < this.scaleUpPreThreshold && this.upEnd == 1 && this.middleStart == 0) {
			this.middleStart = 1;
			this.middleEnd = 0;
			this.durationMiddle = 0;
		}
		if(this.middleStart == 1){
			if(PMT <= this.scaleUpPreThreshold && PMT >= this.scaleDownPreThreshold) this.durationMiddle++;
			if(this.durationMiddle == this.durationPeriodInIntervals) this.middleEnd = 1;
			if(PMT > this.scaleUpPreThreshold || PMT < this.scaleDownPreThreshold){
				this.middleStart = 0;
				this.durationMiddle = 0;
			}
		}
		//Scale Down Behavior
		if(PMT < this.scaleDownThreshold && this.lowStart == 0) {
			this.lowStart = 1;
			this.lowEnd = 0;
			this.durationLow = 0;
		}
		if(this.lowStart == 1){
			if(PMT < this.scaleDownPreThreshold) this.durationLow++;
			if(this.durationLow == this.durationPeriodInIntervals) this.lowEnd = 1;
			if(PMT >= this.scaleDownPreThreshold){
				this.lowStart = 0;
				this.durationLow = 0;
			}
		}
		//Scale Decision
		if(this.upStart == 1 && this.upEnd == 1){
			this.SCALE = ScalingPolicies.SCALEUP;
			upStart = 0;
		}
		if(this.middleStart == 1 && this.middleEnd == 1){
			this.SCALE = ScalingPolicies.SCALEMIDDLE;
			middleStart = 0;
		}
		if(this.lowStart == 1 && this.lowEnd == 1){
			this.SCALE = ScalingPolicies.SCALEDOWN;
			lowStart = 0;
		}
		//Calc Delta
		printDebug(debug + "PMT: " + PMT + " Scale Action: " + getPrintableScalingPolicies(this.SCALE));
		printDebug(debug + "UpStart: " + upStart + " MiddleStart: " + middleStart + " lowStart: " + lowStart);
		printDebug(debug + "UpStart: " + upEnd + " MiddleEnd: " + middleEnd + " lowEnd: " + lowEnd);
		printDebug(debug + "DurationUp: " + durationUp + " DurationMiddle: " + durationMiddle + " DurationLow: " + durationLow +
				" DurationInIntervals: " + durationPeriodInIntervals);
		if(this.SCALE.equals(ScalingPolicies.SCALEUP)){
			printDebug(debug + "SCALEUP - CurrentVMs: " + currentVMs + " IncrementPerc: " + this.incrementPerc +
					" Result: " + currentVMs * this.incrementPerc + " Ceil: " + Math.ceil(currentVMs * this.incrementPerc));
			nextVMDelta = (int) Math.ceil(currentVMs * this.incrementPerc);
			this.SCALE = ScalingPolicies.NOSCALE;
		}
		if(this.SCALE.equals(ScalingPolicies.SCALEDOWN)){
			printDebug(debug + "SCALEDOWN - CurrentVMs: " + currentVMs + " DecrementPerc: " + this.decrementPerc +
					" Result: " + currentVMs * this.decrementPerc + " Ceil: " + Math.ceil(currentVMs * this.decrementPerc));
			nextVMDelta = -(int) Math.ceil(currentVMs * this.decrementPerc);
			this.SCALE = ScalingPolicies.NOSCALE;
		}
		if(this.SCALE.equals(ScalingPolicies.SCALEMIDDLE)){
			printDebug(debug + "SCALEMIDDLE - CurrentVMs: " + currentVMs + " DecrementPerc: " + this.decrementPerc +
					" Result: " + currentVMs * this.decrementPerc + " Ceil: " + Math.ceil(currentVMs * this.decrementPerc));
			nextVMDelta = -(int) Math.ceil((currentVMs * this.decrementPerc)/2.0);
			this.SCALE = ScalingPolicies.NOSCALE;
		}
		printDebug(debug + "nextVMDelta: " + nextVMDelta);
		/** CISCO ALGORITHM **/
		
		int futureVMs = nextVMDelta + currentVMs;
		futureVMs = super.checkVMLimits(futureVMs);
		
    	printDebug(debug + "Controller Result is: " + futureVMs);
    	printDebug(debug + "Next VM Delta is: " + (futureVMs - currentVMs));
    	
    	/*parameters needed for the evaluation of a cost function defined in {@link Model Predictive Controller}*/ 
    	dataColl.addP(vmStack.getSize());
    	dataColl.addR(QoSModeler.getInstance().getWindowedRequestsArrivals(testParam.getSamplingPeriod() *60 *1000));
		
		return (futureVMs - currentVMs);
	}
	
	
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = 0;
			if(vector.size() > 0) mean = sum / (double) vector.size();
			return mean;
		}
	}
	
	private String getPrintableScalingPolicies(ScalingPolicies sp){
		switch(sp){
		case NOSCALE: return "NO SCALE";
		case SCALEUP: return "SCALE UP";
		case SCALEDOWN: return "SCALE DOWN";
		case SCALEMIDDLE: return "SCALE MIDDLE";
		}
		return "";
	}
	
//	public static void main (String[] args){
//		
//		ArrayList<Double> pmt = new ArrayList<Double>();
//		try {
//			for (String line : Files.readAllLines(Paths.get("data/datiQuad"))) {
//				pmt.add(Double.parseDouble(line));
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		double scaleUpThreshold = 0.7;
//		double scaleUpPreThreshold = 0.6;
//		double scaleDownThreshold = 0.3;
//		double scaleDownPreThreshold = 0.4;
//		int upStart = 0;
//		int upEnd = 0;
//		int middleStart = 0;
//		int middleEnd = 0;
//		int lowStart = 0;
//		int lowEnd = 0;
//		int durationUp = 0;
//		int durationMiddle = 0;
//		int durationLow = 0;
//		int durationPeriodInIntervals = 3;
//		ScalingPolicies SCALE = ScalingPolicies.NOSCALE;
//		double nextVMDelta = 0;
//		double incrementPerc = 0.5;
//		double decrementPerc = 0.4;
//		double currentVMs = 1.0;
//		
//		for(Double PMT : pmt){
//			nextVMDelta = 0;
//			/** CISCO ALGORITHM **/
//			if(PMT > scaleUpThreshold && upStart == 0) {
//				upStart = 1;
//				upEnd = 0;
//				durationUp = 0;
//			}
//			if(upStart == 1){
//				if(PMT > scaleUpPreThreshold) durationUp++;
//				if(durationUp == durationPeriodInIntervals) upEnd = 1;
//				if(PMT <= scaleUpPreThreshold){
//					upStart = 0;
//					durationUp = 0;
//				}
//			}
//			//Scale Middle Behavior
//			if(PMT < scaleUpPreThreshold && upEnd == 1 && middleStart == 0) {
//				middleStart = 1;
//				middleEnd = 0;
//				durationMiddle = 0;
//			}
//			if(middleStart == 1){
//				if(PMT <= scaleUpPreThreshold && PMT >= scaleDownPreThreshold) durationMiddle++;
//				if(durationMiddle == durationPeriodInIntervals) middleEnd = 1;
//				if(PMT > scaleUpPreThreshold || PMT < scaleDownPreThreshold){
//					middleStart = 0;
//					durationMiddle = 0;
//				}
//			}
//			//Scale Down Behavior
//			if(PMT < scaleDownThreshold && lowStart == 0) {
//				lowStart = 1;
//				lowEnd = 0;
//				durationLow = 0;
//			}
//			if(lowStart == 1){
//				if(PMT < scaleDownPreThreshold) durationLow++;
//				if(durationLow == durationPeriodInIntervals) lowEnd = 1;
//				if(PMT >= scaleDownPreThreshold){
//					lowStart = 0;
//					durationLow = 0;
//				}
//			}
//			//Scale Decision
//			if(upStart == 1 && upEnd == 1){
//				SCALE = ScalingPolicies.SCALEUP;
//				upStart = 0;
//			}
//			if(middleStart == 1 && middleEnd == 1){
//				SCALE = ScalingPolicies.SCALEMIDDLE;
//				middleStart = 0;
//			}
//			if(lowStart == 1 && lowEnd == 1){
//				SCALE = ScalingPolicies.SCALEDOWN;
//				lowStart = 0;
//			}
//
//			System.out.print(debug + "PMT: " + PMT + " Scale Action: " + 
//					new QuadThresholdController().getPrintableScalingPolicies(SCALE)); 
////			System.out.println(debug + "UpStart: " + upStart + " MiddleStart: " + middleStart + " lowStart: " + lowStart);
////			System.out.println(debug + "UpEnd: " + upEnd + " MiddleEnd: " + middleEnd + " lowEnd: " + lowEnd);
////			System.out.println(debug + "DurationUp: " + durationUp + " DurationMiddle: " + durationMiddle + " DurationLow: " + durationLow +
////					" DurationInIntervals: " + durationPeriodInIntervals);
//			//Calc Delta
//			if(SCALE.equals(ScalingPolicies.SCALEUP)){
//				nextVMDelta = (int) Math.ceil(currentVMs * incrementPerc);
//				SCALE = ScalingPolicies.NOSCALE;
//			}
//			if(SCALE.equals(ScalingPolicies.SCALEDOWN)){
//				nextVMDelta = -(int) Math.ceil(currentVMs * decrementPerc);
//				SCALE = ScalingPolicies.NOSCALE;
//			}
//			if(SCALE.equals(ScalingPolicies.SCALEMIDDLE)){
//				nextVMDelta = -(int) Math.ceil((currentVMs * incrementPerc)/2.0);
//				SCALE = ScalingPolicies.NOSCALE;
//			}
//			
//			System.out.println(" nextVMDelta: " + nextVMDelta);
//			/** CISCO ALGORITHM **/
//
//		}
//	}
	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}
	
	/**
	 * Resets the variables of the algorithm
	 */
	@Override
	public void resetVariables() {
		this.upStart = 0;
		this.upEnd = 0;
		this.middleStart = 0;
		this.middleEnd = 0;
		this.lowStart = 0;
		this.lowEnd = 0;
		this.durationUp = 0;
		this.durationMiddle = 0;
		this.durationLow = 0;
	}

}
