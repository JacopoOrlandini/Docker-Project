package it.unipr.dsg.awm.controller;

import java.util.Date;
import java.util.List;
import java.util.Vector;

//import org.openstack4j.api.OSClient;
import org.openstack4j.api.OSClient.OSClientV3;
//import org.openstack4j.model.telemetry.Meter;
import org.openstack4j.model.telemetry.SampleCriteria;
import org.openstack4j.model.telemetry.Statistics;

import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

/**
 * This class reprensent an abstract controller. The unique method that a
 * Controller have to override is the method {@link #nextVMDelta()} that returns
 * the number of virtual machine to add or remove.
 * 
 * @author Valter Venusti - December 2015
 * @author modified by Federico Torreggiani 2017
 *
 */
public abstract class Controller {

	private static String debug = "ABSTRACT CONTROLLER - ";

	private TestParameters testParam = TestParameters.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();

	/**
	 * Checks that the number of virtual machine passed as parameter doesn't
	 * exceed the minimum and the maximum limit.
	 * 
	 * @param futureVMs
	 *            the number of virtual machine to check
	 * @return the correct number of virtual machine.
	 */
	public int checkVMLimits(int futureVMs) {
		if (futureVMs > testParam.getMaxVM()) {
			printDebug(debug + "WARNING: Forced kCurrent (" + futureVMs + ") to k_max!!");
			futureVMs = testParam.getMaxVM();
		} else if (futureVMs < testParam.getMinVM()) {
			printDebug(debug + "WARNING: Forced kCurrent (" + futureVMs + ") to k_min!!");
			futureVMs = testParam.getMinVM();
		}
		return futureVMs;
	}

	public Vector<Double> getOpenStackPMT(OSClientV3 demoUser, String OpenStackMetric, int samplingPeriodInSeconds) {

		Vector<Double> utils = new Vector<Double>();

		Date d = new Date();

		for (VirtualMachine vm : this.vmStack.getAllVMs()) {

			SampleCriteria criteria = new SampleCriteria();
			// criteria.resource(vm.getOpenStackVM().getId());
			criteria = SampleCriteria.create().resource(vm.getOpenStackVM().getId());

			// debug
			System.out.println(debug + "VMId  " + vm.getOpenStackVM().getId());
			//
			List<? extends Statistics> stats_temp = null;
			boolean flag = true;
			while (flag) {

				stats_temp = demoUser.telemetry().meters().statistics(OpenStackMetric, criteria,
						samplingPeriodInSeconds);

				if (stats_temp.size() == 0) {
					System.out.println(debug + "Stats_temp size  " + stats_temp.size() + " -> waiting 5 minutes ");
					try {
						Thread.sleep(300000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} else {
					System.out.println(debug + "Stats_temp size  " + stats_temp.size() + " -> go through ! ");
					flag = false;
				}
			}

			// debug
			// List<? extends Statistics> stat_debug =
			// demoUser.telemetry().meters().statistics(OpenStackMetric ,
			// criteria);
			// List<? extends Statistics> stat_debug_period =
			// demoUser.telemetry().meters().statistics(OpenStackMetric ,
			// samplingPeriodInSeconds);
			// System.out.println(debug + "debug_list_criteria " + stat_debug);
			// System.out.println(debug + "debug_list_size " +
			// stat_debug.size());
			// System.out.println(debug + "debug_list_period " +
			// stat_debug_period);
			// System.out.println(debug + "debug_list_period_size " +
			// stat_debug_period.size());
			//

			// debug
			// System.out.println(debug + "OpenstackMetric " + OpenStackMetric);
			// System.out.println(debug + "criteria " + criteria);
			// System.out.println(debug + "SamplingPeriod " +
			// samplingPeriodInSeconds);
			//

			printDebug(debug + "VM: " + vm.getMyIP() + " num_total_stats: " + stats_temp.size());

			int counter = 0;
			for (Statistics s : stats_temp) {
				printDebug(debug + "Now: " + d + " Start: " + new Date(d.getTime() - samplingPeriodInSeconds * 1000));
				printDebug(debug + "PeriodStart: " + s.getPeriodStart() + " PeriodEnd: " + s.getPeriodEnd());
				printDebug(debug + "DurationStart: " + s.getDurationStart() + " DurationEnd: " + s.getDurationEnd());
				printDebug(debug + "CountStatistics: " + s.getCount());
				if (s.getPeriodEnd().after(new Date(d.getTime() - samplingPeriodInSeconds * 1000))) {
					utils.add(s.getAvg());
					counter++;
				}
			}
			printDebug(debug + "VM: " + vm.getMyIP() + " num_period_stats: " + counter);

			if (counter == 0) {
				printDebug(debug + "No stats in the period. Getting the last one received...");
				utils.add(stats_temp.get(stats_temp.size() - 1).getAvg());
			}
		}

		return utils;
	}

	public abstract int nextVMDelta();

	public abstract void resetVariables();

	private void printDebug(String s) {
		System.out.println(s);
		dataColl.addControllerString(s);
	}

}
