package it.unipr.dsg.awm.virtualmachine;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.Map.Entry;

import org.openstack4j.model.compute.Server;

import it.unipr.dsg.awm.AppRequestInfo;

/**
 * The description of a Virtual Machine in the system.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */

public class VirtualMachine {
	
	private Server openStackVM = null;
	private String serverId = null;
	private String myIP = null;
	private Map<String, Integer> portServices = null;
	private Map<String, AppStatus> appStatus = null;
	private Status myStatus = null;
	private Vector<AppRequestInfo> myRequest = new Vector<AppRequestInfo>();
	
	/**
	 * The status of a Virtual Machine. It can be CREATION, ACTIVE, DESTRUCTION, INTERRUPT.
	 * 
	 * @author Marco Magnani - March 2015
	 */
	public enum Status { 
		CREATION,	// Fase di creazione della VM
		ACTIVE,		// Fase in cui la VM è attiva/operativa
		DESTRUCTION,	// Fase in cui la VM è stata segnalata per essere distrutta
		INTERRUPT // La VM non risulta raggiungibile dal CheckUp Server
	}
	
	/**
	 * The status of a single application. IDLE or BUSY.
	 * @author Valter Venusti - December 2015
	 */
	public enum AppStatus {
		IDLE,
		BUSY
	}
	
	/**
	 * The constructor needs the OpenStack Server object to initialize a Virtual Machine.
	 * @param server - The OpenStack Server object
	 */
	public VirtualMachine(Server server) {
		this.openStackVM = server;
		this.setServerId(server.getId());
		//this.myIP = server.getAddresses().getAddresses("demo-net").get(0).getAddr();
		this.portServices = new HashMap<String, Integer>();
		this.appStatus = new HashMap<String, AppStatus>();
		this.myStatus = Status.CREATION;
	}
	
	/**
	 * @return The IP address of the Virtual Machine
	 */
	public String getMyIP() {
		return this.myIP;
	}
	
	/**
	 * Sets the IP address of a Virtual Machine taking it from the OpenStack Server object.
	 */
	public void setMyIP() {
		this.myIP = this.openStackVM.getAddresses().getAddresses("provider").get(0).getAddr();
	}
	
	/**
	 * Sets the OpenStack Server object.
	 * @param server - The OpenStack Server object.
	 */
	public void setOpenStackVM(Server server){
		this.openStackVM = server;
		this.serverId = server.getId();
	}

	/**
	 * Adds a service in the Virtual Machine.
	 * @param appName - The name with which the service is registered
	 * @param port - The port on which the service is listening
	 * @return True if success
	 */
	public boolean addService(String appName, int port){
			
		this.portServices.put(appName, port);
		this.appStatus.put(appName, AppStatus.IDLE);
		
		return true;
	}

	/**
	 * Removes a service from the Virtual Machine.
	 * @param appName - The name with which the service is registered
	 * @return True if success
	 */	
	public boolean removeService(String appName){
		
		this.portServices.remove(appName);
		this.appStatus.remove(appName);
		
		if(this.portServices.containsKey(appName)) return false;
		
		return true;
	}
	
	/**
	 * Set the status of an Application
	 * @param appName - The name with which the service is registered
	 * @param status - The new status
	 */
	public void setAppStatus(String appName, VirtualMachine.AppStatus status){
		
		this.appStatus.put(appName, status);
	}
	
	/**
	 * Returns the status of an application
	 * @param appName - The name with which the service is registered
	 * @return the status of the application
	 */
	public AppStatus getAppStatus(String appName){
		
		return this.appStatus.get(appName);
	}
	
	/**
	 * Returns a status in a printable format
	 * @param s - The status
	 * @return the status in printable format
	 */
	public String getPrintableStatus(AppStatus s){
		switch(s){
		case IDLE: return "Idle";
		case BUSY: return "Busy";
		}
		return "";
	}
	
	/**
	 * Check if the Virtual Machine contains a specified service
	 * @param appName - The name with which the service is registered
	 * @return True if the VM contains the service
	 */
	public boolean hasService(String appName){
		
		return this.portServices.containsKey(appName);
	}
	
	/**
	 * Print on standard output all the services presents on the Virtual Machine.
	 */
	public void printServices(){
		
		System.out.println("Services on VM " + this.myIP);
        for(Iterator<Entry<String, Integer>> it = this.portServices.entrySet().iterator();
                it.hasNext(); ){

              Entry<String, Integer> entry = it.next();
              System.out.println(" - " + entry.getKey() + ":" + entry.getValue());
            }
	}
	
	/**
	 * Returns all the services presents on a Virtual Machine in printable format.
	 * @return A string of one line.
	 */
	public String getServicesAsInlineString(){
        String result = "";
		for(Iterator<Entry<String, AppStatus>> it = this.appStatus.entrySet().iterator();
                it.hasNext(); ){

              Entry<String, AppStatus> entry = it.next();
              result += entry.getKey() + "(" + getPrintableStatus(entry.getValue()) + ");";
            }

        return result;
	}
	
	/**
	 * Returns the listening port of an application.
	 * @param appName - The name with which the service is registered
	 * @return the listening port as integer value
	 */
	public int getAppPort(String appName){
		
		return this.portServices.get(appName);
	}

	/**
	 * Adds a request to the queue of assigned requests of the Virtual Machine
	 * @param request - The request to add
	 */
	public void addRequest(AppRequestInfo request) {
		synchronized(myRequest) {
			myRequest.add(request);
		}
	}
	
	/**
	 * Removes a specified request from the queue of assigned request.
	 * @param request - The request to remove
	 */
	public  void removeRequest(AppRequestInfo request) {
		synchronized(myRequest) {
			for(int i=0; i<myRequest.size(); i++) {
				if( myRequest.get(i).getId() == request.getId() )
					myRequest.remove(i);
			}
		}
	} 

	/**
	 * Returns the number of requests assigned to the Virtual Machine
	 * @return int
	 */
	public int getRequestQueueSize() {
		synchronized(myRequest) {
			return myRequest.size();
		}
	} 
	
	/**
	 * Returns a specified request.
	 * @param index - The index of the request in the request's vector of the Virtual Machine.
	 * @return an {@link AppRequestInfo} object
	 */
	public AppRequestInfo getRequestByIndex(int index) {
		synchronized(myRequest) {
			return myRequest.get(index);
		}
	}
	
	/**
	 * Returns the Virtual Machine status
	 * @return the status of the Virtual Machine
	 */
	public Status getVMStatus() {
		synchronized(myStatus) {
			return myStatus;
		}
	}
	
	/**
	 * Sets the Virtual Machine status
	 * @param s - the new Virtual Machine status
	 */
	public void setVMStatus(Status s) {
		synchronized(myStatus) {
			myStatus = s;
		}
	}

	/**
	 * @return the OpenStack Server object
	 */
	public Server getOpenStackVM() { return this.openStackVM; }

	/**
	 * @return the OpenStack Server ID
	 */
	public String getServerId() {
		return serverId;
	}

	/**
	 * Changes the OpenStack Server id
	 * @param serverId - the new ID
	 */
	public void setServerId(String serverId) {
		this.serverId = serverId;
	}
	
} // public class VirtualMachine
