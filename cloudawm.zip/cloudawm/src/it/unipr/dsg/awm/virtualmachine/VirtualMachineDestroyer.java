package it.unipr.dsg.awm.virtualmachine;

import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.model.common.ActionResponse;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.openstack.OSFactory;

import it.unipr.dsg.log.DataCollector;

/**
 * This class has the duty of destroying a specified Virtual Machine
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @modified by Federico Torreggiani 2017
 *
 */
public class VirtualMachineDestroyer extends Thread {
	private static String debug = "VIRTUAL_MACHINE_DESTROYER - ";
	
	private OSClientV3 demoUser;
	private VirtualMachine vmToBeDestroyed;
	private String vmIPv4 = "";
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	/**
	 * Acquires the Virtual Machine to destroy
	 * @param vm - The Virtual Machine to destroy
	 */
	public VirtualMachineDestroyer(VirtualMachine vm) {
		vmToBeDestroyed = vm;
		this.vmIPv4 = vm.getMyIP();
		//this.vmIPv4 = vm.getOpenStackVM().getAddresses().getAddresses("demo-net").get(0).getAddr();
	}
	
	/**
	 * Contact OpenStack API and destroy the VM.
	 * Naturally waits until the VM has served all the requests assigned to her.
	 */
	public void run() {
		long start = System.nanoTime();
		Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");
		this.demoUser = OSFactory.builderV3()
								 .endpoint("http://160.78.27.68:5000/v3")
								 .credentials("demo","demo-pass" , domainIdentifier)
								 .scopeToProject(Identifier.byName("demo") , Identifier.byName("default"))
								 .authenticate();
		System.out.println(debug + "Connesso come 'demo' = " + demoUser.toString());
		
		System.out.println(debug + "Check if VM (" + vmIPv4 + ") have a empty request queue...");
		
		boolean emptyQueue = false;
		do {
			if( vmToBeDestroyed.getRequestQueueSize() > 0 ) {
				emptyQueue = false;
				try {
					Thread.sleep(60 * 1000);
				} catch (InterruptedException e) { e.printStackTrace(); }
			} else emptyQueue = true;	
		} while( !emptyQueue );
			
		ActionResponse resultDeleteServer = demoUser.compute().servers().delete(vmToBeDestroyed.getOpenStackVM().getId());
		if( !resultDeleteServer.isSuccess() ) {
			System.err.println(debug + "Error: " + resultDeleteServer.getFault());
		} else {
			if( vmStack.removeVMByIP(vmIPv4) ){
				System.out.println(debug + "VMs " + vmIPv4 + " correttamente distrutta!!");
		    	
				long end = System.nanoTime();
		    	double elapsedTimeInSecond = (double) (end - start) / 1000000000.0;
		    	dataColl.addVMDeAllocationTime(elapsedTimeInSecond);
			}else{
				System.err.println(debug + "Error occurred during destruction of VM (" + vmIPv4 + ")");
			}
		} 		
		
	}

}
