package it.unipr.dsg.awm.virtualmachine;

import java.util.Comparator;

/**
 * Class used during the operation of sorting the collection of Virtual Machine executed by {@link VirtualMachineStack} class.
 * 
 * @author Marco Magnani - December 2015
 *
 */
public class VirtualMachineComparator implements Comparator<VirtualMachine> {

	/**
	 * Put the Virtual Machines in ascending order of assigned requests.
	 */
	@Override
	public int compare(VirtualMachine vm1, VirtualMachine vm2) {
		int vm1Size = vm1.getRequestQueueSize();
		int vm2Size = vm2.getRequestQueueSize();
		return vm1Size-vm2Size;
	}
	
}
