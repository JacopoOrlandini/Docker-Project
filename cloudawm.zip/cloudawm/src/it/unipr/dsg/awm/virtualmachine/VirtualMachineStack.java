package it.unipr.dsg.awm.virtualmachine;

import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

import it.unipr.dsg.log.TestParameters;

/**
 * This class is a Singleton object with the duty of maintain the information necessary for the management of
 * the Virtual Machines in the Cloud. 
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @author Federico Torreggiani - 2017
 *
 */
public class VirtualMachineStack {
	private static String debug = "VIRTUAL_MACHINE_STACK - ";
	private Vector<VirtualMachine> vmStack = new  Vector<VirtualMachine>();
	
	//private int minVM = 1;
	
	/** SINGLETON STUFF **/
	private static VirtualMachineStack instance = null;

	private VirtualMachineStack() {}
	
	public static synchronized VirtualMachineStack getInstance() {
		if(instance == null)
			instance = new VirtualMachineStack();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/
	
	/** PUBLIC FUNCTIONS **/
	
	/** ** GETTING FUNCTIONS ** **/
	/**
	 * @return All the Virtual Machines in the Cloud
	 */
	public Vector<VirtualMachine> getAllVMs(){ return this.vmStack; }
	
	/**
	 * @return The number of Virtual Machines in the Cloud
	 */
	public int getSize() {
		synchronized(vmStack) {
			return vmStack.size();
		}
	}
	
	/**
	 * @param index - The index of the Virtual Machine within the VM vector
	 * @return The Virtual Machine in the specified location
	 */
	public VirtualMachine getVMByIndex(int index) {
		synchronized(vmStack) {
			return vmStack.get(index);
		}
	}
	
	/**
	 * @param ip - The IP address of the Virtual Machine
	 * @return The Virtual Machine with the passed IP address
	 */
    public VirtualMachine getVMByIP(String ip) {
    	synchronized(vmStack) {
	    	for(int i=0; i<vmStack.size(); i++)
	    		if( vmStack.get(i).getMyIP() != null && vmStack.get(i).getMyIP().equalsIgnoreCase(ip) )
	    			return vmStack.get(i);
			return null;
    	}
    } 
    
    /**
     * @param serverId - The ID of the OpenStack Server object
     * @return The Virtual Machine with the specified ID
     */
    public VirtualMachine getVMByID(String serverId){
    	synchronized(vmStack) {
	    	for(int i=0; i<vmStack.size(); i++)
	    		if( vmStack.get(i).getServerId().equals(serverId) )
	    			return vmStack.get(i);
			return null;
    	}    	
    }
    
    /**
     * Returns the VM with less requests assigned
     * @return VirtualMachine object
     */
    public VirtualMachine getVMWithLessRequest() {
    	synchronized(vmStack) {
    		System.out.println(debug + "\n\tgetVMWithLessRequest() {..}"
    				+ "\n\t------> vmStack.size() = " + vmStack.size());
    		if(vmStack.size() == 1)
    			return vmStack.get(0);
    		
    		int minRequestQueueSize = Integer.MAX_VALUE;
    		VirtualMachine result = null;
    		for(int i=0; i<vmStack.size(); i++) {
    			System.out.println(debug  + "vmStack.get("+i+").getVMStatus() = " + vmStack.get(i).getVMStatus());
    			if( vmStack.get(i).getVMStatus() == VirtualMachine.Status.ACTIVE &&
    					vmStack.get(i).getRequestQueueSize() < minRequestQueueSize ) {
    				result = vmStack.get(i);
    				minRequestQueueSize = result.getRequestQueueSize();
    			}
    		}
    		return result;
    	}
    } // getVMWithLessRequest() {..}

    /**
     * Returns the VM with more requests assigned
     * @return VirtualMachine object
     */
    public VirtualMachine getVMWithMoreRequest() {
    	synchronized(vmStack) {
    		System.out.println(debug + "\n\tgetVMWithLessRequest() {..}"
    				+ "\n\t------> vmStack.size() = " + vmStack.size());
    		if(vmStack.size() == 1)
    			return vmStack.get(0);
    		
    		int maxRequestQueueSize = -1;
    		VirtualMachine result = null;
    		for(int i=0; i<vmStack.size(); i++) {
    			System.out.println(debug  + "vmStack.get("+i+").getVMStatus() = " + vmStack.get(i).getVMStatus());
    			if( vmStack.get(i).getVMStatus() == VirtualMachine.Status.ACTIVE &&
    					vmStack.get(i).getRequestQueueSize() > maxRequestQueueSize ) {
    				result = vmStack.get(i);
    				maxRequestQueueSize = result.getRequestQueueSize();
    			}
    		}
    		return result;
    	}
    } // getVMWithMoreRequest() {..}

//    //Versione 0.1 - MAGNANI
//    public double getAvgMaxTimeTaskWaiting() {
//    	synchronized(vmStack) {
//    		int activeVM = 0;
//    		double tmpMaxTimeTaskWaiting = 0;
//    		System.out.println(debug + "\n\tupdateAvgMaxTimeTaskWaiting(){..}" + 
//        							   "\n\t--- vmStack.size() = " + vmStack.size());
//        	for(int i=0; i<vmStack.size(); i++) {
//        		VirtualMachine vm = vmStack.get(i);
//        		if(vm.getVMStatus() == VirtualMachine.Status.ACTIVE) {
//        			activeVM++;
//    	    		System.out.println("\t--- " + vm.getMyIP() + " vm.getReqeustQueueSize() = " + vm.getRequestQueueSize());
//    	    		for(int j=0; j<vm.getRequestQueueSize(); j++)
//    	    			tmpMaxTimeTaskWaiting += vm.getRequestByIndex(j).getElabTimeEstimation();
//        		} // if(.. == ACTIVE) {..}
//        	} // for(..) {..}
//        	double avgMaxTimeTaskWaiting = tmpMaxTimeTaskWaiting / (double) activeVM;
//        	return avgMaxTimeTaskWaiting;
//    	}
//    } // getAvgMaxTimeTaskWaiting() {..}

    /**
     * @return The number of Virtual Machines in ACTIVE state
     */
    public int getNumOfActiveVM() {
    	synchronized(vmStack) {
    		int activeVM = 0;
    		for(Iterator<VirtualMachine> iteratorVM = vmStack.iterator(); iteratorVM.hasNext();) {
    			if( iteratorVM.next().getVMStatus() == VirtualMachine.Status.ACTIVE )
    				activeVM++;
    		}
    		return activeVM;
    	}
    } 
    
    /**
     * @return The number of Virtual Machines in DESTRUCTION state
     */
    public int getNumOfDestructionVM() {
    	synchronized(vmStack) {
    		int destructionVM = 0;
    		for(VirtualMachine vm : vmStack) {
    			if( VirtualMachine.Status.DESTRUCTION.equals(vm.getVMStatus()) )
    				destructionVM++;
    		}
    		return destructionVM;
    	}
    }
    /** ** GETTING FUNCTIONS ** **/
    
    /**
     * Add a Vm to the Stack
     * @param vm - The VM to add
     * @return True if success, false if the stack is full
     */
    public boolean addVM(VirtualMachine vm) {
		synchronized(vmStack) {
			if(vmStack.size() < TestParameters.getInstance().getMaxVM()) {
				vmStack.addElement(vm);
				return true;
			} else return false;
		}
	} 
    
    /**
     * Removes a Virtual Machine with the specified IP address
     * @param ip - the IP address of the Virtual Machine to remove
     * @return true if success, false otherwise
     */
	public boolean removeVMByIP(String ip) {
		if(ip.equals("")) return false;
		
		synchronized(vmStack) {
			System.out.println(debug + "--- removeVMByIP(" + ip + "){..}");
//			if(vmStack.size() > minVM) {
				System.out.println("\tvmStack.size() = " + vmStack.size());
				for(int i=0; i<vmStack.size(); i++) {
					System.out.println("\t" + vmStack.get(i).getMyIP());
		    		if( vmStack.get(i).getMyIP().equalsIgnoreCase(ip) ) {
		    			System.out.println("\t -------> REMOVED " + vmStack.get(i).getMyIP());
		    			vmStack.remove(i);
		    			return true;
		    		}
				}
				return false;
//			} else return false;
		}
	} 
	
	/**
	 * Gets the Virtual Machines in which there is the application with name "appName" and orders them
	 * in ascending order of assigned requests. Then take the first VM.
	 * @param appName - The Application Name
	 * @return The Virtual Machine with less requests in which the application "appName" is registered
	 */
	//Versione 1.0 - VENUSTI
	public VirtualMachine ascendingSortAndTakeVM(String appName) {
		synchronized(vmStack) {
			System.out.println(debug + "\n\tascendingSortAndTakeVM(" + appName + ") {..}"
									 + "\n\t------> vmStack.size() = " + vmStack.size());
			
			if(vmStack.size() == 1){
				//vmStack.get(0).printServices();
				if(vmStack.get(0).hasService(appName) && 
						vmStack.get(0).getAppStatus(appName).equals(VirtualMachine.AppStatus.IDLE)) return vmStack.get(0);
				else return null;
			}
			
			if(vmStack.size() == 0)
				return null;
			
	    	Vector<VirtualMachine> activeVM = new Vector<VirtualMachine>();
	    	System.out.println(debug);
	    	for(int i=0; i<vmStack.size(); i++)
	    		if( vmStack.get(i).getVMStatus() == VirtualMachine.Status.ACTIVE &&
	    				vmStack.get(i).hasService(appName) &&
	    				vmStack.get(i).getAppStatus(appName).equals(VirtualMachine.AppStatus.IDLE)) {
	    			System.out.println("\t" + vmStack.get(i).getMyIP() + " = " + vmStack.get(i).getRequestQueueSize());
	    			activeVM.add(vmStack.get(i));
	    		}
	    		    	
	    	if(activeVM.size() > 0){
	    		Collections.sort(activeVM, new VirtualMachineComparator());
	    		return activeVM.get(0);
	    	}else{
	    		return null;
	    	}
		}
	} //ascendingSortAndTakeVM() {..}

//    //Versione 0.1 - Magnani
//    public VirtualMachine ascendingSortAndTakeVM() {
//    	synchronized(vmStack) {
//    		System.out.println(debug + "\n\tascendingSortAndTakeVM() {..}"
//    								 + "\n\t------> vmStack.size() = " + vmStack.size());
//    		if(vmStack.size() == 1)
//    			return vmStack.get(0);
//    		
//    		if(vmStack.size() == 0)
//    			return null;
//    		
//	    	Vector<VirtualMachine> activeVM = new Vector<VirtualMachine>();
//	    	System.out.println(debug);
//	    	for(int i=0; i<vmStack.size(); i++)
//	    		if( vmStack.get(i).getVMStatus() == VirtualMachine.Status.ACTIVE ) {
//	    			System.out.println("\t" + vmStack.get(i).getMyIP() + " = " + vmStack.get(i).getRequestQueueSize());
//	    			activeVM.add(vmStack.get(i));
//	    		}
//	    		    	
//	    	Collections.sort(activeVM, new VirtualMachineComparator());
//	    	return activeVM.get(0);
//    	}
//    } //ascendingSortAndTakeVM() {..}
	
	
	public void reset(){
		this.vmStack.clear();
	}
	
	public VirtualMachine resetForWG(){
		VirtualMachine vmTemp = getVMWithMoreRequest();
		this.vmStack.clear();
		this.vmStack.add(vmTemp);
//		for(int i=1; i<vmStack.size(); i++){
//			vmStack.remove(i);
//		}
		return vmTemp;
	}
	
    /** PUBLIC FUNCTIONS **/
}
