package it.unipr.dsg.awm.virtualmachine;

import java.util.Vector;

import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.model.common.ActionResponse;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.openstack.OSFactory;

/**
 * Utility class that cleans the Cloud.
 * 
 * @author Valter Venusti - December 2015
 * @modified by Federico Torreggiani 2017
 *
 */

public class VirtualMachineCleanerForWG extends Thread {

	private static String debug = "VIRTUAL MACHINE CLEANER FOR WG - ";

	private OSClientV3 demoUser;
	VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");

	private void destroyVM(VirtualMachine vmToBeDestroyed) {
		this.demoUser = OSFactory.builderV3().endpoint("http://160.78.27.68:5000/v3")
				.credentials("demo", "demo-pass", domainIdentifier)
				.scopeToProject(Identifier.byName("demo"), Identifier.byName("default")).authenticate();
		System.out.println(debug + "Connesso come 'demo' = " + demoUser.toString());

		ActionResponse resultDeleteServer = demoUser.compute().servers()
				.delete(vmToBeDestroyed.getOpenStackVM().getId());
		if (!resultDeleteServer.isSuccess()) {
			System.err.println(debug + "Error: " + resultDeleteServer.getFault());
		} else {
			System.err.println(debug + "Success destruction of VM (" + vmToBeDestroyed.getMyIP() + ")");
		}

	}

	/**
	 * Destroys all the Virtual Machines in the Cloud, independently from their
	 * state.
	 */
	public void run() {
		try {
			Thread.sleep(200);

			Vector<VirtualMachine> vmStackTemp = new Vector<VirtualMachine>();
			for (VirtualMachine vm : vmStack.getAllVMs()) {
				vmStackTemp.add(vm);
			}

			System.out.println(debug + "Shutting down and deleting " + (vmStackTemp.size() - 1) + " VMs...");
			// some cleaning up code...
			// staring from 1 -> the first VM (#0) must be always alive ...
			if (vmStackTemp.size() > 1) {
				
				VirtualMachine vmToBeAlive = vmStack.resetForWG();
				
				for (int i = 0; i < vmStackTemp.size(); i++) {
					VirtualMachine vm = vmStackTemp.get(i);
					if (!vm.getVMStatus().equals(VirtualMachine.Status.DESTRUCTION) && !vm.getMyIP().equals(vmToBeAlive.getMyIP())) {

						System.out.println(debug + "Destroying scheduled for " + vm.getMyIP());
						vm.setVMStatus(VirtualMachine.Status.DESTRUCTION);
						destroyVM(vm);
					}
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
