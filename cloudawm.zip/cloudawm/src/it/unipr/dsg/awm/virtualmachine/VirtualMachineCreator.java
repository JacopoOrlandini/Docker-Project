package it.unipr.dsg.awm.virtualmachine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.openstack4j.api.Builders;
import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.api.exceptions.ClientResponseException;
import org.openstack4j.api.exceptions.ServerResponseException;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.model.compute.Server;
import org.openstack4j.model.compute.ServerCreate;
import org.openstack4j.model.compute.builder.ServerCreateBuilder;
import org.openstack4j.openstack.OSFactory;

import it.unipr.dsg.awm.servicebroker.ServiceBroker;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine.Status;
import it.unipr.dsg.log.DataCollector;

/**
 * This class is responsible to allocate new Virtual Machines. 
 * When a new VM is allocated a Thread is necessary because there is a start-up time before
 * the VM is ready.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @modified by Federico Torreggiani 2017
 *
 */
public class VirtualMachineCreator extends Thread{
	private static String debug = "VIRTUAL_MACHINE_CREATOR - ";

	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	private OSClientV3 demoUser = null;
	private ServerCreate serverModel = null;
	
	/**
	 * Does nothing...
	 */
	public VirtualMachineCreator() {}
	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addVirtualMachineCreatorString(s);
	}
	
	/**
	 * This method waits until the Server server has become ACTIVE, and returns it.
	 */
	private Server waitUntilServerActive(OSClientV3 os, Server server) throws
	                             ClientResponseException, ServerResponseException {
	    String serverId = server.getId();
	    boolean serverIsReady = false;
	    Server server2 = null;

	    while ( !serverIsReady ) {
	        server2 = os.compute().servers().get(serverId);

	        if ( server2.getStatus().toString().equals("ACTIVE") ) {
	            // The server is now ACTIVE
	            serverIsReady = true;               
	        }

	        // Wait a little bit, to avoid sending too many petitions away continuously
	        if(!serverIsReady){
		        try{
		        	Thread.sleep(20 * 1000);
		        }catch(InterruptedException e){e.printStackTrace();}
	        }
	    }

	    return server2;
	}

	/**
	 * Start a new Virtual Machine with the characteristics contained in the configuration file and
	 * waits until it is ready. In particular the thread waits until the checkUp service on the Virtual Machine response.
	 * 
	 * At the end the Virtual Machine is put in the {@link VirtualMachineStack}
	 * 
	 * TODO Connection to the server http://160.78.27.68:5000/v3
	 */
	
	public void run() {
		long start = System.nanoTime();
		Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");
		this.demoUser = OSFactory.builderV3()	
				 .endpoint("http://160.78.27.68:5000/v3")	//connection to Unipr cluster
				 .credentials("demo","demo-pass", domainIdentifier)
				 .scopeToProject(Identifier.byName("demo") , Identifier.byName("default"))
				 .authenticate();
		printDebug(debug + "Connesso come 'demo' = " + demoUser.toString());		
		
		
		try{			
			Map<String, HashMap<String, String>> VMs = ServiceBroker.getVMInstances();	// VMs = get features of VM
			String indexVmToStart = ServiceBroker.getIndexVMToStart();
			
			//debug
			System.out.println("IndexVmToStart : "+ indexVmToStart);
			System.out.println("name : "+ VMs.get(indexVmToStart).get("name").toString());
			System.out.println("flavor : "+ VMs.get(indexVmToStart).get("flavor").toString());
			System.out.println("image ID : "+ VMs.get(indexVmToStart).get("imageId").toString());
			System.out.println("keyPairName : "+ VMs.get(indexVmToStart).get("keypairName").toString());
			System.out.println("zone : "+ VMs.get(indexVmToStart).get("zone").toString());
			//
			
			String securityGroupsString = VMs.get(indexVmToStart).get("securityGroups");
			String[] securityGroups = securityGroupsString.split("-");
			
			ServerCreateBuilder scb = Builders.server().name(VMs.get(indexVmToStart).get("name").toString()); 	//TODO openstack
			scb.flavor(VMs.get(indexVmToStart).get("flavor").toString());
			scb.image(VMs.get(indexVmToStart).get("imageId").toString());
			scb.keypairName(VMs.get(indexVmToStart).get("keypairName").toString());
			scb.availabilityZone(VMs.get(indexVmToStart).get("zone").toString());
			for(String s : securityGroups){
				scb.addSecurityGroup(s);
				System.out.println("Security group : "+ s);//
			}
			this.serverModel = scb.build();
			
//			this.serverModel = Builders.server().name(VMs.get(indexVmToStart).get("name").toString())
//												.flavor(VMs.get(indexVmToStart).get("flavor").toString())
//												.image(VMs.get(indexVmToStart).get("imageId").toString())
//												.keypairName(VMs.get(indexVmToStart).get("keypairName").toString())
//												.build();
			
			printDebug(debug + "serverModel = " + serverModel);
	
			Server serverTemp = this.demoUser.compute().servers().boot(serverModel);	
	    	
	    	String idServerTemp = serverTemp.getId();
	    	VirtualMachine newVM = new VirtualMachine(serverTemp);
	    	newVM.setVMStatus(Status.CREATION);
	    	vmStack.addVM(newVM);
	    	
	    	//debug
	    	System.out.println(debug + "idServerTemp : " + idServerTemp);
	    	
	    	Server myServer = waitUntilServerActive(demoUser, serverTemp);
	    	String serverIP = myServer.getAddresses().getAddresses("provider").get(0).getAddr();
	    	
	    	//debug
			System.out.println("server  : "+ myServer);
			System.out.println("serverIp  : "+ serverIP);
			//
			
	    	do {
	    		int port = ServiceBroker.getCheckUpPort();
		    	try(Socket s = new Socket(serverIP, port)) {
		    		s.setSoTimeout(5000);
		    		BufferedWriter writerToSocket = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
		    		writerToSocket.write( "CHECK_UP" );
					writerToSocket.flush();
					
					BufferedReader readerFromVM = new BufferedReader(new InputStreamReader(s.getInputStream()));
					String risp = readerFromVM.readLine();
					printDebug(debug + "Received " + risp + " from VM (" + serverIP + ")");
				
		    		s.close();
	
		    		if(risp.equals("ACK")){
		    			
		    			VirtualMachine vm = vmStack.getVMByID(idServerTemp);
		    			if(vm != null){
				    		vm.setOpenStackVM(myServer);
				    		vm.setMyIP();
			    			vm.setVMStatus(VirtualMachine.Status.ACTIVE);
		    			}else{
		    				vmStack.addVM(new VirtualMachine(myServer));
		    			}
		    			
			    		break;
		    		}else{
			    		System.err.println(debug + "VM (" + serverIP + ") check-up failure!! "
								 + "Wait 10 seconds...");
			    		try {
			    			Thread.sleep(10 * 1000);
			    		} catch (InterruptedException e1) { e1.printStackTrace(); }
		    		}
		    	} catch (IOException e) {
		    		System.err.println(debug + "VM (" + serverIP + ") under construction!! "
		    								 + "Wait 10 seconds...");
		    		try {
						Thread.sleep(10 * 1000);
					} catch (InterruptedException e1) { e1.printStackTrace(); }
		    	}
	    	} while(true);
		    	
	    	long end = System.nanoTime();
	    	double elapsedTimeInSecond = (double) (end - start) / 1000000000.0;
	    	
	    	dataColl.addVMAllocationTime(elapsedTimeInSecond);
	    	
	    	printDebug(debug + "Server IP: " + serverIP + "\n\t\t" +
	    							   "Tempo di creazione = " + elapsedTimeInSecond);
	    	
		}catch(ParseException | IOException e){ e.printStackTrace(); }
		
	} // public void run() {..}
}
