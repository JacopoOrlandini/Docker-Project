package it.unipr.dsg.awm;

import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

/**
 * UTILIZZO
 * 
 * 1) deve essere asincrono
 * 2) aggiunge un carico dinamico W dopo un tempo T
 * 
 * W : int, rappresenta le richieste da aggiungere.
 * T : minuto, rappresenta l'istante per aggiungere il carico dinamico.
 * S : request
 * date: request time
 */
public class RandomWorkLoadGenerator extends Thread{
	private static String debug = "DOCKER_RESOURCE_MANAGER - ";
	private int W;
	private int T;
	public ArrayList<Integer> notServed ;
	private Vector<String> S;
	private Vector<Date> dates;
	
	
	public RandomWorkLoadGenerator(int w, int t, Vector<String> in1, Vector<Date> in2) {
		this.setW(w);
		this.setT(t);
		this.setS(in1);	// quando richiamo S, vector deve essere gia inizializzato.
		setDates(in2);
		this.notServed = new ArrayList<Integer>();
		System.out.println(debug+ ": Creata istanza della classe");

	}

	@Override
	public void run() {
		for (int j = 0; j < 5; j++) {
			try {
				Thread.sleep(T * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			notServed.add(S.size());
			System.out.println("Richieste not served =" + S.size());
			for (int i = 0; i < W; i++) {
				S.add(0, "start_task");
				dates.add(0, new Date());
			}
			System.out.println(debug+" : Settate le nuove richieste");	
		}
		
	}

	public static String getDebug() {
		return debug;
	}

	public static void setDebug(String debug) {
		RandomWorkLoadGenerator.debug = debug;
	}

	public int getW() {
		return W;
	}

	public void setW(int w) {
		W = w;
	}

	public int getT() {
		return T;
	}

	public void setT(int t) {
		T = t;
	}

	public Vector<String> getS() {
		return S;
	}

	public void setS(Vector<String> s) {
		S = s;
	}

	public Vector<Date> getDates() {
		return dates;
	}

	public void setDates(Vector<Date> dates) {
		this.dates = dates;
	}

}
