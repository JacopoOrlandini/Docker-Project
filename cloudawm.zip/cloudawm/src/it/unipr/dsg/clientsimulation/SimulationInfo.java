package it.unipr.dsg.clientsimulation;

/**
 * This class has the duty of conserving all the informations about a simulation.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 */
public class SimulationInfo {

	/** SINGLETON STUFF **/
	private static SimulationInfo instance = null;

	private SimulationInfo() {}
	
	public static synchronized SimulationInfo getInstance() {
		if(instance == null)
			instance = new SimulationInfo();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/
	
	/** GLOBAL VARIABLES **/
	/**
	 * Possible status of a simulation.
	 * @author Marco Magnani - March 2015
	 * @author Valter Venusti - December 2015
	 */
	public enum SimStatus {NONE, RUNNING, ENDED}
	
	private SimStatus simStatus = SimStatus.NONE;
	private int numberOfDevices;
	/** GLOBAL VARIABLES **/
	
	/** PUBLIC FUNCTIONS **/
	/**
	 * @return The status of a simulation
	 */
	public SimStatus getSimulationStatus() { return this.simStatus; }
	/**
	 * @return The number of active devices in a simulation.
	 */
	public int getNumberOfDevices() { return numberOfDevices; }
	
	/**
	 * Sets the status of a simulation.
	 * @param status - The new status of the simulation.
	 */
	public void setSimulationStatus(SimStatus status) { 
		this.simStatus = status;
		System.out.println("\t\tSIMULATION INFO: Status = " + this.simStatusToString(status));
	}
	/**
	 * Sets the number of devices of a simulation.
	 * @param numberOfDevices
	 */
	public void setNumberOfDevices(int numberOfDevices) { this.numberOfDevices = numberOfDevices; }

	/**
	 * @param status - A possible simulation status
	 * @return The status passed as parameter in a printable format
	 */
	public String simStatusToString(SimStatus status) {
		if(SimStatus.RUNNING.equals(status))
			return "RUNNING";
		else if(SimStatus.ENDED.equals(status))
			return "ENDED";
		
		return "NONE";
	}

	/**
	 * Subtract a deivce from the simulation and change eventually the status of the entire simulation.
	 * @return The new status of the simulation
	 */
	public String subtractDevice(){
		this.numberOfDevices--;
		if(this.numberOfDevices == 0) this.simStatus = SimStatus.ENDED;
		return simStatusToString(this.simStatus);
	}
	/** PUBLIC FUNCTIONS **/
	
	
}
