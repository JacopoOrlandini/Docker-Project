package it.unipr.dsg.clientsimulation.hcs;

import java.util.Vector;
import java.util.TreeMap;

import it.unipr.dsg.clientsimulation.IDataCollector;

/**
 * This class has the duty of collecting informations about a simulation with the Http
 * Client Simulator.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class HttpClientDataCollector implements IDataCollector {

	//private static String debug = "HTTP CLIENT DATA COLLECTOR - ";
	
	/** SINGLETON STUFF **/
	private static HttpClientDataCollector instance = null;

	private HttpClientDataCollector() {}
	
	public static synchronized HttpClientDataCollector getInstance() {
		if(instance == null)
			instance = new HttpClientDataCollector();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/

	private Vector<Double> execTimeReal = new Vector<Double>();
	private Vector<Double> execTimeRealAvg = new Vector<Double>();
	private Vector<Double> execTimeRealStdDev = new Vector<Double>();
	
	private Vector<Double> queueTimeReal = new Vector<Double>();
	private Vector<Double> queueTimeRealAvg = new Vector<Double>();
	private Vector<Double> queueTimeRealStdDev = new Vector<Double>();
	
	private Vector<Double> instantsOfExecution = new Vector<Double>();
	private TreeMap<Integer, Integer> executionCounters = new TreeMap<Integer, Integer>();

	/**
	 * Collects statistical data.
	 */
	@Override
	public void collectNewData() {

		this.computeNewAvgAndStdDev(this.execTimeReal, this.execTimeRealAvg, this.execTimeRealStdDev);
		this.computeNewAvgAndStdDev(this.queueTimeReal, this.queueTimeRealAvg, this.queueTimeRealStdDev);
	}
	
	/**
	 * Clears all vectors of data collected.
	 */
	@Override
	public void resetAllVariables(){
		
		this.execTimeReal.clear();
		this.execTimeRealAvg.clear();
		this.execTimeRealStdDev.clear();
		this.queueTimeReal.clear();
		this.queueTimeRealAvg.clear();
		this.queueTimeRealStdDev.clear();
		this.instantsOfExecution.clear();
		this.executionCounters.clear();
	}
	
	/** ADD FUNCTIONS **/
	/**
	 * Adds an execution time to the collector. For execution time is intended the execution time on the 
	 * server application.
	 * @param value - The execution time in seconds
	 */
	public void addExecTimeReal(double value) {
		synchronized(this.execTimeReal) {
			this.execTimeReal.add(value);
		}
	}
	/**
	 * Adds a queue time to the collector. Queue time stands for the total time passed from the send of the request to reception
	 * of the response minus the execution time.
	 * @param value - The queue time.
	 */
	public void addQueueTimeReal(double value) {
		synchronized(this.queueTimeReal) {
			this.queueTimeReal.add(value);
		}
	}
	/**
	 * Adds the instant time on which a client makes a request to the Cloud. Instant time stands for
	 * the minute since the start of the simulation.
	 * @param value - The instant time
	 */
	public void addInstantOfExecution(double value) {
		synchronized(this.instantsOfExecution) {
			this.instantsOfExecution.add(value);
		}
	}
	/**
	 * Increments the counter of executions at a specified instant defined in minute since the start of the simulation.
	 * @param value - The instant
	 */
	public void addExecutionCounter(int value) {
		synchronized(this.executionCounters) {
			if(this.executionCounters.containsKey(value)){
				this.executionCounters.put(value, this.executionCounters.get(value)+1);
			}else{
				this.executionCounters.put(value, 1);
			}
		}
	}
	/** ADD FUNCTIONS **/
	
	
	/** GETTING FUNCTIONS **/
	/**
	 * @param value - The minute since the start of the simulation.
	 * @return The number of execution at "value" time
	 */
	public int getExecutionCounter(int value){
		
		return this.executionCounters.get(value);
	}
	/** GETTING FUNCTIONS **/
	
	
	/** GET PRINTABLE DATA **/
	/**
	 * Returns the execution times of the tasks in a printable format 
	 */
	public String getExecTimeRealPrintableData() {
		synchronized(this.execTimeReal) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.execTimeRealAvg.size(); i++)
				result += (i+1) + "\t" + this.execTimeRealAvg.get(i) + "\t" + this.execTimeRealStdDev.get(i) + "\n";
			return result;
		}
	}

	/**
	 * Returns the queue times of the tasks in a printable format 
	 */
	public String getQueueTimeRealPrintableData() {
		synchronized(this.queueTimeReal) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for(int i=0; i<this.queueTimeRealAvg.size(); i++)
				result += (i+1) + "\t" + this.queueTimeRealAvg.get(i) + "\t" + this.queueTimeRealStdDev.get(i) + "\n";
			return result;
		}
	}

	/**
	 * Returns the number of execution sampled every minute in a printable format 
	 */
	public String getExecutionCountersPrintableData() {
		String result = "";
		result += "#K\tQuantity\n";
		synchronized(this.executionCounters) {
			for(Integer i : this.executionCounters.keySet()){
				result += (i+1)  + "\t" + this.executionCounters.get(i) + "\n";			
			}
		}

		return result;
	}
	/** GET PRINTABLE DATA **/

	/** PRIVATE FUNCTIONS **/
	private void computeNewAvgAndStdDev(Vector<Double> dataVector, 
			Vector<Double> avgVector, 
			Vector<Double> stdDevVector) {
		synchronized(dataVector) {
			double avgValue = computeAvgOfVector(dataVector);
			avgVector.add( avgValue );
			stdDevVector.add( computeStdDevOfVector(dataVector, avgValue));
		}
	}
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = sum / (double) vector.size();
			return mean;
		}
	}
	
	private double computeStdDevOfVector(Vector<Double> vector, double mean) {
		synchronized(vector) {
			double sum = 0;
			for(Double value : vector)  sum += Math.pow( (value - mean), 2);
			double stdDev = Math.sqrt( sum / (double) vector.size() );
			return stdDev;
		}
	}
	/** PRIVATE FUNCTIONS **/

}
