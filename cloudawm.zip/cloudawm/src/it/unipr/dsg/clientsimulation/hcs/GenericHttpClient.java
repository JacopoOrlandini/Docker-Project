package it.unipr.dsg.clientsimulation.hcs;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import it.unipr.dsg.clientsimulation.SimulationInfo;
import it.unipr.dsg.clientsimulation.SimulationInfo.SimStatus;

/**
 * This class represents an http client that make requests to the Cloud.
 * The rate parameter is 1/lambda.
 * If lambda = 40 then a client will make one request, in average, every 40 minutes.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class GenericHttpClient extends Thread {
	private String debug = null;
	
	/** HTTP CLIENT VARIABLES **/
	private int httpClientId;
	private double makeARequestEveryXMinute;	

	private HttpClient httpclient = HttpClients.createDefault();

	private Vector<String> matrixesPath = null;	
	private Vector<String> imagesPath = null;
	
	/**
	 * The type of the request. It could be "Matrix" or "Image" in version 1.0
	 * 
	 * @author Valter Venusti - December 2015
	 *
	 */
	public enum RequestType { Matrix, Image };
	/** HTTP CLIENT VARIABLES **/
	
	private SimulationInfo simInfo = SimulationInfo.getInstance();
	private HttpClientDataCollector hcsDataColl = HttpClientDataCollector.getInstance();
	
	/** SIMULATION VARIABLES **/
	private Date globalStart = null;
	private int startMinute = 0;
	private int stopMinute = 500;
	private int socketWaitInSeconds = 120;
	/** SIMULATION VARIABLES **/
	
	/**
	 * @param id - The ID of the client
	 * @param images - A vector containing the paths to the possible images to send to the Cloud
	 * @param matrixes - A vector containing the paths to the possible matrixes to send to the Cloud
	 * @param lambdaDev - The rate parameter (1/lambdaDev)
	 * @param startTime - The minute since the start of the simulation on which the client has to begin to query the Cloud
	 * @param stopTime - The minute since the start of the simulation on which the client has to stop to query the Cloud
	 */
	public GenericHttpClient(int id, Vector<String> images, Vector<String> matrixes, 
			double lambdaDev, int startTime, int stopTime) {
		this.httpClientId = id;
		this.debug = "\t\t" + "HttpClient #" + this.httpClientId + " - ";
		this.matrixesPath = matrixes;
		this.imagesPath = images;
		this.makeARequestEveryXMinute = lambdaDev;
		this.startMinute = startTime;
		this.stopMinute = stopTime;
		this.socketWaitInSeconds = 120;
	}
	
	/**
	 * @param id - The ID of the client
	 * @param images - A vector containing the paths to the possible images to send to the Cloud
	 * @param matrixes - A vector containing the paths to the possible matrixes to send to the Cloud
	 * @param lambdaDev - The rate parameter (1/lambdaDev)
	 * @param startTime - The minute since the start of the simulation on which the client has to begin to query the Cloud
	 * @param stopTime - The minute since the start of the simulation on which the client has to stop to query the Cloud
	 * @param socketWaitInSeconds - The maximum waiting time for a response from the Cloud
	 */
	public GenericHttpClient(int id, Vector<String> images, Vector<String> matrixes, 
			double lambdaDev, int startTime, int stopTime, int socketWaitInSeconds) {
		this.httpClientId = id;
		this.debug = "\t\t" + "HttpClient #" + this.httpClientId + " - ";
		this.matrixesPath = matrixes;
		this.imagesPath = images;
		this.makeARequestEveryXMinute = lambdaDev;
		this.startMinute = startTime;
		this.stopMinute = stopTime;
		this.socketWaitInSeconds = socketWaitInSeconds;
	}
	
	private int minutesDifference(Date d1, Date d2){
		
		long millisDiff = Math.abs(d2.getTime() - d1.getTime());
		
		return (int) (millisDiff / 60000);
	}
	
	/**
	 * The client sleeps until its start time. Then starts to query the Cloud choosing random if send an image or a matrix.
	 * The rate of the queries is defined according to the device's lambda.
	 */
	public void run() {	
		
		this.globalStart = new Date();
		
		//Sleeping until my start
		try {
			Thread.sleep(this.startMinute * 60 * 1000);
		} catch (InterruptedException e1) {
			System.out.println(debug + "Unable to make the first sleep!!!");
			e1.printStackTrace();
		}
		
//		Date dateOfStart = new Date(this.globalStart.getTime() + (this.startMinute * 60 * 1000));
		Date previousArrival = new Date();
		long delayMilliSec = 0;
//		long stopTime = this.globalStart.getTime() + (stopMinute * 60 * 1000);
		
		while(true){
			
			int minDiff = minutesDifference(new Date(), this.globalStart);
			System.out.println(debug + "Minutes from start: " + minDiff);
			if(minDiff >= stopMinute){
				System.out.println(debug + "Should terminate...");
				break;
			}
			
			previousArrival = new Date(previousArrival.getTime() + delayMilliSec);
			
			// Generate the next random interval to wait before next HTTP Request
			double delayInMinutes = poissonRandomInterarrivalDelay(1/makeARequestEveryXMinute);
//			delayMilliSec = (long) ((delayInMinutes/4) * 60 * 1000);
			delayMilliSec = (long) ((delayInMinutes) * 60 * 1000);
			
			Date start = new Date();
			
			int minuteOfExecution = minutesDifference(start, this.globalStart);
			System.out.println(debug + "OK, I take a file to elaborate - Time: " + minuteOfExecution);
			hcsDataColl.addInstantOfExecution(minuteOfExecution);
			hcsDataColl.addExecutionCounter(minuteOfExecution);
			
			// Seleziono in modo casuale una matrice o un'immagine tra quelle disponibili
			int rnd = generateRandomInt(0, 2);
			String currentPath = matrixesPath.get(generateRandomInt(0, matrixesPath.size()));
			File currentFile = new File(currentPath);
			RequestType request = RequestType.Matrix;
			if(rnd == 1){
				currentPath = imagesPath.get(generateRandomInt(0, imagesPath.size()));
				currentFile = new File(currentPath);
				request = RequestType.Image;
			}
			
			try {
				makePostRequest(currentFile, request);
			} catch (IOException e) { e.printStackTrace(); }
			
//			prova(minuteOfExecution);
			
			Date finish = new Date();
					
			long elaborationMilliSec = Math.abs(finish.getTime() - start.getTime()); 
			if(elaborationMilliSec < delayMilliSec){
			
				System.out.println(debug + "Waiting (" + ((double)(delayMilliSec-elaborationMilliSec) / 1000.0) + 
						" sec.) the next event...\n");
				try {
					Thread.sleep(delayMilliSec-elaborationMilliSec);
				} catch (InterruptedException e) { e.printStackTrace(); }			
			}else{
				System.out.println(debug + "Execution too long. No waiting...");
			}
		}
		
		//The device is Dead...
		System.out.println(debug + "Device terminated. The status of the simulation is " + simInfo.subtractDevice());
		System.out.println(debug + "Devices not yet terminated: " + simInfo.getNumberOfDevices());
		if(simInfo.getSimulationStatus().equals(SimStatus.ENDED)){
			System.out.println(debug + "SImulation ENDED...");
		}
		
	} // public void run() {..}
	
//	private void prova(int minuteOfExecution) {
//		
//		System.out.println(debug + "Totale executions at " + minuteOfExecution 
//				+ ": " + hcsDataColl.getExecutionCounter(minuteOfExecution));
//		
//	}

	private static double poissonRandomInterarrivalDelay(double rateParam) {
	    return -( Math.log(1.0 - Math.random()) / rateParam );
	}
	
	private int generateRandomInt(int min, int max) {
        Random rand = new Random();
        int randNum = rand.nextInt((max - min)) + min;
        return randNum;
	} // private int generateRandomInt(..) {..}
	

	private void makePostRequest(File file, RequestType type) 
			throws ClientProtocolException, IOException {
		
		long startRequest = System.nanoTime();
		
		HttpPost httppost = null;
		if(type == RequestType.Image){
			httppost = new HttpPost("http://160.78.27.66:5678/images");
		}else{
			httppost = new HttpPost("http://160.78.27.66:5678/matrixes");
		}
		httppost.addHeader("connection", "keep-alive");
		
		RequestConfig config = RequestConfig.custom()
				.setSocketTimeout(this.socketWaitInSeconds * 1000)
				.setConnectTimeout(this.socketWaitInSeconds * 1000)
				.setConnectionRequestTimeout(this.socketWaitInSeconds * 1000)
				.build();
		httppost.setConfig(config);
		
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("file", file);
		
		HttpEntity content = builder.build();
		httppost.setEntity(content);
		HttpResponse response;
		
		System.out.println(debug + "makePostRequest(..) {..} - execute.(httppost)\n");
		response = httpclient.execute(httppost);
		HttpEntity entity = response.getEntity();
		
		if (entity != null) {
			
			long finishRequest = System.nanoTime();
			
			System.out.println(debug + "makePostRequest(..) {..} - Response received of POST!!!");
			BufferedReader in = new BufferedReader(new InputStreamReader(entity.getContent()));
		    try {
		    	String inputLine, totalResponse = "";
		    	while ((inputLine = in.readLine()) != null) {
		    		totalResponse += inputLine;
		    	}
//		    	System.out.println(totalResponse);
		    	JSONParser jsonParser = new JSONParser();
		    	JSONObject jsonResponse = (JSONObject) jsonParser.parse(totalResponse);
		    	
		    	String fileName = (String) jsonResponse.get("name");
		    	System.out.println(debug + "makePostRequest(..) {..} - name:\"" + fileName + "\"");
		    	
		    	if(type == RequestType.Image){
		    		HCSDeletePhoto delPhoto = new HCSDeletePhoto(fileName);
		    		delPhoto.start();
		    	}else{
		    		HCSDeleteMatrix delMatrix = new HCSDeleteMatrix(fileName);
		    		delMatrix.start();		    		
		    	}
		    	
		    	double elaborationTime = Double.parseDouble((String) jsonResponse.get("elaboration_time"));
		    	double queueTimeInSecond = (double) (finishRequest - startRequest) / 1000000000.0;
		    	hcsDataColl.addExecTimeReal(elaborationTime);
		    	hcsDataColl.addQueueTimeReal(queueTimeInSecond - elaborationTime);
		    	
		    } catch (ParseException e) {
				e.printStackTrace();
			} finally { in.close(); }   
		} else {
			System.err.println(debug + "makePostRequest(..) {..} - Empty Response!! ERROR!!");
		}
	} // private void makePostRequest(..) {..}
	
} // public class MobileDevice extends Thread {..}

