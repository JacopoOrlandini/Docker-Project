package it.unipr.dsg.clientsimulation.hcs;

import java.io.IOException;
import java.util.Vector;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import it.unipr.dsg.awm.util.AWMJSONParser;
import it.unipr.dsg.clientsimulation.ClientGenerator;
import it.unipr.dsg.clientsimulation.SimulationInfo;

/**
 * This class is responsible of starting a simulation.
 * In particular this class creates a number of thread equals to the number of client we
 * want to simulate.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class HttpClientGenerator implements ClientGenerator{

	/**
	 * The constructor initialize the path on which each client can retrieve the images or the 
	 * matrixes to send to the Cloud.
	 */
	public HttpClientGenerator() {
		System.out.println(debug + "Started!!");
		for(int i=0; i<howManyImages; i++) {
			String tmpPath = baseImagePath + "p" + i + ".jpg";
			imagesPath.add(tmpPath);
		}
		for(int i=0; i<howManyMatrixes; i++) {
			String tmpPath = baseMatrixPath + "m" + i + ".txt";
			matrixesPath.add(tmpPath);
		}
	}
	
	/** GLOBAL VARIABLES **/
	private static String debug = "HTTP_CLIENT_GENERATOR - ";
	
	private String baseImagePath = "/home/SdE/MobileDeviceSimulationPhotos/";
	private String baseMatrixPath = "/home/SdE/HttpClientSimulationMatrixes/";
	private int howManyImages = 14;
	private int howManyMatrixes = 13;
	private Vector<String> imagesPath = new Vector<String>();
	private Vector<String> matrixesPath = new Vector<String>();

	//private static int[] cpuCores = {1, 2, 4, 8};
	
	private SimulationInfo simInfo = SimulationInfo.getInstance();
	/** GLOBAL VARIABLES **/
	
	/** PUBLIC FUNCTIONS **/
	/**
	 * Starts the simulation taking the information from the Database.
	 */
	@Override
	public void startSimulation() {
		
		//Retrieving the number of mobile devices and the frequency lambda of the devices
		JSONObject clients = null;
		int clientsNumber = 1, clientsGroups = 1, socketWaitInSeconds = 120;
		try {
			clients = new AWMJSONParser().getFromVoice("HttpClientSimulation");
			socketWaitInSeconds = Integer.parseInt(clients.get("SocketWaitInSeconds").toString());
			clientsNumber = Integer.parseInt(clients.get("NumOfClients").toString());
			clientsGroups = Integer.parseInt(clients.get("Groups").toString());
		} catch (ParseException | IOException e) {
			e.printStackTrace();
			socketWaitInSeconds = 120;
			clientsNumber = 1;
			clientsGroups = 1;
		}
		
		System.out.println(debug + "Clients: " + clientsNumber + " Groups: " + clientsGroups);
//		try {
//			System.in.read();
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		}
		
		int clientID = 1;
		int groupCounter = -1;
		int clientGroupCounter = 0;
		int startTime = 0;
		int stopTime = 500;
		double makeARequestEveryXMinute = 1.0;
		boolean parseError = false;
		
		//simInfo.setNumberOfDevices(clientsNumber);
		
		while( clientsNumber > 0 ) {
	        
			parseError = false;
			if(clientGroupCounter == 0){
				if(groupCounter < clientsGroups-1){
					groupCounter++;
					String group = "Group" + groupCounter;
					JSONObject groupData;
					try {
						groupData = new AWMJSONParser().parseFromString(clients.get(group).toString());
						clientGroupCounter = Integer.parseInt(groupData.get("Quantity").toString());
						makeARequestEveryXMinute = Double.parseDouble(groupData.get("MakeARequestEveryXMinute").toString());
						startTime = Integer.parseInt(groupData.get("TimeStart").toString());
						stopTime = Integer.parseInt(groupData.get("TimeStop").toString());
					} catch (ParseException e) {
						e.printStackTrace();
						parseError = true;
					}

				}else{
					clientsNumber = 0;
					parseError = true;
				}
			}
	
			System.out.println(debug + "Start device " + clientID + " Lambda: " + makeARequestEveryXMinute + 
					" StartTime: " + startTime + " StopTime: " + stopTime);
			
			if(!parseError){
		        GenericHttpClient device = new GenericHttpClient(clientID, imagesPath, 
		        		matrixesPath, makeARequestEveryXMinute, startTime, stopTime, socketWaitInSeconds);
		        device.start();
		        clientID++;
			}
	        
	        if(clientGroupCounter > 0) clientGroupCounter--;
	        clientsNumber--;
        } // while
		
		simInfo.setNumberOfDevices(clientID-1);
		System.out.println(debug + "devices: " + simInfo.getNumberOfDevices());
		simInfo.setSimulationStatus(SimulationInfo.SimStatus.RUNNING);
	}
	/** PUBLIC FUNCTIONS **/
	
}
