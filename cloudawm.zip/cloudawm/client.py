#!/usr/bin/env python
from urllib import urlopen
from urllib2 import URLError
import time
import pprint
import docker as dk
import datetime
import sys


ip = "localhost"
port = sys.argv[1]
contents = urlopen("http://"+ip+":"+str(port)+"/start_task").read()


# def wait_for_internet_connection():

#             contents = urlopen("http://"+ip+":"+str(port)).read()
#             if contents is not "":
#                 return contents
#         except:
#             time.sleep(1)
#             pass




# Per vedere le info: Stats
# metric = containers[0].stats(stream=False)
# pprint.pprint(metric) 

# Per vedere gli attributi del container: Attrs
# pprint.pprint(containers[0].attrs)

# Per aggiornare container
# my_container.update()

# Devo modificare il client per APIDocker
#pprint.pprint(client.inspect_container(containers[0]))



# # Statistiche su uso del container
# delta_total_usage = (float(metric["cpu_stats"]["cpu_usage"]["total_usage"]) - float(metric["precpu_stats"]["cpu_usage"]["total_usage"])) / float((metric["precpu_stats"]["cpu_usage"]["total_usage"]))
# delta_system_usage = (float(metric["cpu_stats"]["system_cpu_usage"]) - float(metric["precpu_stats"]["system_cpu_usage"]))/float(metric["precpu_stats"]["system_cpu_usage"])
# y = float(delta_total_usage / delta_system_usage) * len(metric["cpu_stats"]["cpu_usage"]["percpu_usage"])*100.0


# Per ottenere Te
# creation_date = containers[0].attrs["Created"]

# fmt="%Y-%m-%dT%H:%M:%S"
# old = datetime.datetime.strptime(creation_date[:-4], '%Y-%m-%dT%H:%M:%S.%f')  
# new = datetime.datetime.now()
# Te = new - old

# totSeconds = Te.seconds - 60*60 
# print totSeconds
# exit(1)

""" Parametri da ricavare 
	 * @param T - The sampling period
	 * @param Te - The estimated mean response time on the Cloud
	 * @param alpha - The weight of an active VM in the system
	 * @param beta - The weight of a request not yet served
	 * @param gamma - The weight of activation or deactivation of a VM
	 * @param delta - The weight of a new physical server
	 * @param M - The maximum number of VM per server
    """
