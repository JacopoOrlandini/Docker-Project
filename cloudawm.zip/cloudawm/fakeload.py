import time
def fibonacci(n):
    if n==0 or n==1:
        return 1
    return fibonacci(n-1) + fibonacci(n-2) 


def hello():
    data = []
    time.sleep(30)
    for n in xrange(36):
        data.append(fibonacci(n))


hello()

