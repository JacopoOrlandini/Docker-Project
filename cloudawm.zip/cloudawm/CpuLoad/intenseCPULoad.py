#!/usr/bin/env python
"""
Produces load on all available CPU cores
"""
from multiprocessing import Pool
from multiprocessing import cpu_count
import time

def f(x):
    while True:
        print(x*x)
        time.sleep(0.5)

def main():
    processes = 1
    print '-' * 20
    print 'Running load on CPU'
    print 'Utilizing %d cores' % processes
    print '-' * 20
    pool = Pool(processes)
    pool.map(f, range(processes))

main()
