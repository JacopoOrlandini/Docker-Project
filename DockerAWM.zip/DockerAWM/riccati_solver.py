
import numpy as np
import scipy.linalg
from numpy.linalg import inv, LinAlgError
import getopt
import sys

from scipy.linalg.decomp_schur import schur

def my_solve_discrete_are(a, b, q, r):
    """
    Solves the disctrete algebraic Riccati equation, or DARE, defined as
    (X = A'XA-(A'XB)(R+B'XB)^-1(B'XA)+Q), directly using a Schur decomposition
    method.
    .. versionadded:: 0.11.0
    Parameters
    ----------
    a : (M, M) array_like
        Non-singular, square matrix
    b : (M, N) array_like
        Input
    q : (M, M) array_like
        Input
    r : (N, N) array_like
        Non-singular, square matrix
    Returns
    -------
    x : ndarray
        Solution to the continuous Lyapunov equation
    See Also
    --------
    solve_continuous_are : Solves the continuous algebraic Riccati equation
    Notes
    -----
    Method taken from:
    Laub, "A Schur Method for Solving Algebraic Riccati Equations."
    U.S. Energy Research and Development Agency under contract
    ERDA-E(49-18)-2087.
    http://dspace.mit.edu/bitstream/handle/1721.1/1301/R-0859-05666488.pdf
    """

    try:
        g = inv(r)
    except LinAlgError:
        raise ValueError('Matrix R in the algebraic Riccati equation solver is ill-conditioned')

    g = np.dot(np.dot(b, g), b.conj().transpose())

    try:
        ait = inv(a).conj().transpose()  # ait is "A inverse transpose"
    except LinAlgError:
        raise ValueError('Matrix A in the algebraic Riccati equation solver is ill-conditioned')

    z11 = a+np.dot(np.dot(g, ait), q)
    z12 = -1.0*np.dot(g, ait)
    z21 = -1.0*np.dot(ait, q)
    z22 = ait

    z = np.vstack((np.hstack((z11, z12)), np.hstack((z21, z22))))

    # Note: we need to sort the upper left of s to lie within the unit circle,
    #       while the lower right is outside (Laub, p. 7)
    [s, u, sorted] = schur(z, output='real', lwork=None, overwrite_a=False, sort='iuc')
    
    (m,n) = u.shape

    u11 = u[0:m//2, 0:n//2]
    u21 = u[m//2:m, 0:n//2]
    u11i = inv(u11)

    return np.dot(u21, u11i)


def dlqr(A,B,Q,R):
    """Solve the discrete time lqr controller.
     
     
    x[k+1] = A x[k] + B u[k]
     
    cost = sum x[k].T*Q*x[k] + u[k].T*R*u[k]
    """
    #ref Bertsekas, p.151
 
    #first, try to solve the riccati equation
    X = np.matrix(my_solve_discrete_are(A, B, Q, R))

    #compute the LQR gain
    K = np.matrix(scipy.linalg.inv(B.T*X*B+R)*(B.T*X*A))
     
    eigVals, eigVecs = scipy.linalg.eig(A-B*K)
     
    return K, X, eigVals


T = 300
Te = 2
alpha = 100
gamma = 5000
delta = 10000
beta = 0.005
M_2 = 9*9
A = np.array([[1, 0],[-T/Te, 1]])
B = np.array([[1],[0]])
Q = np.array([[alpha+(delta/M_2), 0],[0, beta]])
R = np.array([[gamma]])

###### GETOPT ########
try:
	#print sys.argv
	(opts, args) = getopt.getopt(sys.argv,'t:e:a:b:g:d')
	#print opts
	#print args
except getopt.GetoptError:
	print 'InverseMatrix.py [-t][-e][-a][-b][-g][-d]'
	sys.exit(2)
T = args[1];
Te = args[2];
alpha = args[3];
beta = args[4];
gamma = args[5];
delta = args[6];
M = args[7];
A = np.array([[1, 0],[-float(T)/float(Te), 1]])
B = np.array([[1],[0]])
Q = np.array([[float(alpha)+(float(delta)/float(M_2)), 0],[0, float(beta)]])
R = np.array([[float(gamma)]])
#### END GETOPT	######	

K,P,eig_controlled = dlqr(A,B,Q,R)

##print "K:\n"
print str(K.item(0,0))
print str(K.item(0,1))
##print "\n"
