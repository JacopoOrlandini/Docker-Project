import docker

client = docker.from_env()
d = {"status":"running"}
tot = 0
try:
    containers = client.containers.list(filters=d)
    tot = len(containers)
except:
    tot = 0

print(tot)

