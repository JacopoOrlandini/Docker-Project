package it.unipr.dsg.awm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

import it.unipr.dsg.awm.controller.Controller;
import it.unipr.dsg.awm.controller.QoSModeler;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineCleanerForWG;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.LogWriter;

/**
 * The class {@code SimulationManager} is responsible to receive the information
 * about the state of a simulation. It is implemented as a thread waiting for
 * messages from a Simulation Client.
 * 
 * @author Federico Torreggiani - 2017
 *
 */

public class SimulationManager extends Thread {

	private static String debug = "SIM MANAGER - ";

	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private AssignedRequest assignedRequest = AssignedRequest.getInstance();
	private QueuedRequest queuedRequest = QueuedRequest.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();
	private LogWriter logWriter = LogWriter.getInstance();

	private int port = 5685;
	private Socket socket;
	private String currentSimStatus;
	private int k_min, k_max;
	private boolean establishedConnection = false;

	private Controller controller;

	private enum simStatus {
		STARTED, RUNNING, ENDED, LASTSIMENDED
	};

	/**
	 * Class constructor
	 */
	public SimulationManager(int k_min, int k_max, Controller controller) {
		this.k_min = k_min;
		this.k_max = k_max;
		this.controller = controller;
	}

	/**
	 * Prepare the system for a new simulation
	 */
	public void run() {
		System.out.println(debug + "STARTED !");
		ServerSocket serverSocket = null;

		try {
			serverSocket = new ServerSocket(port, 500);
		} catch (IOException e) {
			System.err.println(debug + "Could not listen on port " + port);
			System.exit(-1);
		}
		System.out.println(debug + "Listening on port " + this.port + "...");

		while (true) {
			try {

				if (!this.establishedConnection)
					acceptConnection(serverSocket);

				BufferedWriter writerToCSim = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
				BufferedReader readerFromCSim = new BufferedReader(new InputStreamReader(socket.getInputStream()));

				String receivedStatus = readerFromCSim.readLine();
				System.out.println(debug + "<===== New SIMULATION STATUS Received!!!");
				System.out.println(debug + "<===== Simulation status received : " + receivedStatus);

				if (simStatus.RUNNING.toString().equals(receivedStatus)) {
					System.out.println(debug + " New simulation has been started and it is now running...");
					this.currentSimStatus = simStatus.RUNNING.toString();

					writerToCSim.write("ACK");
					writerToCSim.write('\n');
					writerToCSim.flush();
					System.out.println(debug + "=====> ACK the SIM STATUS Received");

				} else if (simStatus.ENDED.toString().equals(receivedStatus)) {
					System.out.println(debug + " Preparing the system for a new simulation...");
					this.currentSimStatus = simStatus.ENDED.toString();

					resetSystem();

					System.out.println(debug + " System ready for a new simulation !");
					writerToCSim.write("READYACK");
					writerToCSim.write('\n');
					writerToCSim.flush();
					System.out.println(debug + "=====> ACK the SIM STATUS Received");

				} else if (simStatus.LASTSIMENDED.toString().equals(receivedStatus)) {
					this.establishedConnection = false;
				} else {
					System.out.println(debug + " - Simulation status uknown ... Reset the system end preparing for a new simulation !");
					resetSystem();
					this.establishedConnection = false;
				}

			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
				try {
					serverSocket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		} // while
	}

	private void acceptConnection(ServerSocket serverSocket) {
		try {
			socket = serverSocket.accept();
		} catch (IOException e2) {
			e2.printStackTrace();
			System.out.println(debug + " Connection error ! ");
		}
		System.out.println(debug + " Connection accepted ! ");
		this.establishedConnection = true;
	}

	private void printDebug(String s) {
		System.out.println(s);
		dataColl.addControllerString(s);
	}
	
	private void resetSystem() throws InterruptedException{
		
		// (1) Write new Log File
		printDebug(debug + "Write new Log File!!!");
		logWriter.writeLogFile();
		logWriter.writeTestParameters();

		// (2) Wait until VM Stack is restored
		printDebug(debug + "Restore VM Stack to k_min VM!!!");
		new VirtualMachineCleanerForWG().start();

		while (vmStack.getSize() > 1) {
			printDebug(debug + "vmStack.getSize() > 0 : " + "[" + vmStack.getSize() + "] > 0");
			Thread.sleep(10 * 1000);
		}

		printDebug(debug + "vmStack Size()  : " + vmStack.getSize());
		//VirtualMachineScaler.scaleUpStack(this.k_min);
/*					while (vmStack.getSize() != this.k_min) {
			printDebug(debug + "vmStack.getSize() != this.k_min : " + "[" + vmStack.getSize() + "] != ["
					+ k_min + "]");
			Thread.sleep(10 * 1000);
		}
*/
		// (3) Reset all variables
		printDebug(debug + "Reset all variables...");
		this.dataColl.resetAllVariables();
		this.qos.resetAllVariables();
		this.assignedRequest.resetAllVariables();
		this.queuedRequest.resetAllVariables();
		if (this.controller != null)
			this.controller.resetVariables();
	}

}
