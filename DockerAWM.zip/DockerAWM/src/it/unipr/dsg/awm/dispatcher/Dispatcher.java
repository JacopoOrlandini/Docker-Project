package it.unipr.dsg.awm.dispatcher;

import it.unipr.dsg.awm.AppRequestInfo;
import it.unipr.dsg.awm.IdAllocator;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;

/**
 * This class is responsible of taking new requests arrived in the Cloud
 * and dispatch them to the VMs.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class Dispatcher extends Thread {
	private static String debug = "DISPATCHER_THREAD - ";
	
	private QueuedRequest queuedRequest = QueuedRequest.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private IdAllocator idAllocator = IdAllocator.getInstance();
	
	/**
	 * The default constructor does nothing.
	 */
	public Dispatcher() {}
	

	/**
	 * This is the only method of the class. It executes these simple passes:
	 * 
	 * 1. Waits for a new requests in the blocking queue of requests ({@link QueuedRequest})
	 * 2. Reads the application of the requests
	 * 3. Tries to find the VM with less assigned requests in which this application is not busy
	 * 4. Set the status the application to BUSY
	 * 5. Tries to take a valid ID for this request
	 * 6. Starts a new Thread to send the request
	 * 
	 * If errors or exceptions occur the request is readded in the blocking queue until it is permitted.
	 */
    public void run() {
    	System.out.println(debug + "Hi!! I'm the Dispatcher.");
    	AppRequestInfo currentRequest = null;
    	Date startDispatchingDate;
    	VirtualMachine currentVM = null;

    	int threadId = 0;
    	while(true) {
    		try{
				// Attendo una nuova richiesta nella BlockingQueue
				System.out.println(debug + "I'm blocked on queuedRequest BlockingQueue...wait...");
				currentRequest = queuedRequest.takeRequestFromQueue();
				startDispatchingDate = new Date();
				System.out.println(debug + "Yeah!! There is a new Request!!");
	
				// Individuo la VM con il minor numero di richieste
				currentVM = vmStack.ascendingSortAndTakeVM(currentRequest.getApplicationName());
				while(currentVM == null) {
					System.out.println(debug + "No VM available!! Put request in queue and wait 5 seconds...");
					queuedRequest.addRequestToQueue(currentRequest, false);
					Thread.sleep(5 * 1000);
					System.out.println(debug + "Take new request and check if there is VM available...");
					currentRequest = queuedRequest.takeRequestFromQueue();
					currentVM = vmStack.ascendingSortAndTakeVM(currentRequest.getApplicationName());
				}
				
				currentVM.setAppStatus(currentRequest.getApplicationName(), VirtualMachine.AppStatus.BUSY);
				
				/*ID ALLOCATION*/
				long id = idAllocator.getNextValidId();
				while(id == -1){
					System.out.println(debug + "No ID available!! Wait 5 seconds...");
					Thread.sleep(5 * 1000);
					System.out.println(debug + "Check if there is ID available...");
					id = idAllocator.getNextValidId();
				}
								
				currentRequest.setId(id);
				
				System.out.println(debug + "Starting new Thread...");
				DispatcherThread thread = new DispatcherThread(threadId, currentVM, currentRequest, startDispatchingDate);
				thread.start();
				System.out.println(debug + "New Thread " + threadId + " started...");
				
				threadId++;
				

			} catch (Exception e) { 
				if(currentRequest != null){
					currentRequest.setErrorNumbers(currentRequest.getErrorNumbers()+1);
					QueuedRequest.getInstance().addRequestToQueue(currentRequest, false);
				}
				e.printStackTrace(); 
				debug(e.toString());
			} 
    		
    		if(currentVM != null){
    			currentVM.setAppStatus(currentRequest.getApplicationName(), VirtualMachine.AppStatus.IDLE);
    		}
    		
    	} // while(true) {..}
    	    	
    } // public void run() {..}
    
	private static void debug(String s){
		
		try {
			File file = new File("/opt/CloudAWM/debugAWM/dispatcherError"+new Date().getTime()+".log");
			PrintWriter writer = new PrintWriter(file);
						
			writer.println(s);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) { 
			System.err.println(debug + "Path Not Found!!");
			e.printStackTrace();
		}
	}
}
