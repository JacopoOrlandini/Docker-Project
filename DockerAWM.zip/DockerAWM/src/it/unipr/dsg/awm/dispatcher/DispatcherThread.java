package it.unipr.dsg.awm.dispatcher;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Date;

import it.unipr.dsg.awm.AppRequestInfo;
import it.unipr.dsg.awm.AssignedRequest;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.log.DataCollector;

/**
 * This class depends on the {@link Dispatcher} class and is responsible of sending 
 * a specific request to a specific VM.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class DispatcherThread extends Thread {
	private static String debug = null;
	
	private final int myID;
	private final VirtualMachine currentVM;
	private final AppRequestInfo currentRequest;
	private final Date startDispatchingDate;
	
	private DataCollector dataColl = DataCollector.getInstance();
	
	private int socketTimeout = 1 * 60 * 1000;
		
	/**
	 * The constructor sets the parameters necessary for the communication.
	 * @param id - the ID of the thread
	 * @param vm - the Virtual Machine of destination
	 * @param request - the request to send
	 * @param date - time of taking the request from the blocking queue
	 */
	public DispatcherThread(int id, VirtualMachine vm, AppRequestInfo request, Date date) {
		this.myID = id;
		debug = "DISPATCHER_THREAD #" + myID + ": ";
		this.currentVM = vm;
		this.currentRequest = request;
		this.startDispatchingDate = date;
	} // public ListenerSocketThread(Socket socket) {..}
	
	
	/**
	 * Simply sends the request to the VM.
	 * If errors or exceptions occur the request is readded to the blocking queue.
	 * Anyway at the end the status of the application is set to IDLE 
	 */
	public void run() {
			
		boolean errore = false;
		Socket socketToVM = null;
		try{
			String serverName = currentVM.getMyIP();
			int serverPort = currentVM.getAppPort(currentRequest.getApplicationName());
			System.out.println(debug + "\n\tConnect to serverName = " + serverName + ":" + serverPort);
			
			// Apro una socket con la VM
			socketToVM = new Socket(serverName, serverPort);
			socketToVM.setSoTimeout(this.socketTimeout);
			
			// BufferedWriter per leggere/scrivere comodamente stringhe dalla/nella socket
			BufferedWriter writerToSocket = new BufferedWriter(new OutputStreamWriter(socketToVM.getOutputStream()));
			BufferedReader readerFromSocket = new BufferedReader(new InputStreamReader(socketToVM.getInputStream()));
			
			Date startCommunication = new Date();
	
			// Wait ACK
			String inputLine = new String();
			inputLine = readerFromSocket.readLine();
			System.out.println(debug + "Received: " + inputLine);
			if(!inputLine.trim().equalsIgnoreCase("ACK")){
				System.out.println(debug + "ACK 1 error. InputLine is: "+inputLine);
				errore = true; 
			}
			
			if(!errore){
				// Send Data ====> INFO #1 - Request ID
				writerToSocket.write( String.valueOf(currentRequest.getId()) );
				writerToSocket.write('\n');
				System.out.println(debug + "Request ID = " + currentRequest.getId());
				writerToSocket.flush();
				// Wait ACK
				inputLine = new String();
				inputLine = readerFromSocket.readLine();
				System.out.println(debug + "Received: " + inputLine);
				if(!inputLine.trim().equalsIgnoreCase("ACK")){
					System.out.println(debug + "ACK 2 error...");
					errore = true;
				}
			}
			
			if(!errore){
				// Send Data ====> INFO #1 - Command
				writerToSocket.write( currentRequest.getPostString() );
				writerToSocket.write('\n');
				System.out.println(debug + "Command = " + currentRequest.getPostString());
				writerToSocket.flush();
				// Wait ACK
				inputLine = new String();
				inputLine = readerFromSocket.readLine();
				System.out.println(debug + "Received: " + inputLine);
				if(!inputLine.trim().equalsIgnoreCase("ACK")){
					System.out.println(debug + "ACK 3 error...");
					errore = true;
				}
			}
			
			Date finishCommunication = new Date();
						
			long communicationTime = finishCommunication.getTime() - startCommunication.getTime();
			dataColl.addDispatcherToVMTime((double)communicationTime);
			
			writerToSocket.close();
			readerFromSocket.close();
			socketToVM.close();
			Date finishDispatchingTime = new Date();
			long dispatchingTime = finishDispatchingTime.getTime() - startDispatchingDate.getTime();
			dataColl.addDispatchingTime( (double) dispatchingTime);
			
			if(errore){
				System.out.println(debug + "Readding request to queue...");
				currentRequest.setErrorNumbers(currentRequest.getErrorNumbers()+1);
				QueuedRequest.getInstance().addRequestToQueue(currentRequest, false);				
			}else{
				System.out.println(debug + "File INVIATO!!!");
				currentRequest.setVM_IP(currentVM.getMyIP());
				currentVM.addRequest(currentRequest);
				AssignedRequest.getInstance().addRequest(currentRequest);
			}

		} catch (IOException e) { 
			if(currentRequest != null){
				if(socketToVM != null)
					try {
						socketToVM.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				currentRequest.setErrorNumbers(currentRequest.getErrorNumbers()+1);
				QueuedRequest.getInstance().addRequestToQueue(currentRequest, false);
			}
			e.printStackTrace(); 
		} 
		
		if(currentVM != null){
			currentVM.setAppStatus(currentRequest.getApplicationName(), VirtualMachine.AppStatus.IDLE);
		}

	} // public void run() {..}
	
} // public class ListenerSocketThread extends Thread {..}
