package it.unipr.dsg.awm.util;

/**
 * This interface is used to create classes that read from a generic Db and return then
 * for elaboration.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public interface Storer {

	/**
	 * This is the only method to override.
	 * @param filename - The name of the file containing the Db
	 * @return Data of the Db in String format
	 */
	public String getFileInStringFormat(String filename);

}
