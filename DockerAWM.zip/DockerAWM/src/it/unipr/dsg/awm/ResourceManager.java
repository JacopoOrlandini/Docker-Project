package it.unipr.dsg.awm;

import it.unipr.dsg.awm.controller.Controller;
import it.unipr.dsg.awm.controller.FrancisController;
import it.unipr.dsg.awm.controller.IntegralController;
import it.unipr.dsg.awm.controller.ModelPredictiveController;
import it.unipr.dsg.awm.controller.MoreThresholdController;
import it.unipr.dsg.awm.controller.QoSModeler;
import it.unipr.dsg.awm.controller.QuadThresholdController;
import it.unipr.dsg.awm.controller.ThresholdController;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineCleaner;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineCreator;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineScaler;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

import java.io.IOException;
import java.util.Date;

/**
 * This class is responsible of manage the auto-scaling of the entire system. It
 * is implemented has a separate Thread.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @author Modified by Federico Torreggiani - March 2017
 *
 */
public class ResourceManager extends Thread {
	/**
	 * Debug string
	 */
	private static String debug = "RESOURCE_MANAGER - ";

	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();

	private Controller controller;

	/** Autonomic Behavior Variables **/
	private int k_min = 5, k_max = 24;

	private int updatePeriod = 5; // minutes

	private SimulationManager simulationManager;

	/** Autonomic Behavior Variables **/
	private Date start, finish = null;
	private Date globalStart = null;

	/**
	 * Constructor of the class. It set some parameters and creates the first
	 * Virtual Machines.
	 * 
	 * @throws InterruptedException
	 */
	public ResourceManager() throws InterruptedException {
		this.k_min = testParam.getMinVM();
		printDebug(debug + "this.k_min = " + this.k_min);
		this.k_max = testParam.getMaxVM();
		printDebug(debug + "this.k_max = " + this.k_max);
		this.updatePeriod = testParam.getSamplingPeriod();
		printDebug(debug + "this.updatePeriod = " + this.updatePeriod);

		// Create the first VM
		for (int i = 0; i < k_min; i++) {
			VirtualMachineCreator vmCreator = new VirtualMachineCreator();
			vmCreator.start();
		}
	}

	private void printDebug(String s) {
		System.out.println(s);
		dataColl.addControllerString(s);
	}

	/**
	 * Routine to manage the auto-scaling policies.
	 */
	public void run() {
		// Wait that all VMs are started
		while (vmStack.getSize() != k_min) {
			try {
				Thread.sleep(10 * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		printDebug(debug + "Yes!! All VMs are started!!");

		/** CHOOSING CONTROLLER **/
		switch (testParam.getWhichController()) {
		case Integral:
			this.controller = new IntegralController();
			break;
		case Francis:
			this.controller = new FrancisController();
			break;
		case Threshold:
			this.controller = new ThresholdController();
			break;
		case QuadThreshold:
			this.controller = new QuadThresholdController();
			break;
		case MoreThresholdController:
			this.controller = new MoreThresholdController();
			break;
		case ModelPredictiveController:
			this.controller = new ModelPredictiveController();
			break;
		default:
			this.controller = null;
			break;
		}
		/** CHOOSING CONTROLLER **/

		/** Starting the SimulationManager Thread **/
		simulationManager = new SimulationManager(k_min, k_max, controller);
		simulationManager.start();

		Runtime.getRuntime().addShutdownHook(new VirtualMachineCleaner());

		// Enter in the infinite loop
		// Each 5 minutes check-up the cloud status
		globalStart = new Date();
		while (true) {
			/** WAITING PART **/
			printDebug(debug + "Ok, attendo " + this.updatePeriod + " minuti...");
			long elapsed = 0;
			if (start != null && finish != null)
				elapsed = finish.getTime() - start.getTime();
			try {
				Thread.sleep((updatePeriod * 60 * 1000) - elapsed);
			} catch (InterruptedException e) {
				printDebug(debug + "Unable to sleep the sample period...");
				e.printStackTrace();
			}
			// Collect new Data Info for final result
			this.dataColl.collectNewData();
			this.qos.collectNewData();
			/** WAITING PART **/

			/** CONTROL PART **/
			// start = new Date();
			printDebug(debug + "Controllo lo stato del sistema e determino se � necessario"
					+ " effettuare un'operazione di scaling.");

			int kPrevious = vmStack.getSize();
			int deltaVM = 0;
			if (this.controller != null)
				deltaVM = this.controller.nextVMDelta();

			int kCurrent = kPrevious + deltaVM;
			dataColl.addControllerResult(kCurrent);
			dataColl.addProcesses(vmStack.getSize());
			dataColl.addActiveProcesses(vmStack.getNumOfActiveVM());
			dataColl.addRequests(QueuedRequest.getInstance().getRequestQueueSize()
					+ AssignedRequest.getInstance().getAssignedRequestSize());
			dataColl.addRequestsPerSample(qos.getWindowedRequestsArrivals(testParam.getSamplingPeriod() * 60 * 1000));
			printDebug(
					debug + "kCurrent (" + kCurrent + ") - kPrevious (" + kPrevious + ") = " + "deltaVM = " + deltaVM);
			if (this.controller != null) {
				double Ju = dataColl.computeMPCCostFunction(deltaVM);
				dataColl.addMPCObjectiveFunction(Ju);
			}

			if (deltaVM == 0)
				printDebug(debug + "kCurrent == kPrevious");
			else if (deltaVM > 0)
				VirtualMachineScaler.scaleUpStack(deltaVM);
			else if (deltaVM < 0)
				VirtualMachineScaler.scaleDownStack(deltaVM);
			// }
			/** CONTROL PART **/

			finish = new Date();
			int elapsedGlobalTime = (int) ((finish.getTime() - globalStart.getTime()) / 1000) / 60;
			printDebug(debug + "Total Time From Start (after VMs Stacks ready) = " + elapsedGlobalTime + "minutes");
		} // while(true) {..}

	} // public void run() {..}

}