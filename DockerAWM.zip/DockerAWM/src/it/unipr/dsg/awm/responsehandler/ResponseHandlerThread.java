package it.unipr.dsg.awm.responsehandler;

import it.unipr.dsg.awm.AppRequestInfo;
import it.unipr.dsg.awm.AssignedRequest;
import it.unipr.dsg.awm.controller.QoSModeler;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Date;

/**
 * This class depends from {@link ResponseHandler} class and has the responsibility
 * of managing a response received from a VM.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class ResponseHandlerThread extends Thread {
	private String debug = null;
	
	private int myID;
	private Socket socketVM = null;
	
	private AssignedRequest assignedRequest = AssignedRequest.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();
	
	/**
	 * The constructor set the thead ID and the communication socket between CloudAWM and the VM.
	 * @param id - the thread ID
	 * @param socket - socket between CloudAWM and the VM.
	 */
	public ResponseHandlerThread(int id, Socket socket) {
		this.myID = id;
		this.socketVM = socket;
		this.debug = "RESPONSE_HANDLER_THREAD #" + myID + " - ";
	}
	
	/**
	 * Actions:
	 * 
	 * 1. Receive the response
	 * 2. Search the request by ID in the assigned request vector
	 * 3. If fail return
	 * 4. If success send the response to the sender of the request
	 * 5. Remove the request from the assigned request vector
	 * 6. If errors or exceptions occur the request is anyway removed
	 */
	public void run() {
		System.out.println(debug + "START!!");
		BufferedWriter writerToVM = null;
		BufferedReader readerFromVM = null;
		BufferedWriter writerToNodeJS = null;
		AppRequestInfo currentRequest = null;
		try {
			// Reader/Writer per la socket con la VM che ha inviato la risposta
			writerToVM = new BufferedWriter(new OutputStreamWriter(socketVM.getOutputStream()));
			readerFromVM = new BufferedReader(new InputStreamReader(socketVM.getInputStream()));
			
			Date startCommunication = new Date();
			
			// Informo la VM che sono pronto per ricevere informazioni
			// ReadyACK =====> VM
			writerToVM.write("ACK");
			writerToVM.write('\n');
			writerToVM.flush();
			System.out.println(debug + "=====> ACK");
			
			// INFO #0 <===== Wait Id Request
			String idRequest = readerFromVM.readLine();
			System.out.println(debug + "<===== idRequest: " + idRequest);

			// Informo la VM che ho ricevuto l'ID
			// ReadyACK =====> VM
			writerToVM.write("ACK");
			writerToVM.write('\n');
			writerToVM.flush();
			System.out.println(debug + "=====> ACK");
			
			// INFO #1 <===== Wait Info
			String infoString = readerFromVM.readLine();
			System.out.println(debug + "<===== InfoString: " + infoString);

			// Informo la VM che ho ricevuto correttamente la risposta
			// ReadyACK =====> VM
			writerToVM.write("ACK");
			writerToVM.write('\n');
			writerToVM.flush();
			System.out.println(debug + "=====> ACK");
			
			currentRequest = 
					AssignedRequest.getInstance().searchRequestByID(idRequest);
			
			if(currentRequest == null){
				System.out.println(debug + "Search request by ID (" + idRequest + ") failed.");
				socketVM.close();
				return;
			}
			
			qos.addExecutionTimeValue(currentRequest.getExecutionTime()/1000.0);
			
			// Retrieve socket with NodeJS
			Socket socketNodeJS = currentRequest.getSocketInfo();
			// Define writer for send data to NodeJS
			writerToNodeJS = new BufferedWriter(new OutputStreamWriter(socketNodeJS.getOutputStream()));

			writerToNodeJS.write(infoString);
			
			
			Date finishCommunication = new Date();
			long communicationTime = finishCommunication.getTime() - startCommunication.getTime();
			dataColl.addVMToRespHandThreadTime((double)communicationTime);
			
			String vmIP = currentRequest.getVM_IP();
			VirtualMachine currentVM = vmStack.getVMByIP(vmIP);
			if( currentVM == null )
				 System.err.println(debug + "VM not found!!");
			else currentVM.removeRequest(currentRequest);	

			// Remove Request from AssignedRequest Vector
			assignedRequest.removeRequest(currentRequest);
			
			writerToVM.close();
			readerFromVM.close();
			writerToNodeJS.close();
			
		} catch (IOException e) { 
			e.printStackTrace();
			try {
				if(writerToVM != null) writerToVM.close();
				if(readerFromVM != null)readerFromVM.close();
				if(writerToNodeJS != null) writerToNodeJS.close();
				if(currentRequest != null) assignedRequest.removeRequest(currentRequest);
			} catch (IOException e1) { e1.printStackTrace(); }

		}
		
	} // public void run() {..}
	
} // public class ResponseHandlerThread() {..}
