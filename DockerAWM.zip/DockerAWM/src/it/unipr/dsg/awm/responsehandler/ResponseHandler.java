package it.unipr.dsg.awm.responsehandler;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This class is responsible to receive and manage all the responses that VMs sent.
 * For any new response this class starts a new management thread.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class ResponseHandler extends Thread {
	private static String debug = "RESPONSE_HANDLER - ";
	private int serverPort = 5681;
		
	/**
	 * Does nothing...
	 */
	public ResponseHandler() {}
	
	/**
	 * Simply starts a new thread for any new response.
	 */
	public void run() {
		System.out.println(debug + "START!!!");
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(serverPort, 500);
		} catch (IOException e1) { 
			System.err.println(debug + "Could not listen on port " + serverPort);
        	System.exit(-1);
        }
		
		int threadId = 0;
    	while(true) {
    		try {
				Socket socket = serverSocket.accept();
				
				System.out.println(debug + "<===== New RESPONSE Received!!!");
				ResponseHandlerThread respHandlerThread = new ResponseHandlerThread(threadId, socket);
				respHandlerThread.start();
				
				threadId++;
			} catch (IOException e) {
				e.printStackTrace();
				try { serverSocket.close(); } catch (IOException e1) { e1.printStackTrace(); }
			}
    	} // while(true) {..}
	} // public void run() {..}
	
}
