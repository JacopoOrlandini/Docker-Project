package it.unipr.dsg.awm;

import it.unipr.dsg.awm.servicebroker.ServiceBroker;
import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import org.json.simple.parser.ParseException;

/**
 * This class implements a Thread that periodically contact the active VMS in the Cloud
 * to verify their state.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class CheckUpServer extends Thread {
	/**
	 * String used for debug prints.
	 */
	private static String debug = "CHECKUP_SERVER - ";
	
	/**
	 * Seconds determining the period of the CheckUp Server. 
	 * Every "waitingSeconds" seconds will be made a test from the server.
	 */
	private int waitingSeconds = 5*60;
	
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	
	public CheckUpServer() {}
	
	/**
	 * This method contains the protocol used to contact the "checkUp" service installed
	 * by default on the VMs.
	 * @param vm The Virtual Machine to contact
	 * @throws IOException if the configuration file is not reachable
	 * @throws ParseException if there is an error during parsing the configuration file
	 */
	private void protocol(VirtualMachine vm) throws IOException, ParseException{
		
		int port = ServiceBroker.getCheckUpPort();
    	try(Socket s = new Socket(vm.getMyIP(), port)) {
    		s.setSoTimeout(5000);
    		BufferedWriter writerToSocket = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
    		writerToSocket.write( "CHECK_UP" );
			writerToSocket.flush();
			
			BufferedReader readerFromVM = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String risp = readerFromVM.readLine();
			System.out.println(debug + "Received " + risp + " from VM (" + vm.getMyIP() + ")");
		
    		s.close();

    		if(risp.equals("ACK")){    		
	    		System.out.println(debug + "VM (" + vm.getMyIP() + ") check-up success!! Set status to ACTIVE...");
	    		vm.setVMStatus(VirtualMachine.Status.ACTIVE);
    		}else{
	    		System.out.println(debug + "VM (" + vm.getMyIP() + ") check-up failure!! Set status to INTERRUPT...");
	    		vm.setVMStatus(VirtualMachine.Status.INTERRUPT);
    		}
    	}catch(Exception e){
    		System.out.println(debug + "Exception in contacting VM " + vm.getMyIP() + ". Set status to INTERRUPT...");
    		vm.setVMStatus(VirtualMachine.Status.INTERRUPT);
    	}
	}
	
	public void run() {
		
		while(true) {
			
			try{
				int sec = ServiceBroker.getWaitingSecondsCheckUpServer();
				if(sec == 0) sec = this.waitingSeconds;
				System.out.println(debug + "Waiting " + sec + " seconds...");
				Thread.sleep(sec * 1000);
			}catch(InterruptedException e){ e.printStackTrace(); }
			
			try {
				
				for(int i = 0; i < vmStack.getSize(); i++){
					VirtualMachine vm = vmStack.getVMByIndex(i);
					if(vm.getVMStatus().equals(VirtualMachine.Status.ACTIVE) ||
							vm.getVMStatus().equals(VirtualMachine.Status.INTERRUPT)){
						
						protocol(vm);
					}
				}
				
			} catch (IOException | ParseException e) { 
				e.printStackTrace();
			}
			
		}//while(true)..
	} // public void run() {..}
	
} // public class SpeedUpServer
