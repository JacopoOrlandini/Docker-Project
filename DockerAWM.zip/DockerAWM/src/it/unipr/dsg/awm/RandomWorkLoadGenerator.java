package it.unipr.dsg.awm;

import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

/**
 * UTILIZZO
 * 
 * 1) deve essere asincrono
 * 2) aggiunge un carico dinamico W dopo un tempo T
 * 
 * W : int, rappresenta le richieste da aggiungere.
 * T : minuto, rappresenta l'istante per aggiungere il carico dinamico.
 * S : request
 * date: request time
 */
public class RandomWorkLoadGenerator extends Thread{
	private static String debug = "DOCKER_RESOURCE_MANAGER - ";
	private int W;	//max value for request for randomRequest
	private int T;	//max value for time for randomTime
	private int RR;
	public ArrayList<Integer> notServed ;
	private Vector<String> S;
	private Vector<Date> dates;
	Random random;
	static final private long SEED = (long) (3.0); 	//for simulation replicability
	
	public RandomWorkLoadGenerator(int w, int t, int rR, Vector<String> in1, Vector<Date> in2) {
		this.setW(w);
		this.setT(t);
		this.setRR(rR);
		this.setS(in1);	// quando richiamo S, vector deve essere gia inizializzato.
		setDates(in2);
		this.notServed = new ArrayList<Integer>();
		random = new Random(SEED);
		System.out.println(debug+ ": Creata istanza della classe");

	}

	@Override
	public void run() {
		int randomTimes = random.nextInt() % RR;
		for (int j = 0; j < randomTimes; j++) {
			try {
				int randomDelay = random.nextInt() % T;
				Thread.sleep(randomDelay * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			notServed.add(S.size());
			System.out.println("Richieste not served =" + S.size());
			int randomRequests = random.nextInt() % W;
			for (int i = 0; i < randomRequests; i++) {
				S.add(0, "start_task");
				dates.add(0, new Date());
			}
			System.out.println(debug+" : Settate le nuove richieste");	
		}
		
	}

	public static String getDebug() {
		return debug;
	}

	public static void setDebug(String debug) {
		RandomWorkLoadGenerator.debug = debug;
	}

	public int getW() {
		return W;
	}

	public void setW(int w) {
		W = w;
	}

	public int getT() {
		return T;
	}

	public void setT(int t) {
		T = t;
	}

	public Vector<String> getS() {
		return S;
	}

	public void setS(Vector<String> s) {
		S = s;
	}

	public Vector<Date> getDates() {
		return dates;
	}

	public void setDates(Vector<Date> dates) {
		this.dates = dates;
	}

	public int getRR() {
		return RR;
	}

	public void setRR(int rR) {
		RR = rR;
	}

}
