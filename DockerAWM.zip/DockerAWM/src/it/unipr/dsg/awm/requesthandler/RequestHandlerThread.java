package it.unipr.dsg.awm.requesthandler;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Date;

import it.unipr.dsg.awm.AppRequestInfo;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.log.DataCollector;

/**
 * This class depends from {@link RequestHandler} class and made a very simple thing:
 * it put a request in the blocking queue {@link QueuedRequest}.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class RequestHandlerThread extends Thread {
	private static String debug = null;
	
	private int myID;
	private Socket socket = null;
	
	private DataCollector dataColl = DataCollector.getInstance();
	
	/**
	 * The constructor sets the ID of the thread and the socket between the sender of the request and CloudAWM.
	 * @param id - the ID of the thread
	 * @param socket - the socket between the sender of the request and CloudAWM.
	 */
	public RequestHandlerThread(int id, Socket socket) {
		this.myID = id;
		debug = "REQUEST_HANDLER_THREAD #" + myID + ": ";
		this.socket = socket;
	}
	
	/**
	 * Creates the new request object ({@link AppRequestInfo}) and puts it in the blocking queue
	 * {@link QueuedRequest}
	 */
	public void run() {
		System.out.println(debug + "START!!!");
		Date startCommunication = new Date();
		try {
			// BufferReader per leggere i dati che arrivano sulla socket
			BufferedReader incomingData = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			// Leggo il nome dell'applicazione
			String appName = incomingData.readLine();
			System.out.println(debug + "=====> Received: " + appName);
			
			String command = incomingData.readLine();
			System.out.println(debug + "=====> Received: " + command);
			
			if(appName == null || appName == "" ){
				
				System.out.println(debug + "Malformed request. Discarding...");
				this.socket.close();
			} else {
				
				//System.out.println(debug + "Request correct...");
				// Genero il nuovo oggetto che rappresenta la richiesta appena "catturata"
				AppRequestInfo newRequest = new AppRequestInfo(this.socket);
				
				newRequest.setApplicationName(appName);
				newRequest.setPostString(command);
	
				System.out.println(debug + "Adding the request...");
				QueuedRequest.getInstance().addRequestToQueue(newRequest, true);
				System.out.println(debug + "Request added...");
								
			}
			
			Date finishCommunication = new Date();
			long communicationTime = finishCommunication.getTime() - startCommunication.getTime();
			dataColl.addNodeJStoReqHandThreadTime((double)communicationTime);
			
		} catch (Exception e) { e.printStackTrace(); }
		
		System.out.println(debug + "END!!!");
	} // public void run() {..}
	
} // public class ListenerSocketThread extends Thread {..}
