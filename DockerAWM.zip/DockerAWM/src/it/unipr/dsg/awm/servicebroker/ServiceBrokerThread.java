package it.unipr.dsg.awm.servicebroker;

import it.unipr.dsg.awm.virtualmachine.VirtualMachine;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * Class that manages registration or cancellation requests arrived from the application
 * activated on the Virtual Machines.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class ServiceBrokerThread extends Thread {
	private String debug = null;
	
	private int myID;
	private Socket socketVM = null;
	
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	
	/**
	 * Sets the thread ID and the socket established between CloudAWM and the Virtual Machine.
	 * @param id - the thread ID
	 * @param socket - the socket established between CloudAWM and the Virtual Machine
	 */
	public ServiceBrokerThread(int id, Socket socket) {
		this.myID = id;
		this.socketVM = socket;
		this.debug = "SERVICE_BROKER_THREAD #" + myID + " - ";
	}
	
	/**
	 * Manages a request of registration or cancellation.
	 * The request has to be in the format "Action:AppName:Port" where Action could be "Register" or "Remove".
	 * Possible responses are:
	 * 
	 * - ACK-100: Invalid action
	 * - ACK-200: Erroneous format
	 * - ACK-300: Error in registering service
	 * - ACK-400: Ok
	 * - ACK-500: Error in removing service
	 */
	public void run() {
		System.out.println(debug + "START!!");
		try {
			// Reader/Writer per la socket con la VM che ha inviato la risposta
			BufferedWriter writerToVM = new BufferedWriter(new OutputStreamWriter(this.socketVM.getOutputStream()));
			BufferedReader readerFromVM = new BufferedReader(new InputStreamReader(this.socketVM.getInputStream()));
					
			// Informo la VM che sono pronto per ricevere informazioni
			// ReadyACK =====> VM
			writerToVM.write("ReadyACK\n");
			writerToVM.flush();
			System.out.println(debug + "=====> ReadyACK");
			
			// INFO #1 <===== Wait App Identification
			String info = readerFromVM.readLine();
			System.out.println(debug + "<===== Received: " + info);

			//Elab the received info. The format has to be "Action:AppName:Port"
			String[] parts = info.trim().split(":");
			if(parts.length != 3){
				writerToVM.write("ACK-200");
				writerToVM.flush();
				System.out.println(debug + "Erroneous format");
			}else{
				String action = parts[0];
				String appName = parts[1];
				String port = parts[2];
				String IP = this.socketVM.getRemoteSocketAddress().toString();
				IP = IP.substring(1, IP.lastIndexOf(":"));
				System.out.println(debug + "RemoteIP: " + IP + " RemotePort: " + port + 
						" RemoteApp: " + appName + " Action: " + action);
				
				if(action.equalsIgnoreCase("register")){
					VirtualMachine vm = vmStack.getVMByIP(IP);
					if(vm == null || !vm.addService(appName, Integer.parseInt(port))){
						writerToVM.write("ACK-300");
						writerToVM.flush();
						System.out.println(debug + "Error in registering service");
					}else{
						writerToVM.write("ACK-400");
						writerToVM.flush();
						System.out.println(debug + "Register Ok");
					}
				}else{
					if(action.equalsIgnoreCase("remove")){	
						VirtualMachine vm = vmStack.getVMByIP(IP);
						if(vm == null || !vm.removeService(appName)){
							writerToVM.write("ACK-500");
							writerToVM.flush();
							System.out.println(debug + "Error in removing service");
						}else{
							writerToVM.write("ACK-400");
							writerToVM.flush();
							System.out.println(debug + "Remove Ok");
						}
					}else{
						writerToVM.write("ACK-100");
						writerToVM.flush();
						System.out.println(debug + "Invalid command");
					}
				}
				
			}
						
			writerToVM.close();
			readerFromVM.close();
			
		} catch (IOException e) { e.printStackTrace(); }
		
	} // public void run() {..}
	
} // public class ResponseHandlerThread() {..}
