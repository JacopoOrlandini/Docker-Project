package it.unipr.dsg.awm;

import java.io.IOException;

public class DockerContainerWrapper {

	/*Status
	 * 0:idle
	 * 1:finished
	 * 3: to delete
	 */
	private static String debug = "[CONTAINER]";
	public int status; 
	public String containerID;
	public Process process;
	public double CPU;
	private int id;
	private int port;
	
	
	public DockerContainerWrapper(String image, int id, int port ) throws IOException {
		this.process = Runtime.getRuntime().exec("python "+image+".py s"+id+" "+ port);
		this.setId(id);
		this.CPU = 0;
		this.setPort(port);
		this.status = 0;
		System.out.println(debug+": "+id+" "+port+" "+status);
	}
	public int getStatus() {
		return status;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
