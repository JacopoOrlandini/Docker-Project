package it.unipr.dsg.awm.virtualmachine;

import it.unipr.dsg.log.TestParameters;

/**
 * This class contains 2 static methods for scaling up and scaling down the Cloud
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class VirtualMachineScaler {

	private static String debug = "VIRTUAL MACHINE SCALER - ";
	
	/**
	 * Does nothing...
	 */
	public VirtualMachineScaler() {}
	
	/**
	 * This method call "howManyVM" times the class {@link VirtualMachineCreator}
	 * @param howManyVM - The number of VM to allocate
	 */
    public static void scaleUpStack(int howManyVM) {
    	System.out.println(debug + " ==> scaleUpStack(..) {..}");
    	
    	int k_max = TestParameters.getInstance().getMaxVM();
    	int k_min = TestParameters.getInstance().getMinVM();
    	
    	if(howManyVM > (k_max-k_min)) {
    		System.out.println("\tWARNING: You are trying to activate more VMs" + 
    						   "than is attivabile in the update period!!!");
    		howManyVM = (k_max-k_min);
    	}
    	    	
    	for(int i=0; i<howManyVM; i++) {
    		VirtualMachineCreator vmCreator = new VirtualMachineCreator();
    		vmCreator.start();
    	}
    } 
    
    /**
     * This method call "howManyVM" times the class {@link VirtualMachineDestroyer}
     * @param howManyVM - The number of Virtual Machine to destroy
     */
    public static void scaleDownStack(int howManyVM) {
    	System.out.println(debug + " ==> scaleDownStack(" + howManyVM + ") {..}");
    	
    	for(int i=0; i<Math.abs(howManyVM); i++) {
	    	// Scelgo la VM con la coda pi� breve
	    	VirtualMachine vmToDestroy = VirtualMachineStack.getInstance().getVMWithLessRequest();
	    	
	    	if(vmToDestroy == null) {
	    		System.out.println(debug + "\tvmToDestroy == null!!!!");
	    	} else {
	    		System.out.println(debug + "\tvmToDestroy IPv4 = " + vmToDestroy.getMyIP());
	    		// Imposto lo stato della VM a DESTRUCTION in modo che non venga pi� considerata dal Dispatcher
	    		vmToDestroy.setVMStatus(VirtualMachine.Status.DESTRUCTION);
	    		System.out.println(debug + "\tvmToDestroy IPv4 = " + vmToDestroy.getMyIP() + "--> STATE : DESTRUCTION");
	    		
	    		VirtualMachineDestroyer vmDestroyer = new VirtualMachineDestroyer(vmToDestroy);
	    		vmDestroyer.start();
	    	} 
    	} 
    } // scaleDownStack(..) {..}

}
