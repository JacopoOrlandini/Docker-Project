package it.unipr.dsg.awm;

import it.unipr.dsg.awm.controller.QoSModeler;
import it.unipr.dsg.awm.dispatcher.Dispatcher;
import it.unipr.dsg.awm.requesthandler.RequestHandler;
import it.unipr.dsg.awm.responsehandler.ResponseHandler;
import it.unipr.dsg.awm.servicebroker.ServiceBroker;
import it.unipr.dsg.log.TestParameters;
import it.unipr.dsg.log.TestParameters.SimulationType;
import it.unipr.dsg.awm.controller.FrancisController;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import org.json.simple.parser.ParseException;



/**
 * This class is the main class of CloudAWM.
 * It is the first class to be called and it starts all other threads needed for
 * the correct execution of CloudAWM.
 * It has also the target of collecting all the parameters needed from the other classes
 * and needed for possible simulations.
 * 
 * In particular this class creates 8 threads:
 * 
 * The {@link ResourceManager} thread;
 * The {@link RequestHandler} thread;
 * The {@link Dispatcher} thread;
 * The {@link ResponseHandler} thread;
 * The {@link ConsoleListener} thread;
 * The {@link ServiceBroker} thread;
 * The {@link SpeedUpServer} thread;
 * The {@link CheckUpServer} thread;
 * 
 * In the version 1.0 the data are read from a JSON file situated in the relative path json/db.json.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @author Federico Torreggiani - March-August 2017 
 *
 */

public class AutonomicWorkloadManager {
	private static final int CPU_IDLE = 3;

	private static String debug = "AUTONOMIC_WORKLOAD_MANAGER - ";
	
	/*Sono inseriti tutti i parametri della simulazione quindi come funzionera il sistema.
	 * Posso facilmente prendere tutti i parametri con get e set.*/
	private static TestParameters testParam = TestParameters.getInstance();
	
	private static QoSModeler qos = QoSModeler.getInstance();
	private static InputStreamReader reader = new InputStreamReader (System.in);
    private static BufferedReader myInput = new BufferedReader (reader);
	
    // Starting point 
	public static void main( String[] args ) throws Exception {

		System.out.println("                                                                                                \n" + 

				"                             `':':':':'':':':':':;:;:;:;':':':':'':':':':'    `':::::;;;;;;;;;',                \n" + 
				"                             `':;:;:;:'':;:;:;:':::::::;':;:;:;:'':;:;:;:'     '':::;;;;;;;;;''                 \n" + 
				"                             `':::::::'':::::::':::::::;':::::::'':::::::'  ,''';:::;;;;;;;;''                  \n" + 
				"                         ,'''''''''''''''''''''''''''''''''''''''''''''''''''';::::;;;;;;;'''                   \n" + 
				"                         '';::::::::::::::::::::::::::::::::::::::::::::::::::::::;;'''''''`                    \n" + 
				"                         '';::::::::::Progetto Sistemi orientati ad Internet::::::::;:',,,                        \n" + 
				"                         '';:::::::::::::::::::::::::::::::::::::::::::::::::::::;;''                           \n" + 
				"                         ;';;:::::::::::::::::::::::::::::::::::::::::::::::::::;;;',                           \n" + 
				"                         :';;::::::::::::::::::::DOCKER:ORLANDINI::::::::::::::::::;;;'                            \n" + 
				"                         `';;::::::::::::::::::::::::286416::::::::::::::::;;;'.                            \n" + 
				"                          ';;:::::::::::::::::::::::::::::::::::::::::::::::::;;;''                             \n" + 
				"                          ';;:::::::::::::::::::::::::::::::::::::::::::::::::;;;'                              \n" + 
				"                          '';;:::::::::::::::::   :::::::::::::::::::::::::::;;;';                              \n" + 
				"                          ,';;:::::::::::::::: ;'  :::::::::::::::::::::::::;;;''                               \n" + 
				"                           ';;;::::::::::::::: ''' ::::::::::::::::::::::::;;;''                                \n" + 
				"                           '';;:::::::::::::::. ' .:::::::::::::::::::::::;;;;'`                                \n" + 
				"                            ';;;:::::::::::::::,`,:::::::::::::::::::::::;;;;',                                 \n" + 
				"                            '';;:::::::::::;::::::::::::::::::::::::::::;;;;':                                  \n" + 
				"                             ';;;::::::::'''::::::::::::::::::::::::::;;;;;':                                   \n" + 
				"                             ;';;;:::;'''',  ::::::::::::::::::::::::;;;;''`                                    \n" + 
				"                              ''''''''':     ,:::::::::::::::::::::;;;;;''                                      \n" + 
				"                               ''             :::::::::::::::::::;;;;;'';                                       \n" + 
				"                                ''             ::::::::::::::::;;;;;;''`                                        \n" + 
				"                                 '':            ,:::::::::::;;;;;;;'':                                          \n" + 
				"                                  :''.            ::::::;;;;;;;;''':                                            \n" + 
				"                                    ''':           .;;;;;;;;;''''`                                              \n" + 
				"                                      ;'''':.        `;;''''''.                                                 \n" + 
				"                                         ,''''''''''''''';`                                                     \n" + 
				"                                                                      ");
		

		 
		// Variables for Docker Implementation
		inputParameters();
		//setto id e porte iniziali per mantenere coerente l'assegnazione dei container
		// TODO quando rimuovo un container potrei riassociare il nome e la porta
		int sT = 10;	//periodo campionamento in secondi
		int port = 4000;	
		int id = 0;		//nome del container s[id], esempio se id = 0 il container viene chiamato s0.
		int staticWork = 10;		// carico iniziale di richieste del sistema
		int slots = 0;
		List<Integer> containerAllocated = new ArrayList<>();	//mantengo il numero di container allocati durante il sampling
		Vector<Date> startTimeRequest= new Vector<Date>();	
		Vector<Date> endTimeRequest= new Vector<Date>();
		Vector<String> requests = new Vector<String>();			// Carico delle richieste del sistema
		Vector<DockerContainerWrapper> pool = new Vector<DockerContainerWrapper>(); //wrapper per mantenere info sul container 
		

		/*INITIAL RESET
		 * Attenzione elimina tutti i container presenti*/
		cleanSession();
		/*END RESET*/
		
		
		/*CREATE IMAGE: SERVERAPP*/
		System.out.println("Wait building Image SERVERAPP\nTakes a few seconds...");
		Process createImage = Runtime.getRuntime().exec("python "+"createImage"+".py");
		createImage.waitFor();
		/*END IMAGE*/
		
		/*SIMULTAION TYPE
		 * 0: francis controller
		 * 1: no controller*/
		int simulation;
		System.out.println("Inserire 0 per francis o 1 per no Controller");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		simulation = sc.nextInt();

		int kmin = 0;
		if(simulation == 0)
			kmin = 2;
		else
			kmin = 5;
			
		/*CREO KMIN CONTAINER ALLO START
		 * SETTABILE ANCHE A 0
		 * Numoro di container inizialmente caricati dal sistema.*/
		for (int i = 0; i < kmin; i++) {
			pool.add(new DockerContainerWrapper("startContainer", id, port));
			id++;
			port++;
		}
		
		/*START WORKLOAD GENERATOR
		 * Generatore delle richieste dinamiche per il sistema
		 *  @param dynamicWork = quante richieste vengono inserite in coda
		 *  @param delay = quanto aspetta prima di inviare le richieste.
		 *  Tutte le richieste al momento sono uguali facilmente estendibile avere sia tempi che numero richieste differenti.
		 * */ 
		int dynamicWork = 20;	//valore massimo di richieste caricabile sul sistema
		int delay = 50;	// tempo di attesa massimo prima di inviare nuove richieste
		int times = 6;	//numero casuale massimo di volte che carico delle richiste
		/*
		 * Esempio potri caricare al massimo 20 richiste ogni 50 secondi per 6 volte
		 * Per un totale di 120 richieste in 300 secondi */
		RandomWorkLoadGenerator wlg = new RandomWorkLoadGenerator(dynamicWork, delay, times, requests, startTimeRequest);
		wlg.start();
		/*END WORKLOADGENERATOR*/

		/*START FRANCIS CONTROLLER*/
		FrancisController frC = new FrancisController();	//i parametri vengono da TestParam
		System.out.println("-------------------------------------");
		/*END FRANCIS CONTROLLER*/
		
		/* ADDING REQUESTS AND START DATES TO AWM */
		for (int i = 0; i < staticWork; i++) {
			requests.add(0, "start_task");	// element added at the beggining
			startTimeRequest.add(0, new Date());	// Aggiungo la data di richiesta iniziale del thread da eseguire	
		}
		System.out.println(debug+" Added requests");
		frC.setRequest(requests.size());	// set request value into controller for etak value
		/*END ADDING REQUESTS TO AWM */


		/*EVOLUZIONE DEL SISTEMA*/
		//finche esistono delle richieste oppure work geneartor thread e' attivo (ovvero devono arrivare nuove richieste)
		while(!requests.isEmpty() || wlg.isAlive()) {
			
			/*CHECKER --> is container up? wait if not up*/
			checker(pool);
			/*END CHECKER*/
			
			
			/*START FRANCIS CONTROLLER RESPONSE : 
			 * ALLOCATE OR REMOVE (checker must be above or container could be not instantiated)*/
			if (simulation == 0) {
				int dockerInstance = frC.nextVMDelta();
				containerAllocated.add(dockerInstance);	// tengo traccia per risultati
				
				if (dockerInstance <= -1) {
					int toRemove = Math.abs(dockerInstance);
					toRemove = remove(toRemove, pool);
					}
				
				else if (dockerInstance >= 1) {
					System.out.println(debug+"AVVIO NUOVO CONTAINER");
					for (int i = 0; i < dockerInstance; i++) {
						pool.add(new DockerContainerWrapper("startContainer", id, port));	//partono server in idle
						id++;
						port++;
					}
				}
				else {
				}


			}
			/*END FRANCIS CONTROLLER RESPONSE*/
			
			
		/*CHECKER CONTAINER CPU STATUS
		 * Controllo e setto lo stato dei container per poter successivamente inviare le richieste*/
		pool = getStatus(pool);
		/*END CHECKER STATUS CONTAINER CPU*/
     
     
        /* SIMPLE DISPATCHER
         * Invio delle richieste in "requests" sui container liberi in "pool"
         * Se non sono liberi, non avvio nessuna richiesta e attendo che finisca l'esecuzione*/
		dispatcher(pool,requests, wlg,endTimeRequest,frC);
		/*END DISPATCHER*/
			
		/*SAMPLING PERIOD*/
		System.out.println(debug+"Aspettando Istante di Campionamento...");
		TimeUnit.SECONDS.sleep(sT);	
		slots++; //aggiunge uno slot completato
		/*END SAMPLING*/
		} 
		
		
		// WRITING RESULTS TO FILE 
		String FILENAME = "./";
		BufferedWriter bw = null;
		FileWriter fw = null;

		try {
			System.out.println("Inserire nome simulazione:");
			@SuppressWarnings("resource")
			Scanner sc1 = new Scanner(System.in);
			FILENAME += sc1.next();
			
			fw = new FileWriter(FILENAME);
			bw = new BufferedWriter(fw);
			bw.write(startTimeRequest.toString()+"\n");
			bw.write(endTimeRequest.toString()+"\n");
			bw.write(containerAllocated.toString()+"\n");
			bw.write(slots+"\n");
			long millis = 0;
			for(int i = 0; i < startTimeRequest.size();i++) {
				long diff = endTimeRequest.get(i).getTime() - startTimeRequest.get(i).getTime();//as given
				millis += TimeUnit.MILLISECONDS.toMillis(diff);
			}
			bw.write(wlg.notServed.toString()+"\n");
			bw.write( "Avg Time : "+ millis/startTimeRequest.size() +"ms\n");
			System.out.println("Simulation Completed");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
		}
	}
	private static void cleanSession() throws IOException, InterruptedException {
		System.out.println("ATTENTION. Do you want to reset and kill ALL CONTAINERS:");
		int rese;
		System.out.println("Insert\n0:clean all containers\n9:no clean containers");
		@SuppressWarnings("resource")
		Scanner sc2 = new Scanner(System.in);
		rese = sc2.nextInt();
		if(rese == 0) {
			Process reset = Runtime.getRuntime().exec("python "+"killContainers"+".py");
			reset.waitFor();
			System.out.println("Reset Done. Now We can start new simulation");
		}
		else if (rese == 9) {
			System.out.println("No clean containers. Now We can start new simulation");
		}
		else {
			System.out.println("You fail to press 0 or 9. Bye");
			System.exit(9);
		}		
	}
	public static int remove(int toRemove, Vector<DockerContainerWrapper> pool) throws Exception {
		
		while(toRemove!=0) {
			pool.get(0).status = 3;	//elimino il piu vecchio, Te viene diminuita, se elimino ultimo container Te rimane alta
			
			//Se non riesco a eliminare tutti quelli che devo allora : aspetto che termini esecuzione ed elimino il container forzandolo 
			while(pool.get(0).CPU > CPU_IDLE) {
				pool = getStatus(pool);
				TimeUnit.SECONDS.sleep(1);	//aspetto che finisca la sua esecuzione
			}
			Process p1 = Runtime.getRuntime().exec("docker container rm "+ pool.get(0).containerID+ " -f");	//elimino il container associato
			p1.waitFor();
			System.out.println(debug+"rimosso "+pool.get(0).containerID);
			pool.remove(0);
			toRemove--;
			}
		return toRemove;
	}
	public static void checker(Vector<DockerContainerWrapper> pool) throws InterruptedException {
		for (DockerContainerWrapper a : pool) {
			String idC = null;
			URLConnection connection = null;
			while(idC == null) {
			try {
				  connection =  new URL("http://127.0.0.1:"+a.getPort()).openConnection();	//gira in localhost
				  Scanner scanner = new Scanner(connection.getInputStream());
				  scanner.useDelimiter("\\Z");
				  idC = scanner.next();
				  scanner.close();
				  break;
				}catch ( Exception ex ) {
					System.err.println("Container is not up. Waiting 1 sec...");
					TimeUnit.SECONDS.sleep(1);	
				}
			}
			// Associo id container a porta container 
			a.containerID = idC;
			System.out.println("CHECKER: container " + a.containerID + " is UP");
		}
	}
	public static void dispatcher(Vector<DockerContainerWrapper> pool, Vector<String> requests, RandomWorkLoadGenerator wlg,Vector<Date> endTimeRequest,FrancisController frC){
		// Avvio le richieste se possibile e se ci sono
        // Posso avviare una richiesta sul server ?
		for (DockerContainerWrapper a : pool) {
			// Esiste una richiesta pendente se no skip dell'invio
			if (requests.size() != 0) {
				try {
					if(a.CPU < CPU_IDLE) {
						System.out.println("DISPATCHER: avvio richiesta su "+ a.getPort());
						requests.remove(requests.size()-1);
						wlg.setS(requests);//update size
						endTimeRequest.add(0, new Date());
						frC.setRequest(requests.size());//update francis controller
						a.status = 1;
						@SuppressWarnings("unused")
						Process q = Runtime.getRuntime().exec("python "+"client"+".py "+a.getPort());
					}
					else {
						System.out.println("DISPATCHER: Container occupato --> "+ a.getPort()+ " [NOT SENDED]");
					}
					
				}catch ( Exception ex ) {
					ex.printStackTrace();
				}	
			}
			else
				System.out.println("DISPATCHER:	Nessuna richiesta pendente");
		}
	}
	public static Vector<DockerContainerWrapper> getStatus(Vector<DockerContainerWrapper> pool) throws Exception {
		Process p1 = Runtime.getRuntime().exec("python "+"getStatus"+".py");
		String s = "";
		BufferedReader stdInput = new BufferedReader(new 
		InputStreamReader(p1.getInputStream()));
		BufferedReader stdError = new BufferedReader(new 
		InputStreamReader(p1.getErrorStream()));
		while ((s = stdInput.readLine()) != null) { 
			try {
				String nameContainer = s.substring(0, 12);
				double CPUFeature = Double.parseDouble(s.substring(40, 44));	 
				for (DockerContainerWrapper tmp : pool) {
					if (tmp.containerID.equals(nameContainer)) {
						tmp.CPU = CPUFeature;
						if (tmp.CPU < CPU_IDLE) {
								tmp.status = 0;
						}
					}
				}	
			} 
			catch (Exception e){}
		}
		while ((s = stdError.readLine()) != null) 
			System.out.println("ERROR CHECKER STATUS : " + s);	
		return pool;

	}


	/*DA QUA IN GIU, NON HO MODIFICATO NULLA: NON GUARDARE*/
		
	private static void inputParameters() {
		
		int minVM = ServiceBroker.getMinVM();
		while( minVM < 1 ) {
			System.out.print(debug + "\tInserisci il numero minimo di VMs dello Stack: ");
			try {
				minVM = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		};
		System.out.println(debug + "\tminVM = " + minVM);
		testParam.setMinVM(minVM);		
	
		int maxVM = ServiceBroker.getMaxVM();
		while( maxVM < minVM ) {
			System.out.print(debug + "\tInserisci il numero massimo di VMs dello Stack: ");
			try {
				maxVM = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		};
		System.out.println(debug + "\tmaxVM = " + maxVM);
		testParam.setMaxVM(maxVM);
		
		try {
			String whichController = ServiceBroker.getIndexControllerToUse();
			testParam.setWhichController(Integer.parseInt(whichController));
			System.out.println(debug + "\tController = " + testParam.getPrintableController());
			
			int samplingPeriodInMinutes = ServiceBroker.getSamplingPeriodInMinutes();
			System.out.println(debug + "\tsamplingPeriodInMinutes = " + samplingPeriodInMinutes);
			testParam.setSamplingPeriod(samplingPeriodInMinutes);
			
			Map<String, HashMap<String, String>> controllers = ServiceBroker.getControllers();
			
			switch(whichController){
			case "0": 
				testParam.setDelta(Integer.parseInt(controllers.get(whichController).get("delta")));
				System.out.println(debug + "\tDelta = " + testParam.getDelta());
				qos.setSetPoint(Double.parseDouble(controllers.get(whichController).get("setPoint")));
				System.out.println(debug + "\tSetPoint = " + qos.getSetPoint());
				break;
			case "3": 
				testParam.setAlpha(Double.parseDouble(controllers.get(whichController).get("alpha")));
				System.out.println(debug + "\tAlpha = " + testParam.getAlpha());
				testParam.setBeta(Double.parseDouble(controllers.get(whichController).get("beta")));
				System.out.println(debug + "\tBeta = " + testParam.getBeta());
				testParam.setGamma(Double.parseDouble(controllers.get(whichController).get("gamma")));
				System.out.println(debug + "\tGamma = " + testParam.getGamma());
				testParam.setDeltaR(Double.parseDouble(controllers.get(whichController).get("delta")));
				System.out.println(debug + "\tDelta = " + testParam.getDeltaR());
				testParam.setM(Double.parseDouble(controllers.get(whichController).get("M")));
				System.out.println(debug + "\tM = " + testParam.getM());
				testParam.setTe(Double.parseDouble(controllers.get(whichController).get("Te")));
				System.out.println(debug + "\tTe = " + testParam.getTe());
				break;
			case "4":
				testParam.setOpenstackMetric(controllers.get(whichController).get("openstackMetric"));
				System.out.println(debug + "\tOpenstackMetric = " + testParam.getOpenstackMetric());
				testParam.setScaleUpThreshold(Double.parseDouble(controllers.get(whichController).get("scaleUpThresholdInPerc")));
				System.out.println(debug + "\tScaleUpThreshold = " + testParam.getScaleUpThreshold());
				testParam.setScaleDownThreshold(Double.parseDouble(controllers.get(whichController).get("scaleDownThresholdInPerc")));
				System.out.println(debug + "\tScaleDownThreshold = " + testParam.getScaleDownThreshold());
				break;
			case "5":
				testParam.setOpenstackMetric(controllers.get(whichController).get("openstackMetric"));
				System.out.println(debug + "\tOpenstackMetric = " + testParam.getOpenstackMetric());
				testParam.setScaleUpThreshold(Double.parseDouble(controllers.get(whichController).get("scaleUpThresholdInPerc")));
				System.out.println(debug + "\tScaleUpThreshold = " + testParam.getScaleUpThreshold());
				testParam.setScaleDownThreshold(Double.parseDouble(controllers.get(whichController).get("scaleDownThresholdInPerc")));
				System.out.println(debug + "\tScaleDownThreshold = " + testParam.getScaleDownThreshold());
				testParam.setScaleUpPreThreshold(Double.parseDouble(controllers.get(whichController).get("scaleUpPreThresholdInPerc")));
				System.out.println(debug + "\tScaleUpPreThreshold = " + testParam.getScaleUpPreThreshold());
				testParam.setScaleDownPreThreshold(Double.parseDouble(controllers.get(whichController).get("scaleDownPreThresholdInPerc")));
				System.out.println(debug + "\tScaleDownPreThreshold = " + testParam.getScaleDownPreThreshold());
				testParam.setIncrementPerc(Double.parseDouble(controllers.get(whichController).get("incrementPerc")));
				System.out.println(debug + "\tIncrementPerc = " + testParam.getIncrementPerc());
				testParam.setDecrementPerc(Double.parseDouble(controllers.get(whichController).get("decrementPerc")));
				System.out.println(debug + "\tDecrementPerc = " + testParam.getDecrementPerc());
				testParam.setDurationPeriodInIntervals(
						Integer.parseInt(controllers.get(whichController).get("durationPeriodInIntervals")));
				System.out.println(debug + "\tDurationPeriodInIntervals = " + testParam.getDurationPeriodInIntervals());
				break;
			case "6":
				testParam.setOpenstackMetric(controllers.get(whichController).get("openstackMetric"));
				System.out.println(debug + "\tOpenstackMetric = " + testParam.getOpenstackMetric());
				testParam.setScaleUpThreshold_1(Double.parseDouble(controllers.get(whichController).get("scaleUpThreshold_1")));
				System.out.println(debug + "\tScaleUpThreshold_1 = " + testParam.getScaleUpThreshold_1());
				testParam.setScaleUpThreshold_2(Double.parseDouble(controllers.get(whichController).get("scaleUpThreshold_2")));
				System.out.println(debug + "\tScaleUpThreshold_2 = " + testParam.getScaleUpThreshold_2());
				testParam.setScaleUpThreshold_3(Double.parseDouble(controllers.get(whichController).get("scaleUpThreshold_3")));
				System.out.println(debug + "\tScaleUpThreshold_3 = " + testParam.getScaleUpThreshold_3());
				testParam.setScaleDownThreshold_1(Double.parseDouble(controllers.get(whichController).get("scaleDownThreshold_1")));
				System.out.println(debug + "\tScaleDownThreshold_1 = " + testParam.getScaleDownThreshold_1());
				testParam.setScaleDownThreshold_2(Double.parseDouble(controllers.get(whichController).get("scaleDownThreshold_2")));
				System.out.println(debug + "\tScaleDownThreshold_2 = " + testParam.getScaleDownThreshold_2());
				testParam.setScaleDownThreshold_3(Double.parseDouble(controllers.get(whichController).get("scaleDownThreshold_3")));
				System.out.println(debug + "\tScaleDownThreshold_3 = " + testParam.getScaleDownThreshold_3());
				break;
			case "7":
				testParam.setAlphaMPC(Double.parseDouble(controllers.get(whichController).get("alpha")));
				System.out.println(debug + "\tAlpha = " + testParam.getAlphaMPC());
				testParam.setBetaMPC(Double.parseDouble(controllers.get(whichController).get("beta")));
				System.out.println(debug + "\tBeta = " + testParam.getBetaMPC());
				testParam.setGammaMPC(Double.parseDouble(controllers.get(whichController).get("gamma")));
				System.out.println(debug + "\tGamma = " + testParam.getGammaMPC());
				testParam.setDeltaMPC(Double.parseDouble(controllers.get(whichController).get("delta")));
				System.out.println(debug + "\tDelta = " + testParam.getDeltaMPC());
				testParam.setMMPC(Double.parseDouble(controllers.get(whichController).get("M")));
				System.out.println(debug + "\tM = " + testParam.getMMPC());
				testParam.setTeMPC(Double.parseDouble(controllers.get(whichController).get("Te")));
				System.out.println(debug + "\tTe = " + testParam.getTeMPC());
				testParam.setFutureFiniteHorizon(Integer.parseInt(controllers.get(whichController).get("finitehorizon")));
				System.out.println(debug + "\tfinite horizon steps = " + testParam.getFutureFiniteHorizon());
				break;
			default:
				System.out.println(debug + "Nessun riferimento a controllori esistenti...");
				setWhichController();
			}
		} catch (ParseException | IOException e) {
			e.printStackTrace();
			System.out.println();
			System.out.println(debug + "Inserimento da tastiera...");
			
			setWhichController();
		}

		testParam.setHowManySimulation(ServiceBroker.getHowManySimulations());
		System.out.println(debug + "\thowManySimulation = " + testParam.getHowManySimulation());

		if(testParam.getHowManySimulation() > 0){
			
			try {
				String simulation = ServiceBroker.getSimulation();
				
				testParam.setSimulation(simulation);
				
			} catch (ParseException | IOException e) {
				e.printStackTrace();
				setWhichSimulation();
			}
		}
		/******/
	}

	public static void setWhichController(){
		int whichController = 0;
		boolean rightValue = false;
		do {
			System.out.println(debug + "\tTipo di controllore?? ");
			System.out.println(debug + "\t Integral              ====> 0");
			System.out.println(debug + "\t Proportional-Integral ====> 1");
			System.out.println(debug + "\t Riccati               ====> 2");
			System.out.println(debug + "\t Francis               ====> 3");
			System.out.println(debug + "\t Threshold             ====> 4");
			System.out.println(debug + "\t QuadThreshold             ====> 5");
			System.out.print(debug + "\tInserisci la tua scelta: ");
			try {
				whichController = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
			if(whichController == 0 || whichController == 1 || whichController == 2
					|| whichController == 3 || whichController == 4) rightValue = true;
		} while( rightValue == false );
		System.out.println(debug + "\twhichController = " + whichController);
		testParam.setWhichController(whichController);
		
		commonControllerParameters();
		
		switch(whichController){
		case 0: integralControllerParameters(); break;
		case 3: break;
		case 4: thresholdControllerParameters(); break;
		case 5: quadThresholdControllerParameters(); break;
		}
	}
	
	public static void commonControllerParameters(){
		
		int samplingPeriodInMinutes = 5;
		do {
			System.out.print(debug + "\tInserisci il tempo di campionamento del controllore in minuti: ");
			try {
				samplingPeriodInMinutes = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( samplingPeriodInMinutes < 1);
		System.out.println(debug + "\tsamplingPeriodInMinutes = " + samplingPeriodInMinutes);
		testParam.setSamplingPeriod(samplingPeriodInMinutes);
	}
	
	public static void integralControllerParameters(){
		
		int delta = 4;
		do {
			System.out.print(debug + "\tInserisci il valore del parametro DELTA dell'AdaptiveLoop: ");
			try {
				delta = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( delta < 1);
		System.out.println(debug + "\tdelta = " + delta);
		testParam.setDelta(delta);
		
		double setPoint = 0.6;
		do {
			System.out.print(debug + "\tInserisci il valore del SetPoint per l'AdaptiveLoop: ");
			try {
				setPoint = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( setPoint < 0);
		System.out.println(debug + "\tsetPoint = " + setPoint);
		qos.setSetPoint(setPoint);
	}
	
	public static void thresholdControllerParameters(){
		
		String openstackMetric = "cpu_util";
		System.out.print(debug + "\tInserisci la metrica di OpenStack da misurare (es. cpu_util): ");
		try {
			openstackMetric = myInput.readLine();
		} catch (IOException e) { e.printStackTrace(); }
		System.out.println(debug + "\topenstackMetric = " + openstackMetric);
		testParam.setOpenstackMetric(openstackMetric);
		
		double scaleUpThreshold = 0.6;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia per lo scaleUp: ");
			try {
				scaleUpThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleUpThreshold < 0);
		System.out.println(debug + "\tscaleUpThreshold = " + scaleUpThreshold);
		testParam.setScaleUpThreshold(scaleUpThreshold);

		double scaleDownThreshold = 0.6;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia per lo scaleUp: ");
			try {
				scaleDownThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleDownThreshold < 0);
		System.out.println(debug + "\tscaleDownThreshold = " + scaleDownThreshold);
		testParam.setScaleDownThreshold(scaleDownThreshold);

	}
	
	public static void quadThresholdControllerParameters(){
		
		String openstackMetric = "cpu_util";
		System.out.print(debug + "\tInserisci la metrica di OpenStack da misurare (es. cpu_util): ");
		try {
			openstackMetric = myInput.readLine();
		} catch (IOException e) { e.printStackTrace(); }
		System.out.println(debug + "\topenstackMetric = " + openstackMetric);
		testParam.setOpenstackMetric(openstackMetric);
		
		double scaleUpThreshold = 0.7;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia per lo scaleUp: ");
			try {
				scaleUpThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleUpThreshold < 0);
		System.out.println(debug + "\tscaleUpThreshold = " + scaleUpThreshold);
		testParam.setScaleUpThreshold(scaleUpThreshold);
		
		double scaleUpPreThreshold = 0.6;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia bassa per lo scaleUp: ");
			try {
				scaleUpPreThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleUpPreThreshold < 0);
		System.out.println(debug + "\tscaleUpPreThreshold = " + scaleUpPreThreshold);
		testParam.setScaleUpPreThreshold(scaleUpPreThreshold);

		double scaleDownPreThreshold = 0.4;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia alta per lo scaleDown: ");
			try {
				scaleDownPreThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleDownPreThreshold < 0 || scaleDownPreThreshold >= scaleUpPreThreshold);
		System.out.println(debug + "\tscaleDownPreThreshold = " + scaleDownPreThreshold);
		testParam.setScaleDownPreThreshold(scaleDownPreThreshold);

		double scaleDownThreshold = 0.3;
		do {
			System.out.print(debug + "\tInserisci il valore della soglia per lo scaleDown: ");
			try {
				scaleDownThreshold = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( scaleDownThreshold < 0 || scaleDownThreshold >= scaleUpThreshold);
		System.out.println(debug + "\tscaleDownPreThreshold = " + scaleDownThreshold);
		testParam.setScaleDownThreshold(scaleDownThreshold);

		double incrementPerc = 0.5;
		do {
			System.out.print(debug + "\tInserisci la percentuale di incremento: ");
			try {
				incrementPerc = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( incrementPerc < 0 || incrementPerc > 1);
		System.out.println(debug + "\tincrementPerc = " + incrementPerc);
		testParam.setIncrementPerc(incrementPerc);
	
		double decrementPerc = 0.3;
		do {
			System.out.print(debug + "\tInserisci la percentuale di decremento: ");
			try {
				decrementPerc = Double.parseDouble( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( decrementPerc < 0 || decrementPerc > 1);
		System.out.println(debug + "\tdecrementPerc = " + decrementPerc);
		testParam.setDecrementPerc(decrementPerc);
		
		int durationPeriodInIntervals = 3;
		do {
			System.out.print(debug + "\tInserisci la durata del periodo in intervalli: ");
			try {
				durationPeriodInIntervals = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
		} while( durationPeriodInIntervals < 0 );
		System.out.println(debug + "\tdurationPeriodInIntervals = " + durationPeriodInIntervals);
		testParam.setDurationPeriodInIntervals(durationPeriodInIntervals);
	}
	
	public static void setWhichSimulation(){
		int whichSimulation = 0;
		boolean rightValue = false;
		do {
			System.out.println(debug + "\tTipo di simulazione?? ");
			System.out.println(debug + "\t Mobile Device Simulation    ====> 0");
			System.out.println(debug + "\t Http Client Simulation      ====> 1");
			System.out.print(debug + "\tInserisci la tua scelta: ");
			try {
				whichSimulation = Integer.parseInt( myInput.readLine() );
			} catch (NumberFormatException | IOException e) { e.printStackTrace(); }
			if(whichSimulation == 0 || whichSimulation == 1) rightValue = true;
		} while( rightValue == false );
		System.out.println(debug + "\twhichSimulation = " + whichSimulation);
		
		switch(whichSimulation){
		case 0: testParam.setSimulation(SimulationType.MobDev); break;
		case 1: testParam.setSimulation(SimulationType.HttpClient); break;
		}
	}

		
} // public class Dispatcher {..}
