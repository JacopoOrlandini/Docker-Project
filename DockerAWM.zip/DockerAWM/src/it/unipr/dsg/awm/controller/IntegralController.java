package it.unipr.dsg.awm.controller;

import it.unipr.dsg.awm.AssignedRequest;
import it.unipr.dsg.awm.QueuedRequest;
import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;

/**
 * This class implements a standard integral controller. <br>
 * <br>
 * k(t+1) = k(t) + L*(phi - s)
 * <br>
 * <br>
 * dove L � il guadagno del controllore, phi � la risorsa misurata e s � il set point desiderato
 * per tale risorsa.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class IntegralController extends Controller {

	private static String debug = "INTEGRAL CONTROLLER - ";

	private double setPoint;
	private int delta = 4;
	
	private AssignedRequest assignedRequest = AssignedRequest.getInstance();
	private QueuedRequest queuedRequest = QueuedRequest.getInstance();
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	/**
	 * Initializes the set point taking its value from the {@link QoSModeler} class.
	 */
	public IntegralController(){
		this.setPoint = qos.getSetPoint();
	}
	/**
	 * Initializes the set point with the value passed.
	 * @param setPoint
	 */
	public IntegralController(double setPoint) {
		this.setPoint = setPoint;
	}

	/**
	 * Calculates the number of virtual machines to allocate or deallocate according to the formula of the integral
	 * controller.
	 */
	@Override
	public int nextVMDelta() {
		
		double fraction_ct = (double) assignedRequest.getCompletedTasks() / (double) queuedRequest.getArrivedTasks();
		double controllerGain = (double) this.delta / fraction_ct; 
		int currentVMs = vmStack.getSize();
				
		double setPointMeasurement = qos.getQoSCurrentMeasurement();

		dataColl.addSetPointValue(setPointMeasurement);
		dataColl.addControllerGainValue(controllerGain);
		dataColl.addControllerGainNumValue(this.delta);
		dataColl.addControllerGainDenValue(fraction_ct);
		
		int controllerResult = (int) Math.ceil(integralController(controllerGain, setPointMeasurement, currentVMs));
		
		return (controllerResult - currentVMs);
	}

	
	private int integralController(double L, double ratio_tc, int kPrevious) {
		int kCurrent = (int) Math.ceil(kPrevious + L * (ratio_tc - this.setPoint));
		printDebug(debug + "kPrevious + L * (ratio_tc - s) = " + 
									kPrevious + " + " + L + " * " + "(" + ratio_tc + " - " + this.setPoint + ") " +
									"= " + kCurrent);
    	
    	kCurrent = super.checkVMLimits(kCurrent);
    	
    	printDebug(debug + "integralController() =====> kCurrent = " + kCurrent);
    	
    	return kCurrent;
	}
	
	/**
	 * Does nothing..
	 */
	@Override
	public void resetVariables() {}
	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}

}
