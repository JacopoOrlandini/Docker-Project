package it.unipr.dsg.awm.controller;

import java.util.Vector;

import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.openstack.OSFactory;

import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

public class MoreThresholdController extends Controller {

	private static String debug = "MORE THRESHOLD CONTROLLER - ";
	
	private OSClientV3 demoUser;
	private int samplingPeriodInSeconds = 5 * 60;
	
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	private String OpenStackMetric;
	private double scaleUpThreshold_1;
	private double scaleDownThreshold_1;
	private double scaleUpThreshold_2;
	private double scaleDownThreshold_2;
	private double scaleUpThreshold_3;
	private double scaleDownThreshold_3;
	
	/**
	 * The constructor establish the connection with OpenStack and set the resource to measure and the two
	 * thresholds.
	 */
	public MoreThresholdController() {
		
		Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");
		this.demoUser = OSFactory.builderV3()
				 .endpoint("http://160.78.27.68:5000/v3")
				 .credentials("demo","demo-pass" , domainIdentifier)
				 .scopeToProject(Identifier.byName("demo") , Identifier.byName("default"))
				 .authenticate();
		
		this.OpenStackMetric = testParam.getOpenstackMetric();
		this.scaleUpThreshold_1 = testParam.getScaleUpThreshold_1();
		this.scaleUpThreshold_2 = testParam.getScaleUpThreshold_2();
		this.scaleUpThreshold_3 = testParam.getScaleUpThreshold_3();
		this.scaleDownThreshold_1 = testParam.getScaleDownThreshold_1();
		this.scaleDownThreshold_2 = testParam.getScaleDownThreshold_2();
		this.scaleDownThreshold_3 = testParam.getScaleDownThreshold_3();
		this.samplingPeriodInSeconds = testParam.getSamplingPeriod() * 60;
	}

	@Override
	public int nextVMDelta() {

		Vector<Double> utils = super.getOpenStackPMT(this.demoUser, this.OpenStackMetric, this.samplingPeriodInSeconds);
				
		double mean_utils = computeAvgOfVector(utils);
		mean_utils = mean_utils / 100.0;
		dataColl.addOpenStackMetricMeasurementValue(mean_utils);
		
		printDebug(debug + "Num of avgs: " + utils.size() + " Avg: " + mean_utils);
		
		int nextVMDelta = 0;
		int currentVMs = vmStack.getSize();
		if(mean_utils > this.scaleUpThreshold_1) nextVMDelta = 1;
		if(mean_utils > this.scaleUpThreshold_2) nextVMDelta = 2;
		if(mean_utils > this.scaleUpThreshold_3) nextVMDelta = 3;
		if(mean_utils < this.scaleDownThreshold_1) nextVMDelta = -1;
		if(mean_utils < this.scaleDownThreshold_2) nextVMDelta = -2;
		if(mean_utils < this.scaleDownThreshold_3) nextVMDelta = -3;
		
		int futureVMs = nextVMDelta + currentVMs;
		futureVMs = super.checkVMLimits(futureVMs);
		
    	printDebug(debug + "Controller Result is: " + futureVMs);
    	printDebug(debug + "Next VM Delta is: " + (futureVMs - currentVMs));
		
		return (futureVMs - currentVMs);
	
	}

	/**
	 * Does nothing...
	 */
	@Override
	public void resetVariables() {}
	
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = 0;
			if(vector.size() > 0) mean = sum / (double) vector.size();
			return mean;
		}
	}
	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}	
	
}
