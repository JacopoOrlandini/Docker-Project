package it.unipr.dsg.awm.controller;

import java.util.Vector;

import org.openstack4j.api.OSClient.OSClientV3;
import org.openstack4j.model.common.Identifier;
import org.openstack4j.openstack.OSFactory;

import it.unipr.dsg.awm.virtualmachine.VirtualMachineStack;
import it.unipr.dsg.log.DataCollector;
import it.unipr.dsg.log.TestParameters;

/**
 * This class implements a simple Controller with threshold.
 * When the utilization of a resource exceed an upper threshold scale up of 1 VM.
 * When the utilization of a resource goes below a lower threshold scale down of 1 VM.
 * For measuring the resource the API of Ceilometer are used. In this manner we can measure 
 * some basic physical resources of the VMs.
 * The resource to measure and the two thresholds can be set by configuration file in JSON format.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class ThresholdController extends Controller {

	private static String debug = "THRESHOLD CONTROLLER - ";
	
	private OSClientV3 demoUser;
	private int samplingPeriodInSeconds = 5 * 60;
	
	private VirtualMachineStack vmStack = VirtualMachineStack.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	private DataCollector dataColl = DataCollector.getInstance();
	
	private String OpenStackMetric;
	private double scaleUpThreshold;
	private double scaleDownThreshold;
	
	/**
	 * The constructor establish the connection with OpenStack and set the resource to measure and the two
	 * thresholds.
	 */
	public ThresholdController() {
		
		Identifier domainIdentifier = Identifier.byId("625adf1cb91649b8acdd0a76e246feda");
		this.demoUser = OSFactory.builderV3()
				 .endpoint("http://160.78.27.68:5000/v3")
				 .credentials("demo","demo-pass", domainIdentifier)
				 .scopeToProject(Identifier.byName("demo") , Identifier.byName("default"))
				 .authenticate();
		
		this.OpenStackMetric = testParam.getOpenstackMetric();
		this.scaleUpThreshold = testParam.getScaleUpThreshold();
		this.scaleDownThreshold = testParam.getScaleDownThreshold();
		this.samplingPeriodInSeconds = testParam.getSamplingPeriod() * 60;
	}

	/**
	 * This method returns the number of Virtual Machine to allocate or deallocate.
	 * It retrieves the measurements and calculate the average of all of them which
	 * has been saved not too far in time. 
	 * In particular only the measurements executed during the last sampling period are considered.
	 */
	@Override
	public int nextVMDelta() {
		
		Vector<Double> utils = super.getOpenStackPMT(this.demoUser, this.OpenStackMetric, this.samplingPeriodInSeconds);
				
		double mean_utils = computeAvgOfVector(utils);
		mean_utils = mean_utils / 100.0;
		dataColl.addOpenStackMetricMeasurementValue(mean_utils);
		
		printDebug(debug + "Num of avgs: " + utils.size() + " Avg: " + mean_utils);
		
		int nextVMDelta = 0;
		int currentVMs = vmStack.getSize();
		if(mean_utils > this.scaleUpThreshold) nextVMDelta = 1;
		if(mean_utils < this.scaleDownThreshold) nextVMDelta = -1;
		
		int futureVMs = nextVMDelta + currentVMs;
		futureVMs = super.checkVMLimits(futureVMs);
		
    	printDebug(debug + "Controller Result is: " + futureVMs);
    	printDebug(debug + "Next VM Delta is: " + (futureVMs - currentVMs));
		
		return (futureVMs - currentVMs);
	}
	
//	private void printStatistics(List<? extends Statistics> stats_temp, VirtualMachine vm){
//		
//		printDebug("Statitics for " + vm.getMyIP() + "cpu_util:");
//		printDebug("\tSize: " + stats_temp.size());
//		
//		for(Statistics s : stats_temp){
//			printDebug("\tAvg: " + s.getAvg());
//			printDebug("\tCount: " + s.getCount());
//			printDebug("\tDuration: " + s.getDuration());
//			printDebug("\tPeriod: " + s.getPeriod());
//			printDebug("\tSum: " + s.getSum());
//			printDebug("\tDurationStart: " + s.getDurationStart());
//			printDebug("\tDurationEnd: " + s.getDurationEnd());
//			printDebug("\tPeriodStart: " + s.getPeriodStart());
//			printDebug("\tPeriodEnd: " + s.getPeriodEnd());				
//		}		
//	}
	
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = 0;
			if(vector.size() > 0) mean = sum / (double) vector.size();
			return mean;
		}
	}

	@Override
	public void resetVariables() {}
	
	private void printDebug(String s){
		System.out.println(s);
		dataColl.addControllerString(s);
	}

}
