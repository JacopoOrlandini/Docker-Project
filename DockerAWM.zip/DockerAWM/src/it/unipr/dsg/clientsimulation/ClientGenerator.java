package it.unipr.dsg.clientsimulation;

/**
 * Interface for a generic workload generator
 * 
 * @author Valter Venusti - December 2015
 *
 */
public interface ClientGenerator {

	public void startSimulation();
}
