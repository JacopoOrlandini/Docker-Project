package it.unipr.dsg.clientsimulation;

/**
 * Interface for a generic Client Data Collector.
 * 
 * @author Valter Venusti - December 2015
 */
public interface IDataCollector {

	/**
	 * This methods will be collected every sampling time and is responsible
	 * of saving the statistics for sample period just elapsed.
	 */
	public void collectNewData();
	
	/**
	 * Resets all the statistics of the simulation.
	 */
	public void resetAllVariables();
}
