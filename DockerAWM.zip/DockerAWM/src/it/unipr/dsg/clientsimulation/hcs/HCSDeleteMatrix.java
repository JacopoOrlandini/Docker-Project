package it.unipr.dsg.clientsimulation.hcs;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.impl.client.HttpClients;

/**
 * This class sends a DELETE requests to the Cloud in order to delete a specific matrix.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class HCSDeleteMatrix extends Thread {

	private HttpClient httpclient = HttpClients.createDefault();
	private String matrixName = "";
	
	/**
	 * @param name - The name with which the Cloud knows the matrix
	 */
	public HCSDeleteMatrix (String name) {
		this.matrixName = name;
	}
	
	/**
	 * Makes an Http DELETE request
	 */
	public void run() {
		HttpDelete httpDelete = new HttpDelete("http://160.78.27.66:5678/matrixes/" + this.matrixName);
		httpDelete.addHeader("connection", "keep-alive");
			
		try {
			HttpResponse response = httpclient.execute(httpDelete);
			StatusLine status = response.getStatusLine();
			int statusCode = status.getStatusCode();
			
			if(statusCode == 204) {
				System.out.println("\t\tDELETE MATRIXES - Yeah!! Matrix " + this.matrixName + " is deleted!!");
			} else {
				System.out.println("\t\tDELETE MATRIXES - Error!! " + status.toString());
			}
				
		} catch (IOException e) { e.printStackTrace(); }
	} // public void run() {..}

}
