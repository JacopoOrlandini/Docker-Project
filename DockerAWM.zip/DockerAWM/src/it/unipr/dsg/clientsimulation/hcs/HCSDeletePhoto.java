package it.unipr.dsg.clientsimulation.hcs;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.impl.client.HttpClients;

/**
 * This class sends a DELETE requests to the Cloud in order to delete a specific matrix.
 * 
 * @author Valter Venusti - December 2015
 *
 */
public class HCSDeletePhoto extends Thread {

	private HttpClient httpclient = HttpClients.createDefault();
	private String photoName = "";
	
	/**
	 * @param name - The name with which the Cloud knows the matrix
	 */
	public HCSDeletePhoto (String name) {
		this.photoName = name;
	}
	
	/**
	 * Makes an Http DELETE request
	 */
	public void run() {
		HttpDelete httpDelete = new HttpDelete("http://160.78.27.66:5678/images/" + this.photoName);
		httpDelete.addHeader("connection", "keep-alive");
			
		try {
			HttpResponse response = httpclient.execute(httpDelete);
			StatusLine status = response.getStatusLine();
			int statusCode = status.getStatusCode();
			
			if(statusCode == 204) {
				System.out.println("\t\tDELETE PHOTOS - Yeah!! Photo " + this.photoName + " is deleted!!");
			} else {
				System.out.println("\t\tDELETE PHOTOS - Error!! " + status.toString());
			}
				
		} catch (IOException e) { e.printStackTrace(); }
	} // public void run() {..}

//	public static void main(String[] args){
//		
//		new HCSDeletePhoto("facce-simili-9_2016-01-23_10.54.22.833").start();
//	}
}
