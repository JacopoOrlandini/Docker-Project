package it.unipr.dsg.clientsimulation.mds;

import java.util.Vector;

import it.unipr.dsg.clientsimulation.IDataCollector;
import it.unipr.dsg.clientsimulation.SimulationInfo;

/**
 * 
 * @author Marco Magnani - March 2015
 *
 */
public class MobileDataCollector implements IDataCollector {

	
	/** SINGLETON STUFF **/
	private static MobileDataCollector instance = null;

	private MobileDataCollector() {}
	
	public static synchronized MobileDataCollector getInstance() {
		if(instance == null)
			instance = new MobileDataCollector();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/

	private Vector<Double> execTimeGlobal = new Vector<Double>();
	private Vector<Double> execTimeCloud = new Vector<Double>();
	private Vector<Double> slowdown = new Vector<Double>();
	private Vector<Double> mobDevLifeTime = new Vector<Double>();
	
	private SimulationInfo simInfo = SimulationInfo.getInstance();
	
	@Override
	public void collectNewData(){}
	
	@Override
	public void resetAllVariables(){
		this.execTimeCloud.clear();
		this.execTimeGlobal.clear();
		this.slowdown.clear();
		this.mobDevLifeTime.clear();
	}
	
	/** ADD FUNCTIONS **/
	public void addExecTimeGlobal(double value) {
		synchronized(this.execTimeGlobal) {
			this.execTimeGlobal.add(value);
		}
	}

	public void addExecTimeCloud(double value) {
		synchronized(this.execTimeCloud) {
			this.execTimeCloud.add(value);
		}
	}
	
	public void addSlowdown(double waitingTime, double elabTime) {
		synchronized(this.slowdown) {
			double slowdownValue = (waitingTime + elabTime) / elabTime;
			this.slowdown.add(slowdownValue);
		}
	}
	
	public void addTerminatedMobDevLifeTime(double lifeTime) {
		synchronized(this.mobDevLifeTime) {
			this.mobDevLifeTime.add(lifeTime);
			System.out.println("\t\t" + "DATA_COLLECTOR - New Terminated Device, remaining " + 
										(MobileDeviceGenerator.getInstance().numberOfMobDev - this.mobDevLifeTime.size()) );
			if( this.mobDevLifeTime.size() == MobileDeviceGenerator.getInstance().numberOfMobDev ) {
				simInfo.setSimulationStatus(SimulationInfo.SimStatus.ENDED);
				
			}
		}
	}
	/** ADD FUNCTIONS **/
	
	/** GET PRINTABLE DATA **/
	public String getOtherInfoPrintableData() {
		String result = "";
		result += "#INFO\tMEAN\tSTD_DEV\n";
		synchronized(this.execTimeGlobal) {
			double mean = computeAvgOfVector(this.execTimeGlobal);
			result += "GLOBAL\t" + mean  + "\t" + computeStdDevOfVector(this.execTimeGlobal, mean) + "\n";
		}
		synchronized(this.execTimeCloud) {
			double mean = computeAvgOfVector(this.execTimeCloud);
			result += "CLOUD\t" + mean  + "\t" + computeStdDevOfVector(this.execTimeCloud, mean) + "\n";
		}
		synchronized(this.slowdown) {
			double mean = computeAvgOfVector(this.slowdown);
			result += "SLOWDOWN\t" + mean  + "\t" + computeStdDevOfVector(this.slowdown, mean) + "\n";
		}
		synchronized(this.mobDevLifeTime) {
			double mean = computeAvgOfVector(this.mobDevLifeTime);
			result += "MOB-DEV_LIFETIME\t" + mean  + "\t" + computeStdDevOfVector(this.mobDevLifeTime, mean) + "\n";
		}
		return result;
	}
	/** GET PRINTABLE DATA **/

	/** PRIVATE FUNCTIONS **/
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized(vector) {
			double sum = 0;
			for(Double d : vector) sum += d;
			double mean = sum / (double) vector.size();
			return mean;
		}
	}
	
	private double computeStdDevOfVector(Vector<Double> vector, double mean) {
		synchronized(vector) {
			double sum = 0;
			for(Double value : vector)  sum += Math.pow( (value - mean), 2);
			double stdDev = Math.sqrt( sum / (double) vector.size() );
			return stdDev;
		}
	}
	/** PRIVATE FUNCTIONS **/

}
