package it.unipr.dsg.clientsimulation.mds;

import java.io.IOException;
import java.util.Vector;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import it.unipr.dsg.awm.util.AWMJSONParser;
import it.unipr.dsg.clientsimulation.ClientGenerator;
import it.unipr.dsg.clientsimulation.SimulationInfo;

/**
 * 
 * @author Marco Magnani - March 2015
 *
 */
public class MobileDeviceGenerator implements ClientGenerator {
	
	/** SINGLETON STUFF **/
	private static MobileDeviceGenerator instance = null;

	public MobileDeviceGenerator() {
		System.out.println(debug + "Started!!");
		for(int i=0; i<howManyImages; i++) {
			String tmpPath = baseImagePath + "p" + i + ".jpg";
			imagesPath.add(tmpPath);
		}
	}
	
	public static synchronized MobileDeviceGenerator getInstance() {
		if(instance == null)
			instance = new MobileDeviceGenerator();
		return instance;
	} // getInstance() {..}
	/** SINGLETON STUFF **/
	
	/** GLOBAL VARIABLES **/
	private static String debug = "MOBILE_DEVICE_GENERATOR - ";
	
	private String baseImagePath = "/home/SdE/MobileDeviceSimulationPhotos/";
	private int howManyImages = 14;
	private Vector<String> imagesPath = new Vector<String>();

	//private static int[] cpuCores = {1, 2, 4, 8};
	
	private SimulationInfo simInfo = SimulationInfo.getInstance();
	
	public int numberOfMobDev = 1;
	/** GLOBAL VARIABLES **/
	
	/** PUBLIC FUNCTIONS **/
	@Override
	public void startSimulation() {
		
		//Retrieving the number of mobile devices and the frequency lambda of the devices
		JSONObject mobDev;
		int devicesNumber = 0;
		double lambdaDevices = 0.00625;
		try {
			mobDev = new AWMJSONParser().getFromVoice("MobDevSimulation");
			devicesNumber = Integer.parseInt(mobDev.get("NumOfMobDev").toString());
			lambdaDevices = Double.parseDouble(mobDev.get("Lambda").toString());
		} catch (ParseException | IOException e) {
			e.printStackTrace();
		}
		
		if( devicesNumber < 1 ) numberOfMobDev = 1;
		else numberOfMobDev = devicesNumber;
		
		int mobDevID = 1;
		while( numberOfMobDev > 0 ) {
	        // Genero un numero casuale tra 0 e 3, per selezionare il numero di Cores che avrà il nuovo MobileDevice
	        //int min = 0, max = 3;
	        //Random rand = new Random();
	        //int randNum = rand.nextInt((max - min) + 1) + min;
	        
	        MobileDevice mobileDev = new MobileDevice(mobDevID, imagesPath, lambdaDevices);
	        mobileDev.start();
	        
	        mobDevID++;
	        numberOfMobDev--;
        } // while(numberOfMobDev > 0) {..}
		
		simInfo.setSimulationStatus(SimulationInfo.SimStatus.RUNNING);
	}
	/** PUBLIC FUNCTIONS **/
}
