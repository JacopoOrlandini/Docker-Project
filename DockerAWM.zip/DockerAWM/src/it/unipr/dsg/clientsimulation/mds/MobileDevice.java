package it.unipr.dsg.clientsimulation.mds;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import javax.imageio.ImageIO;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * 
 * @author Marco Magnani - March 2015
 *
 */
public class MobileDevice extends Thread {
	private String debug = null;
	
	/** KUMAR VARIABLES **/
	private double batteryCapacity = 4500; // mWh
	private double WmFixed = 0.5;	// Power consumed by the OS and the processes executed in background
	private double Wi= 0.25;	// Average power consumed by the mobile device when idle
	private double Woff = 0.7;	// Average power consumed by the Job transfer
	//private int M = 1000;	// MHz
	double transmissionRate = (10 * 1000 * 1000); 	// [MBytes/Sec]
	private double Eon = 0;		// Network Interface is always ON
	/** KUMAR VARIABLES **/
	
	/** MOBILE DEVICES VARIABLES **/
	private int mobDevID;
    //private int cpuCores = 0;
	private double lambda;	

	private HttpClient httpclient = HttpClients.createDefault();

	private Vector<String> imagesPath = null;
	long imagePixels = 0;	
	private double elabTimePerPixel = 0.002780;
	/** MOBILE DEVICES VARIABLES **/
	
	//private TestParameters testParam = TestParameters.getInstance();
	private MobileDataCollector dataColl = MobileDataCollector.getInstance();
	
	/** SIMULATION VARIABLES **/
	private long simulationTime = //10000 * /** SECONDI **/
								  //5 * 60 *
								  7400 * 
								  1000 /** MILLI-SECONDI**/;
	private Date start = null, finish = null, globalStart = null;;
	/** SIMULATION VARIABLES **/
	
	MobileDevice(int id, Vector<String> images, double lambdaDev) {
		this.mobDevID = id;
		//this.cpuCores = cores;
		this.debug = "\t\t" + "MobDev #" + mobDevID + " - ";
		this.imagesPath = images;
		this.lambda = lambdaDev;
	}
	
	public void run() {
		globalStart = new Date();
		while(batteryCapacity > 0) {
			start = new Date();
			
			// Generate the next random interval to wait before next HTTP Request
			double delay = poissonRandomInterarrivalDelay(lambda);
			long delayMilliSec = (long) (delay * 1000);
			
			System.out.println(debug + "(simulationTime - delayMilliSec) = " + 
									   "(" + simulationTime + " - " + delayMilliSec + ") = " +
									   	(simulationTime - delayMilliSec) );
			if( (simulationTime - delayMilliSec) < 0)
				break;
			
			System.out.println(debug + "Waiting (" + (delayMilliSec / 1000) + " sec.) the next event...\n");
			try {
				Thread.sleep(delayMilliSec);
			} catch (InterruptedException e) { e.printStackTrace(); }
			System.out.println(debug + "OK, I take a image to elaborate...");
			
			// Seleziono in modo casuale un'immagine tra quelle disponibili
			String currentImagePath = imagesPath.get(generateRandomInt(0, 13));
			File currentImage = new File(currentImagePath);

			BufferedImage bufferImage;
			try {
				bufferImage = ImageIO.read(currentImage);
				imagePixels = bufferImage.getWidth() * bufferImage.getHeight();
			} catch (IOException e) { e.printStackTrace(); }

			/** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** *****
			 *  						Formula di Kumar							  *
			 * 			c = C/M * (Wm - Wi/F) - Woff * D / transmissionRate - Eon	  *
			 *  ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** *****
			 *	(C / M) è dimensionalmente un tempo, poiché C sono cicli di clock e M è la frequenza della CPU,
			 *	quindi (C / M) rappresenta il tempo che impiego per elaborare l'immagine.
			 *	**/
			
			double myElabTime = (imagePixels * elabTimePerPixel); 	// [Milli-Sec]
			
			double F = 0;
			try {
				// [Number] ==> Speed-Up = T_mobile / (T_cloud + AvgWaitingTimeCloud)
				F = speedUpRequest(imagePixels, myElabTime);
			} catch (IOException | ParseException e1) { e1.printStackTrace(); }
			
			double c = 0;
			// [W] ==> Average power consumed to execute jobs on the mobile device
			double Wm = WmFixed + generateRandomDouble(0.1, 0.4);
			// [Bytes] ==> Input Data size (Bytes)
			double D = currentImage.length();
			
			boolean lancioMoneta = false;
			if( Double.isNaN(F) ) {
				System.out.println(debug + "SpeedUp isNan(..)!! - No info on SpeedUp!! Force LOCALE execution.");
				c = -1;
			} else {
				if( F == 0 ) {
					System.out.println(debug + "SpeedUp is Zero!! No information about cloud...");
					lancioMoneta = true;
				} else {
					System.out.println(debug + "Calculate Kumar Energy Estimation!!");
					c = (myElabTime/1000.0) * (Wm - Wi/F) - (Woff * D / transmissionRate) - Eon;
				}
			}
			
			if(lancioMoneta){
				Random rnd = new Random();
				int moneta = rnd.nextInt() % 2;
				if(moneta == 0) c = 1;
				else c = -1;
			}
			
			if( c >= 0 ) {
				// CLOUD ELABORATION
				System.out.println(debug + "Kumar result: CLOUD");
				
				try {
					makePostRequest(currentImage);
				} catch (IOException e) { e.printStackTrace(); }
				
				double transmissionTime = (double) D / transmissionRate;
				double transmissionEnergy = transmissionTime * Woff;
				
				double estimatedCloudExecutionDelay = (myElabTime / 1000) * F;
				double idleEnergy = estimatedCloudExecutionDelay * Wi;
				
				batteryCapacity -= (transmissionEnergy + idleEnergy);
			} else {
				// LOCAL ELABORATION
				System.out.println(debug + "Kumar result: LOCALE");
				
				System.out.println(debug + "Simulate LOCALE elaboration...\n");
				try {
					Thread.sleep((long) myElabTime);
				} catch (InterruptedException e) { e.printStackTrace(); }
				System.out.println(debug + "LOCALE elaboration finished!!");

				//dataColl.addExecTimeGlobal(myElabTime);
				
				double localElabEnergy = (myElabTime / 1000) * Wm;
				
				batteryCapacity -= localElabEnergy;
			}
			
			System.out.println(debug + "Remain batteryCapacity = " + batteryCapacity + "\n");
			finish = new Date();
			long elapsedTime = finish.getTime() - start.getTime();
			simulationTime -= elapsedTime;
		} // while( batteryCapacity > 0 ) {..}
		finish = new Date();
		double lifeTime = ( ( (finish.getTime() - globalStart.getTime()) / 1000.0 ) / 60.0);
		
		dataColl.addTerminatedMobDevLifeTime(lifeTime);
	} // public void run() {..}
	
	private static double poissonRandomInterarrivalDelay(double rateParam) {
	    return -( Math.log(1.0 - Math.random()) / rateParam );
	}
	
	private int generateRandomInt(int min, int max) {
        Random rand = new Random();
        int randNum = rand.nextInt((max - min) + 1) + min;
        return randNum;
	} // private int generateRandomInt(..) {..}
	
	private double generateRandomDouble(double min, double max) {
		Random r = new Random();
		double randomValue = min + (max - min) * r.nextDouble();
		return randomValue;
	} // private int generateRandomDouble(..) {..}
	
	private double speedUpRequest(long imagePixels, double elabTime) throws ClientProtocolException, IOException, ParseException {
		double speedUp = -1;
		
		String urlRequest = "http://160.78.27.66:5678/speedup/" + imagePixels + "/" + elabTime;
		
		HttpGet getSpeedUp = new HttpGet(urlRequest);
		getSpeedUp.addHeader("connection", "keep-alive");
		
		HttpResponse response;
		response = httpclient.execute(getSpeedUp);
		HttpEntity entity = response.getEntity();
		
		if (entity != null) {
			BufferedReader in = new BufferedReader(new InputStreamReader(entity.getContent()));
		    try {
		    	String inputLine, totalResponse = "";
		    	while ((inputLine = in.readLine()) != null) {
		    		totalResponse += inputLine;
		    	}
//		    	System.out.println(totalResponse);
		    	JSONParser jsonParser = new JSONParser();
		    	JSONObject jsonResponse = (JSONObject) jsonParser.parse(totalResponse);
		    	
		    	speedUp = Double.parseDouble((String) jsonResponse.get("speedUp"));
		    	System.out.println(debug + "speedUpRequest(..) {..} = " + speedUp);
		    } finally { in.close(); }   
		} else {
			System.err.println(debug + "entity == null");
		}
		
		return speedUp;
	} // private double speedUpRequest(..) {..}

	private void makePostRequest(File image) throws ClientProtocolException, IOException {
		HttpPost httppost = new HttpPost("http://160.78.27.66:5678/images");
		httppost.addHeader("connection", "keep-alive");
		
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("image", image);
		
		HttpEntity content = builder.build();
		httppost.setEntity(content);
		HttpResponse response;
		
		System.out.println(debug + "makePostRequest(..) {..} - execute.(httppost)\n");
		response = httpclient.execute(httppost);
		HttpEntity entity = response.getEntity();
		
		if (entity != null) {
			System.out.println(debug + "makePostRequest(..) {..} - Response received of POST!!!");
			BufferedReader in = new BufferedReader(new InputStreamReader(entity.getContent()));
		    try {
		    	String inputLine, totalResponse = "";
		    	while ((inputLine = in.readLine()) != null) {
		    		totalResponse += inputLine;
		    	}
//		    	System.out.println(totalResponse);
		    	JSONParser jsonParser = new JSONParser();
		    	JSONObject jsonResponse = (JSONObject) jsonParser.parse(totalResponse);
		    	
		    	String photoName = (String) jsonResponse.get("name");
		    	System.out.println(debug + "makePostRequest(..) {..} - name:\"" + photoName + "\"");
		    	DeletePhoto delPhoto = new DeletePhoto(photoName);
		    	delPhoto.start();
		    	
		    	double elaborationTime = Double.parseDouble((String) jsonResponse.get("elaboration_time"));
		    	double queueingTime = Double.parseDouble((String) jsonResponse.get("queueing_time"));
		    	dataColl.addExecTimeGlobal(queueingTime + elaborationTime);
		    	dataColl.addExecTimeCloud(queueingTime + elaborationTime);
		    	dataColl.addSlowdown(queueingTime, elaborationTime);
		    } catch (ParseException e) {
				e.printStackTrace();
			} finally { in.close(); }   
		} else {
			System.err.println(debug + "makePostRequest(..) {..} - Empty Response!! ERROR!!");
		}
	} // private void makePostRequest(..) {..}
	
} // public class MobileDevice extends Thread {..}
