package it.unipr.dsg.matrix;

import Jama.Matrix;

/**
 * Class containing the model of the cloud system used in the optimal control.<br><br>
 * The model of the system is of the type:<br><br>
 * x(k+1) = A*x(k) + B*u(k) + P*w(k)<br>
 * w(k+1) = S*w(k)<br>
 * y(k+1) = C*x(k) + D*w(k)<br>
 * <br>
 * In our particular case (x(k) = [p(k) r(k)]):<br><br>
 * p(k+1) = p(k) + u(k)<br>
 * r(k+1) = (-T/Te)*x(k) + r(k) + eta(k)<br>
 * eta(k+1) = eta(k)<br>
 * y(k) = r(k)<br>
 * <br>
 * 
 * {@link CloudSystem} uses {@link DsgMatrixUtils} and the <a href="http://math.nist.gov/javanumerics/jama/">JAMA</a> library. 
 * 
 * @author Valter Venusti - December 2015
 */

public class CloudSystem {

	/**
	 * The sampling time in seconds (e.g. 300 means sampling every 300 seconds)
	 */
	private double T;
	/**
	 * The execution time of a task on the cloud
	 */
	private double Te;
	/**
	 * Weight associated to an active Virtual Machine in the system
	 */
	private double alpha;
	/**
	 * Weight associated to a request not yet served
	 */
	private double beta;
	/**
	 * Weight associated to the allocation or deallocation of a new Virtual Machine
	 */
	private double gamma;
	/**
	 * Weight associated to the number of physical active servers
	 */
	private double delta;
	/**
	 * Max Virtual Machine for server
	 */
	private double M;
	
	/**
	 * Default constructor.
	 */
	public CloudSystem(){
		this.T = this.Te = this.M = this.alpha = this.beta = this.delta = this.gamma = 0;
	}
	
	/**
	 * Construct a new model of the cloud through the parameters passed in the function.<br><br>
	 * In particular alpha, beta, gamma, delta, M are weight of the cost function:<br>
	 * J = sum(i=0 to infinite){alpha*p<sub>i</sub><sup>2</sup>+beta*r<sub>i</sub><sup>2</sup>+gamma*u<sub>i</sub><sup>2</sup>
	 * +(delta/M<sup>2</sup>)*p<sub>i</sub><sup>2</sup>}
	 * <br><br>
	 * where:<br>
	 * <ul>
	 * <li>p is the number of active processes
	 * <li>r is the number of requests not yet served
	 * <li>u is the control 
	 * </ul>
	 * 
	 * @param T - the sampling time in seconds (e.g. T=300 means a sampling time of 300 seconds)
	 * @param Te - the execution time of a task in the cloud
	 * @param alpha - weight associated to an active Virtual Machine in the system
	 * @param beta - weight associated to a request not yet served
	 * @param gamma - weight associated to the allocation or deallocation of a new Virtual Machine
	 * @param delta - weight associated to the number of physical active servers
	 * @param M - max number of Virtual Machine for server
	 */
	public CloudSystem(double T, double Te, double alpha, double beta, double gamma, double delta, double M){
		
		setT(T);
		setTe(Te);
		setM(M);
		setAlpha(alpha);
		setBeta(beta);
		setGamma(gamma);
		setDelta(delta);
	}

	public double getT() {
		return T;
	}

	public void setT(double t) {
		T = t;
	}

	public double getTe() {
		return Te;
	}

	public double setTe(double te) {
		Te = te;
		return te;
	}

	public double getAlpha() {
		return alpha;
	}

	public double setAlpha(double alpha) {
		this.alpha = alpha;
		return alpha;
	}

	public double getBeta() {
		return beta;
	}

	public double setBeta(double beta) {
		this.beta = beta;
		return beta;
	}

	public double getGamma() {
		return gamma;
	}

	public double setGamma(double gamma) {
		this.gamma = gamma;
		return gamma;
	}

	public double getDelta() {
		return delta;
	}

	public double setDelta(double delta) {
		this.delta = delta;
		return delta;
	}

	public double getM() {
		return M;
	}

	public double setM(double m) {
		M = m;
		return m;
	}

	/**
	 * Construct and return the state matrix A
	 * 
	 * @return the state matrix A
	 * @throws ArithmeticException - in case of division by zero
	 */
	public Matrix getA() throws ArithmeticException{
		/*
		 * A = [  1      0
		 * 		-T/Te    1]
		 */
		
		if(getTe() == 0) throw new ArithmeticException("Division by zero. 'Te' is zero...");
		
		double[][] A = new double[2][2];
		A[0][0] = 1;      
		A[0][1] = 0;
		A[1][0] = -getT()/getTe();  
		A[1][1] = 1;
		
		return new Matrix(A);
	}
	
	/**
	 * Construct and return the input matrix B
	 * 
	 * @return the input matrix B
	 */
	public Matrix getB(){
		/*
		 * B = [  1  
		 *  	  0  ]
		 */
		double[][] B = new double[2][1];
		B[0][0] = 1;
		B[1][0] = 0;
		
		return new Matrix(B);
	}
	
	/**
	 * Construct and return the weight matrix Q
	 * 
	 * @return the weight matrix Q
	 * @throws ArithmeticException - in case of division by zero
	 */
	public Matrix getQ() throws ArithmeticException{
		
		/*
		 * Q = [ alpha+(delta/M^2)      0
		 * 		      0               beta]
		 */
		
		if(getM() == 0) throw new ArithmeticException("Division by zero. 'M' is zero...");
		
		double[][] Q = new double[2][2];
		Q[0][0] = getAlpha()+(getDelta()/(getM()*getM()));
		Q[0][1] = 0;
		Q[1][0] = 0;
		Q[1][1] = getBeta();
		
		return new Matrix(Q);		
	}
	
	/**
	 * Construct and return the weight matrix R
	 * 
	 * @return the weight matrix R
	 */
	public Matrix getR(){
		
		/*
		 * R = [  gamma  ]
		 */
		double[][] R = new double[1][1];
		R[0][0] = getGamma();
		
		return new Matrix(R);
	}
	
	/**
	 * Construct and return the exosystem matrix P.<br><br>
	 * The system is in the following form:<br><br>
	 * x(k+1) = A*x(k) + B*u(k) + P*w(k)<br>
	 * w(k+1) = S*w(k)
	 * 
	 * @return the matrix P
	 */
	public Matrix getPexosystem(){
		
		/*
		 * B = [  0  
		 *  	  1  ]
		 */
		double[][] P = new double[2][1];
		P[0][0] = 0;
		P[1][0] = 1;
		
		return new Matrix(P);
	}
	
	/**
	 * Construct and return the control matrix Pigreco resulting from the resolution of the Francis-Byrnes-Isidori equations.<br><br>
	 * The optimal control for a system in the form:<br><br>
	 * x(k+1) = A*x(k) + B*u(k) + P*w(k)<br>
	 * w(k+1) = S*w(k)<br>
	 * y(k) = C*x(k) + D*w(k)<br>
	 * <br>
	 * is u(k) = -K(x(k) - Pigreco*w(k)) + Lambda*w(k)<br>
	 * <br>
	 * where Pigreco and Lambda satisfies:<br><br>
	 * C*Pigreco + D = 0<br>
	 * Pigreco*S = A*Pigreco + B*Lambda + P
	 * 
	 * @return the matrix Pigreco
	 * @throws ArithmeticException - in case of division by zero
	 */
	public Matrix getPigreco() throws ArithmeticException{
		
		/*
		 * Pigreco = [  Te/T  
		 *  	         0   ]
		 */
		if(getT() == 0) throw new ArithmeticException("Division by zero. 'T' is zero...");
		
		double[][] P = new double[2][1];
		P[0][0] = Te/T;
		P[1][0] = 0;
		
		return new Matrix(P);
	}
	
	/**
	 * Construct and return the control matrix Lambda {@link #getPigreco()}
	 * 
	 * @return the matrix Lambda
	 */
	public Matrix getLambda(){
		
		/*
		 * Lambda = [ 0 ]
		 */
		double[][] L = new double[1][1];
		L[0][0] = 0;
		
		return new Matrix(L);		
	}
	
	/**
	 * Calculates, using {@link DsgMatrixUtils} dlqr method, the optimal control resulting from the resolution
	 * of the Riccati equation.<br>
	 * The optimal control is u(k) = -K*x(k)
	 * 
	 * @return the gain matrix K
	 * @throws ArithmeticException - in case of division by zero
	 * 
	 * @see <a href='https://en.wikipedia.org/wiki/Riccati_equation'>Riccati equation</a>
	 */
	public Matrix getDlqrGainMatrix() throws ArithmeticException{
		
//		return DsgMatrixUtils.dlqr(getA(), getB(), getQ(), getR()).get("K");
		return DsgMatrixUtils.dlqrPython(T, Te, alpha, beta, gamma, delta, M);
	}
	
	/**
	 * Computes a new state of the system starting from the old state and the requests currently in the system.<br>
	 * The optimal control is calculated with the Francis equations ({@link #getPigreco()}).
	 * 
	 * @param oldState the old state (in matrix form)
	 * @param newRequests the number of the new requests arrived in the system (in matrix form)
	 * @return the next state (in matrix form)
	 * @throws ArithmeticException - in case of division by zero
	 */
	public Matrix nextState(Matrix oldState, Matrix newRequests) throws ArithmeticException{
		
		Matrix K = getDlqrGainMatrix();
		if(K != null){
			return DsgMatrixUtils.francisRegulatorFeedback(getA(), getB(), K, oldState, 
					newRequests, getPigreco(), getLambda(), getPexosystem());
		}else{
			return null;
		}
	}
	

}
