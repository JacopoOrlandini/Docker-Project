package it.unipr.dsg.log;

import java.util.Vector;

/**
 * Utility Singleton class used for collecting some data and return them in a
 * printable format.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 *
 */
public class DataCollector {

	/** SINGLETON STUFF **/
	private static DataCollector instance = null;

	private DataCollector() {
	}

	public static synchronized DataCollector getInstance() {
		if (instance == null)
			instance = new DataCollector();
		return instance;
	} // getInstance() {..}

	/** SINGLETON STUFF **/

	/** GLOBAL VARIABLES **/

	// Dispatcher To VM Communication Time
	private Vector<Double> dispatcherToVM = new Vector<Double>();
	private Vector<Double> dispatcherToVMAvg = new Vector<Double>();
	private Vector<Double> dispatcherToVMStdDev = new Vector<Double>();

	// Dispatching Time
	private Vector<Double> dispatchingTime = new Vector<Double>();

	// Vm To ResponseHandlerThread Communication Time
	private Vector<Double> VMToRespHandThread = new Vector<Double>();
	private Vector<Double> VMToRespHandThreadAvg = new Vector<Double>();
	private Vector<Double> VMToRespHandThreadStdDev = new Vector<Double>();

	// Node.JS to Request Handler Thread Communication Time
	private Vector<Double> NodeJSToReqHandThread = new Vector<Double>();
	private Vector<Double> NodeJSToReqHandThreadAvg = new Vector<Double>();
	private Vector<Double> NodeJSToReqHandThreadStdDev = new Vector<Double>();

	// VM Allocation Time
	private Vector<Double> VMAllocationTime = new Vector<Double>();
	private Vector<Double> VMAllocationTimeAvg = new Vector<Double>();
	private Vector<Double> VMAllocationTimeStdDev = new Vector<Double>();

	// VM DeAllocation Time
	private Vector<Double> VMDeAllocationTime = new Vector<Double>();
	private Vector<Double> VMDeAllocationTimeAvg = new Vector<Double>();
	private Vector<Double> VMDeAllocationTimeStdDev = new Vector<Double>();

	// set point (ratio_tc = currentStationingTime / windowedAvgTimeOnCloud)
	// Value
	private Vector<Double> setPointValue = new Vector<Double>();

	private Vector<Double> controllerResult = new Vector<Double>();
	private Vector<Double> processes = new Vector<Double>();
	private Vector<Double> activeProcesses = new Vector<Double>();
	private Vector<Double> requests = new Vector<Double>();

	private Vector<Double> controllerGain = new Vector<Double>();
	private Vector<Double> controllerGainNum = new Vector<Double>();
	private Vector<Double> controllerGainDen = new Vector<Double>();

	private Vector<Double> Te = new Vector<Double>();
	private Vector<Double> requestsPerSample = new Vector<Double>();

	private Vector<Double> openstackMetricMeasurement = new Vector<Double>();

	private Vector<String> quadThresholdScalingDecisions = new Vector<String>();

	private Vector<String> debugController = new Vector<String>();
	private Vector<String> debugVirtualMachineCreator = new Vector<String>();

	// MPC Controller evaluation time
	private Vector<Double> mpcEvaluationTime = new Vector<Double>();
	// MPC Controller objective function values (Cost function)
	private Vector<Double> mpcObjectiveFunction = new Vector<Double>();

	// variables needed for the cost function compute
	private int p = 0;
	private double r = 0;

	/** GLOBAL VARIABLES **/

	/** PUBLIC FUNCTIONS **/
	public void collectNewData() {
		// Compute Average Dispatcher to VM
		this.computeNewAvgAndStdDev(this.dispatcherToVM, this.dispatcherToVMAvg, this.dispatcherToVMStdDev);

		// Compute Average VM to ResponseHandlerThred
		this.computeNewAvgAndStdDev(this.VMToRespHandThread, this.VMToRespHandThreadAvg, this.VMToRespHandThreadStdDev);

		this.computeNewAvgAndStdDev(this.NodeJSToReqHandThread, this.NodeJSToReqHandThreadAvg,
				this.NodeJSToReqHandThreadStdDev);

		this.computeNewAvgAndStdDev(this.VMAllocationTime, this.VMAllocationTimeAvg, this.VMAllocationTimeStdDev);

		this.computeNewAvgAndStdDev(this.VMDeAllocationTime, this.VMDeAllocationTimeAvg, this.VMDeAllocationTimeStdDev);
	}

	public void addControllerString(String string) {
		synchronized (this.debugController) {
			this.debugController.add(string);
		}
	}

	public void addVirtualMachineCreatorString(String string) {
		synchronized (this.debugVirtualMachineCreator) {
			this.debugVirtualMachineCreator.add(string);
		}
	}

	public void addDispatcherToVMTime(double communicationTime) {
		synchronized (this.dispatcherToVM) {
			this.dispatcherToVM.add(communicationTime);
		}
	}

	public void addNodeJStoReqHandThreadTime(double communicationTime) {
		synchronized (this.NodeJSToReqHandThread) {
			this.NodeJSToReqHandThread.add(communicationTime);
		}
	}

	public void addDispatchingTime(double time) {
		synchronized (this.dispatchingTime) {
			this.dispatchingTime.add(time);
		}
	}

	public void addVMToRespHandThreadTime(double communicationTime) {
		synchronized (this.VMToRespHandThread) {
			this.VMToRespHandThread.add(communicationTime);
		}
	}

	public void addVMAllocationTime(double allocationTime) {
		synchronized (this.VMAllocationTime) {
			this.VMAllocationTime.add(allocationTime);
		}
	}

	public void addVMDeAllocationTime(double deallocationTime) {
		synchronized (this.VMDeAllocationTime) {
			this.VMDeAllocationTime.add(deallocationTime);
		}
	}

	public void addSetPointValue(double phi) {
		synchronized (this.setPointValue) {
			this.setPointValue.add(phi);
		}
	}

	public void addOpenStackMetricMeasurementValue(double value) {
		synchronized (this.openstackMetricMeasurement) {
			this.openstackMetricMeasurement.add(value);
		}
	}

	public void addControllerGainValue(double value) {
		synchronized (this.controllerGain) {
			this.controllerGain.add(value);
		}
	}

	public void addTeValue(double value) {
		synchronized (this.Te) {
			this.Te.add(value);
		}
	}

	public void addRequestsPerSample(double value) {
		synchronized (this.requestsPerSample) {
			this.requestsPerSample.add(value);
		}
	}

	public void addControllerGainNumValue(double value) {
		synchronized (this.controllerGainNum) {
			this.controllerGainNum.add(value);
		}
	}

	public void addControllerGainDenValue(double value) {
		synchronized (this.controllerGainDen) {
			this.controllerGainDen.add(value);
		}
	}

	public void addControllerResult(double result) {
		synchronized (this.controllerResult) {
			this.controllerResult.add(result);
		}
	}

	public void addProcesses(double result) {
		synchronized (this.processes) {
			this.processes.add(result);
		}
	}

	public void addActiveProcesses(double result) {
		synchronized (this.activeProcesses) {
			this.activeProcesses.add(result);
		}
	}

	public void addRequests(double result) {
		synchronized (this.requests) {
			this.requests.add(result);
		}
	}

	public void addQuadThresholdScalingDecisions(String s) {
		synchronized (this.quadThresholdScalingDecisions) {
			this.quadThresholdScalingDecisions.add(s);
		}
	}

	public void addMPCEvaluationTime(double result) {
		synchronized (this.mpcEvaluationTime) {
			this.mpcEvaluationTime.add(result);
		}
	}

	public void addMPCObjectiveFunction(double result) {
		synchronized (this.mpcObjectiveFunction) {
			this.mpcObjectiveFunction.add(result);
		}
	}

	public void addP(int p) {
		this.p = p;
	}

	public void addR(double r) {
		this.r = r;
	}

	/** ** ADD .. VALUE ** **/

	/** ** GET ... PRINTABLE DATA ** **/

	public String getDebugControllerPrintableData() {
		synchronized (this.debugController) {
			String result = "";
			for (int i = 0; i < this.debugController.size(); i++)
				result += this.debugController.get(i) + "\n";
			return result;
		}
	}

	public String getDebugVirtualMachineCreatorPrintableData() {
		synchronized (this.debugVirtualMachineCreator) {
			String result = "";
			for (int i = 0; i < this.debugVirtualMachineCreator.size(); i++)
				result += this.debugVirtualMachineCreator.get(i) + "\n";
			return result;
		}
	}

	public String getDispatcherToVMPrintableData() {
		synchronized (this.dispatcherToVM) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for (int i = 0; i < this.dispatcherToVMAvg.size(); i++)
				result += (i + 1) + "\t" + this.dispatcherToVMAvg.get(i) + "\t" + this.dispatcherToVMStdDev.get(i)
						+ "\n";
			return result;
		}
	}

	public String getVMAllocationPrintableData() {
		synchronized (this.VMAllocationTime) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for (int i = 0; i < this.VMAllocationTimeAvg.size(); i++)
				result += (i + 1) + "\t" + this.VMAllocationTimeAvg.get(i) + "\t" + this.VMAllocationTimeStdDev.get(i)
						+ "\n";
			return result;
		}
	}

	public String getVMDeAllocationPrintableData() {
		synchronized (this.VMDeAllocationTime) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for (int i = 0; i < this.VMDeAllocationTimeAvg.size(); i++)
				result += (i + 1) + "\t" + this.VMDeAllocationTimeAvg.get(i) + "\t"
						+ this.VMDeAllocationTimeStdDev.get(i) + "\n";
			return result;
		}
	}

	public String getDispatchingTimePrintableData() {
		synchronized (this.dispatchingTime) {
			String result = "";
			result += "1 / (Mean Dispatching Time)\n";
			double sum = 0;
			for (Double d : this.dispatchingTime)
				sum += d;
			double avg = sum / (double) this.dispatchingTime.size();
			double uD = 1.0 / avg;
			result += "0\t" + uD + "\n";
			return result;
		}
	}

	public String getVMToRespHandThreadPrintableData() {
		synchronized (this.VMToRespHandThread) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for (int i = 0; i < this.VMToRespHandThreadAvg.size(); i++)
				result += (i + 1) + "\t" + this.VMToRespHandThreadAvg.get(i) + "\t"
						+ this.VMToRespHandThreadStdDev.get(i) + "\n";
			return result;
		}
	}

	public String getNodeJSToReqHandThreadPrintableData() {
		synchronized (this.NodeJSToReqHandThread) {
			String result = "";
			result += "TIME\tAVG\tSTD_DEV\n";
			for (int i = 0; i < this.NodeJSToReqHandThreadAvg.size(); i++)
				result += (i + 1) + "\t" + this.NodeJSToReqHandThreadAvg.get(i) + "\t"
						+ this.NodeJSToReqHandThreadStdDev.get(i) + "\n";
			return result;
		}
	}

	public String getSetPointValuePrintableData() {
		synchronized (this.setPointValue) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.setPointValue.size(); i++)
				result += (i + 1) + "\t" + this.setPointValue.get(i) + "\n";
			return result;
		}
	}

	public String getTeValuePrintableData() {
		synchronized (this.Te) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.Te.size(); i++)
				result += (i + 1) + "\t" + this.Te.get(i) + "\n";
			return result;
		}
	}

	public String getRequestsPerSamplePrintableData() {
		synchronized (this.Te) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.requestsPerSample.size(); i++)
				result += (i + 1) + "\t" + this.requestsPerSample.get(i) + "\n";
			return result;
		}
	}

	public String getControllerResultPrintableData() {
		synchronized (this.controllerResult) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.controllerResult.size(); i++)
				result += (i + 1) + "\t" + this.controllerResult.get(i) + "\n";
			return result;
		}
	}

	public String getControllerGainPrintableData() {
		synchronized (this.controllerGain) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.controllerGain.size(); i++)
				result += (i + 1) + "\t" + this.controllerGain.get(i) + "\n";
			return result;
		}
	}

	public String getControllerGainNumPrintableData() {
		synchronized (this.controllerGainNum) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.controllerGainNum.size(); i++)
				result += (i + 1) + "\t" + this.controllerGainNum.get(i) + "\n";
			return result;
		}
	}

	public String getControllerGainDenPrintableData() {
		synchronized (this.controllerGainDen) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.controllerGainDen.size(); i++)
				result += (i + 1) + "\t" + this.controllerGainDen.get(i) + "\n";
			return result;
		}
	}

	public String getOpenStackMatricMeasurementPrintableData() {
		synchronized (this.openstackMetricMeasurement) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.openstackMetricMeasurement.size(); i++)
				result += (i + 1) + "\t" + this.openstackMetricMeasurement.get(i) + "\n";
			return result;
		}
	}

	public String getProcessesPrintableData() {
		synchronized (this.processes) {
			String result = "";
			result += "TIME\tVALUE\n";
			result += "0\t1.0\n";
			for (int i = 0; i < this.processes.size(); i++)
				result += (i + 1) + "\t" + this.processes.get(i) + "\n";
			return result;
		}
	}

	public String getActiveProcessesPrintableData() {
		synchronized (this.activeProcesses) {
			String result = "";
			result += "TIME\tVALUE\n";
			result += "0\t1.0\n";
			for (int i = 0; i < this.activeProcesses.size(); i++)
				result += (i + 1) + "\t" + this.activeProcesses.get(i) + "\n";
			return result;
		}
	}

	public String getRequestsPrintableData() {
		synchronized (this.requests) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.requests.size(); i++)
				result += (i + 1) + "\t" + this.requests.get(i) + "\n";
			return result;
		}
	}

	public String getQuadThresholdScalingDecisionsPrintableData() {
		synchronized (this.quadThresholdScalingDecisions) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.quadThresholdScalingDecisions.size(); i++)
				result += (i + 1) + "\t" + this.quadThresholdScalingDecisions.get(i) + "\n";
			return result;
		}
	}

	public String getMPCEvaluationTimePrintableData() {
		synchronized (this.mpcEvaluationTime) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.mpcEvaluationTime.size(); i++)
				result += (i + 1) + "\t" + this.mpcEvaluationTime.get(i) + "\n";
			return result;
		}
	}

	public String getCostFunctionPrintableData() {
		synchronized (this.mpcObjectiveFunction) {
			String result = "";
			result += "TIME\tVALUE\n";
			for (int i = 0; i < this.mpcObjectiveFunction.size(); i++)
				result += (i + 1) + "\t" + this.mpcObjectiveFunction.get(i) + "\n";
			return result;
		}
	}

	public void resetAllVariables() {

		this.dispatcherToVM.clear();
		this.dispatcherToVMAvg.clear();
		this.dispatcherToVMStdDev.clear();

		this.dispatchingTime.clear();

		this.VMToRespHandThread.clear();
		this.VMToRespHandThreadAvg.clear();
		this.VMToRespHandThreadStdDev.clear();

		this.NodeJSToReqHandThread.clear();
		this.NodeJSToReqHandThreadAvg.clear();
		this.NodeJSToReqHandThreadStdDev.clear();

		this.VMAllocationTime.clear();
		this.VMAllocationTimeAvg.clear();
		this.VMAllocationTimeStdDev.clear();

		this.VMDeAllocationTime.clear();
		this.VMDeAllocationTimeAvg.clear();
		this.VMDeAllocationTimeStdDev.clear();

		this.setPointValue.clear();

		this.controllerResult.clear();
		this.processes.clear();
		this.activeProcesses.clear();
		this.requests.clear();

		this.controllerGain.clear();
		this.controllerGainNum.clear();
		this.controllerGainDen.clear();

		this.Te.clear();
		this.requestsPerSample.clear();
		this.openstackMetricMeasurement.clear();

		this.quadThresholdScalingDecisions.clear();
		this.debugController.clear();
		this.debugVirtualMachineCreator.clear();

		this.mpcEvaluationTime.clear();
		this.mpcObjectiveFunction.clear();
	}

	/**
	 * Compute the cost function (Ju) value as defined in
	 * {@code ModelPredictiveController} class
	 */
	public double computeMPCCostFunction(int u) {
		double a = TestParameters.getInstance().getAlphaMPC();
		double b = TestParameters.getInstance().getBetaMPC();
		double g = TestParameters.getInstance().getGammaMPC();
		double d = TestParameters.getInstance().getDeltaMPC();
		double M = TestParameters.getInstance().getMMPC();

		int p = getP();
		double r = getR();

		double Ju = 0;

		Ju = a * Math.pow(p, 2) + b * Math.pow(Math.ceil(r), 2) + g * Math.pow(u, 2)
				+ d * Math.pow(Math.ceil(p) / M, 2);

		System.out.println("\nCOST FUNCTION VALUE  --> " + Ju);
		return Ju;
	}

	/** PUBLIC FUNCTIONS **/
	//
	// /** PRIVATE FUNCTIONS **/
	//// private void deleteOldWindowedTimeOnCloud(int windowInMilliseconds){
	//// synchronized(this.windowedTimeOnCloud){
	//// Date date = new Date(new Date().getTime() - windowInMilliseconds);
	//// for(Iterator<Entry<Date, Double>> it =
	// this.windowedTimeOnCloud.entrySet().iterator();
	//// it.hasNext(); ){
	////
	//// Entry<Date, Double> entry = it.next();
	////
	//// if(entry.getKey().before(date)){
	//// it.remove();
	//// }
	//// }
	//// }
	//// }

	private int getP() {
		return this.p;
	}

	private double getR() {
		return this.r;
	}

	private void computeNewAvgAndStdDev(Vector<Double> dataVector, Vector<Double> avgVector,
			Vector<Double> stdDevVector) {
		synchronized (dataVector) {
			double avgValue = computeAvgOfVector(dataVector);
			avgVector.add(avgValue);
			stdDevVector.add(computeStdDevOfVector(dataVector, avgValue));
		}
	}

	/** ** MEAN AND STD-DEV FUNCTION ** **/
	private double computeAvgOfVector(Vector<Double> vector) {
		synchronized (vector) {
			double sum = 0;
			for (Double d : vector)
				sum += d;
			double mean = sum / (double) vector.size();
			return mean;
		}
	}

	private double computeStdDevOfVector(Vector<Double> vector, double mean) {
		synchronized (vector) {
			double sum = 0;
			for (Double value : vector)
				sum += Math.pow((value - mean), 2);
			double stdDev = Math.sqrt(sum / (double) vector.size());
			return stdDev;
		}
	}
	/** ** MEAN AND STD-DEV FUNCTION ** **/
	/** PRIVATE FUNCTIONS **/
}
