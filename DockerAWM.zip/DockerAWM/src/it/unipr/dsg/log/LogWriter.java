package it.unipr.dsg.log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import it.unipr.dsg.awm.controller.QoSModeler;
//import it.unipr.dsg.clientsimulation.hcs.HttpClientDataCollector;

/**
 * Utility Singleton class used to write log files.
 * 
 * @author Marco Magnani - March 2015
 * @author Valter Venusti - December 2015
 * @author Federico Torreggiani
 *
 */
public class LogWriter {
	/** SINGLETON STUFF **/
	private static LogWriter instance = null;

	private LogWriter() {
	}

	public static synchronized LogWriter getInstance() {
		if (instance == null)
			instance = new LogWriter();
		return instance;
	} // getInstance() {..}

	/** SINGLETON STUFF **/

	/** STRING PATH **/
	private String baseClusterPath = "/opt/CloudAWM/GraphData/";

	//
	private String dispatcherToVMPath = baseClusterPath + "dispatcherToVMCommTime";
	private String dispatchingTimePath = baseClusterPath + "dispatchingTime";
	private String VMToRespHandThreadPath = baseClusterPath + "VMToRespHandThreadCommTime";
	private String NodeJSToReqHandThreadPath = baseClusterPath + "NodeJSToReqHandThreadCommTime";
	private String setPointValuePath = baseClusterPath + "setPointValue";

	private String testParameterPath = baseClusterPath + "testParameters.dat";
	// private String executionCountersPath = baseClusterPath +
	// "processInterarrivals";
	private String timeOnCloudPath = baseClusterPath + "timeOnCloud";
	private String controllerResultPath = baseClusterPath + "controllerResult";
	private String processesPath = baseClusterPath + "processes";
	private String activeProcessesPath = baseClusterPath + "activeProcesses";
	private String requestsPath = baseClusterPath + "requests";
	private String VMAllocationPath = baseClusterPath + "VMAllocation";
	private String VMDeAllocationPath = baseClusterPath + "VMDeAllocation";
	// private String executionTimePath = baseClusterPath + "executionTime";
	// private String queueTimePath = baseClusterPath + "queueTime";

	private String controllerGainPath = baseClusterPath + "controllerGain";
	private String controllerGainNumPath = baseClusterPath + "controllerGainNum";
	private String controllerGainDenPath = baseClusterPath + "controllerGainDen";
	private String TeValuePath = baseClusterPath + "TeValue";
	private String requestsPerSampleValuePath = baseClusterPath + "RequestsPerSample";

	private String openStackMetricPath = baseClusterPath + "openStackMetric";
	private String quadThresholdScalingDecisions = baseClusterPath + "quadThresholdScalingDecisions";
	private String executionTimeCloudAWMPath = baseClusterPath + "executionTimeCloudAWM";

	private String timeOnCloudFaceDetectionPath = baseClusterPath + "timeOnCloudFaceDetection";
	private String timeOnCloudInverseMatrixPath = baseClusterPath + "timeOnCloudInverseMatrix";
	private String timeOnCloudFaceDetectionAllPath = baseClusterPath + "timeOnCloudFaceDetectionAll";
	private String timeOnCloudInverseMatrixAllPath = baseClusterPath + "timeOnCloudInverseMatrixAll";

	private String debugControllerPath = baseClusterPath + "debugController";
	private String debugVirtualMachineCreator = baseClusterPath + "debugVirtualMachineCreator";

	private String MPCEvaluationTime = baseClusterPath + "MPCEvaluationTime";
	private String MPCObjectiveFunction = baseClusterPath + "MPCObjectiveFunction";
	/** STRING PATH **/

	/** GLOBAL VARIABLES **/
	private String debug = "LOG WRITER - ";
	private int counterLogFile = 0;

	private DataCollector dataColl = DataCollector.getInstance();
	private TestParameters testParam = TestParameters.getInstance();
	// private HttpClientDataCollector hcsDataColl =
	// HttpClientDataCollector.getInstance();
	private QoSModeler qos = QoSModeler.getInstance();

	/** GLOBAL VARIABLES **/

	/** PUBLIC FUNCTIONS **/
	public void writeLogFile() {
		this.counterLogFile++;

		this.writeSetPointValueLogFile();

		// this.writeExecutionCounters();
		this.writeTimeOnCloud();
		this.writeControllerResultValueLogFile();
		this.writeProcessesValueLogFile();
		this.writeActiveProcessesValueLogFile();
		this.writeRequestsValueLogFile();

		this.writeDispatcherToVMTimeLogFile();
		this.writeDispatchingTimeLogFile();
		this.writeVMToRespHandlerThreadTimeLogFile();
		this.writeNodeJSToReqHandlerThreadTimeLogFile();

		this.writeVMAllocationTimeLogFile();
		this.writeVMDeAllocationTimeLogFile();

		// this.writeExecutionTimeLogFile();
		// this.writeQueueTimeLogFile();

		this.writeControllerGainValueLogFile();
		this.writeControllerGainNumValueLogFile();
		this.writeControllerGainDenValueLogFile();

		this.writeTeValueLogFile();
		this.writeOpenStackMetricLogFile();
		this.writeRequestsPerSampleValueLogFile();

		this.writeQuadThresholdScalingDecisions();
		this.writeExecutionTimeCloudAWMLogFile();

		this.writeTimeOnCloudFaceDetection();
		this.writeTimeOnCloudInverseMatrix();
		this.writeTimeOnCloudFaceDetectionAll();
		this.writeTimeOnCloudInverseMatrixAll();

		this.writeDebugControllerLogFile();
		this.writeDebugVirtualMachineCreatorLogFile();

		// write Log file for the MPC controller performance evaluation
		this.writeMPCEvaluationTime();
		this.writeMPCObjectiveFunction();
	}

	public void writeTestParameters() {
		try {
			File file = new File(this.testParameterPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = testParam.getPrintableParameters();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.testParameterPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	public void publicWriteDebugControllerLogFile() {
		String currentPath = this.debugControllerPath + "_" + this.counterLogFile + "_user.dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDebugControllerPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	public void publicWriteDebugVirtualMachineCreatorLogFile() {
		String currentPath = this.debugVirtualMachineCreator + "_" + this.counterLogFile + "_user.dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDebugVirtualMachineCreatorPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	/** PUBLIC FUNCTIONS **/

	/** PRIVATE FUNCTIONS **/
	private void writeVMToRespHandlerThreadTimeLogFile() {
		String currentPath = this.VMToRespHandThreadPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getVMToRespHandThreadPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeDebugControllerLogFile() {
		String currentPath = this.debugControllerPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDebugControllerPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeDebugVirtualMachineCreatorLogFile() {
		String currentPath = this.debugVirtualMachineCreator + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDebugVirtualMachineCreatorPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeNodeJSToReqHandlerThreadTimeLogFile() {
		String currentPath = this.NodeJSToReqHandThreadPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getNodeJSToReqHandThreadPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeVMAllocationTimeLogFile() {
		String currentPath = this.VMAllocationPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getVMAllocationPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeVMDeAllocationTimeLogFile() {
		String currentPath = this.VMDeAllocationPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getVMDeAllocationPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeOpenStackMetricLogFile() {
		String currentPath = this.openStackMetricPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getOpenStackMatricMeasurementPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	/*
	 * private void writeExecutionTimeLogFile() { String currentPath =
	 * this.executionTimePath + "_" + this.counterLogFile + ".dat"; try { File
	 * file = new File(currentPath); PrintWriter writer = new PrintWriter(file);
	 * 
	 * String logData = hcsDataColl.getExecTimeRealPrintableData();
	 * 
	 * writer.println(logData); writer.flush(); writer.close(); } catch
	 * (FileNotFoundException e) { System.err.println(debug + currentPath +
	 * " --- Not Found!!"); e.printStackTrace(); } }
	 */
	/*
	 * private void writeQueueTimeLogFile() { String currentPath =
	 * this.queueTimePath + "_" + this.counterLogFile + ".dat"; try { File file
	 * = new File(currentPath); PrintWriter writer = new PrintWriter(file);
	 * 
	 * String logData = hcsDataColl.getQueueTimeRealPrintableData();
	 * 
	 * writer.println(logData); writer.flush(); writer.close(); } catch
	 * (FileNotFoundException e) { System.err.println(debug + currentPath +
	 * " --- Not Found!!"); e.printStackTrace(); } }
	 */
	private void writeDispatcherToVMTimeLogFile() {
		String currentPath = dispatcherToVMPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDispatcherToVMPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeDispatchingTimeLogFile() {
		String currentPath = this.dispatchingTimePath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getDispatchingTimePrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeSetPointValueLogFile() {
		String currentPath = this.setPointValuePath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getSetPointValuePrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeControllerGainValueLogFile() {
		String currentPath = this.controllerGainPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getControllerGainPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeControllerGainNumValueLogFile() {
		String currentPath = this.controllerGainNumPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getControllerGainNumPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeControllerGainDenValueLogFile() {
		String currentPath = this.controllerGainDenPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getControllerGainDenPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeTeValueLogFile() {
		String currentPath = this.TeValuePath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getTeValuePrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeExecutionTimeCloudAWMLogFile() {
		String currentPath = this.executionTimeCloudAWMPath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getExecutionTimesPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeRequestsPerSampleValueLogFile() {
		String currentPath = this.requestsPerSampleValuePath + "_" + this.counterLogFile + ".dat";
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getRequestsPerSamplePrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeControllerResultValueLogFile() {
		String currentPath = this.controllerResultPath + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getControllerResultPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	/*
	 * private void writeExecutionCounters() { try { System.out.println(debug +
	 * "Trying to write log file..."); File file = new
	 * File(this.executionCountersPath + "_" + this.counterLogFile + ".dat");
	 * PrintWriter writer = new PrintWriter(file);
	 * 
	 * String logData = hcsDataColl.getExecutionCountersPrintableData();
	 * 
	 * writer.println(logData); writer.flush(); writer.close();
	 * System.out.println(); System.out.println(debug + "Log file written...");
	 * } catch (FileNotFoundException e) { System.err.println(debug +
	 * this.executionCountersPath + " --- Not Found!!"); e.printStackTrace(); }
	 * }
	 */
	private void writeTimeOnCloud() {
		try {
			System.out.println(debug + "Trying to write log file...");
			File file = new File(this.timeOnCloudPath + "_" + this.counterLogFile + ".dat");
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getTimeOnCloudPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
			System.out.println();
			System.out.println(debug + "Log file written...");
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.timeOnCloudPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeTimeOnCloudFaceDetection() {
		try {
			System.out.println(debug + "Trying to write log file...");
			File file = new File(this.timeOnCloudFaceDetectionPath + "_" + this.counterLogFile + ".dat");
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getTimeOnCloudFaceDetectionPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
			System.out.println();
			System.out.println(debug + "Log file written...");
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.timeOnCloudPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeTimeOnCloudInverseMatrix() {
		try {
			System.out.println(debug + "Trying to write log file...");
			File file = new File(this.timeOnCloudInverseMatrixPath + "_" + this.counterLogFile + ".dat");
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getTimeOnCloudInverseMatrixPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
			System.out.println();
			System.out.println(debug + "Log file written...");
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.timeOnCloudPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeTimeOnCloudFaceDetectionAll() {
		try {
			System.out.println(debug + "Trying to write log file...");
			File file = new File(this.timeOnCloudFaceDetectionAllPath + "_" + this.counterLogFile + ".dat");
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getAllTimeOnCloudFaceDetectionPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
			System.out.println();
			System.out.println(debug + "Log file written...");
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.timeOnCloudPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeTimeOnCloudInverseMatrixAll() {
		try {
			System.out.println(debug + "Trying to write log file...");
			File file = new File(this.timeOnCloudInverseMatrixAllPath + "_" + this.counterLogFile + ".dat");
			PrintWriter writer = new PrintWriter(file);

			String logData = qos.getAllTimeOnCloudInverseMatrixPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
			System.out.println();
			System.out.println(debug + "Log file written...");
		} catch (FileNotFoundException e) {
			System.err.println(debug + this.timeOnCloudPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeProcessesValueLogFile() {
		String currentPath = this.processesPath + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getProcessesPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeActiveProcessesValueLogFile() {
		String currentPath = this.activeProcessesPath + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getActiveProcessesPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeRequestsValueLogFile() {
		String currentPath = this.requestsPath + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getRequestsPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeQuadThresholdScalingDecisions() {
		String currentPath = this.quadThresholdScalingDecisions + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getQuadThresholdScalingDecisionsPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeMPCEvaluationTime() {
		String currentPath = this.MPCEvaluationTime + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getMPCEvaluationTimePrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	private void writeMPCObjectiveFunction() {
		String currentPath = this.MPCObjectiveFunction + "_" + this.counterLogFile + ".dat";
		;
		try {
			File file = new File(currentPath);
			PrintWriter writer = new PrintWriter(file);

			String logData = dataColl.getCostFunctionPrintableData();

			writer.println(logData);
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.println(debug + currentPath + " --- Not Found!!");
			e.printStackTrace();
		}
	}

	/** PRIVATE FUNCTIONS **/
}
