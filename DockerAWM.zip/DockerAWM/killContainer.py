import docker
import sys
client = docker.from_env()

lCl = docker.APIClient(base_url='unix://var/run/docker.sock')

lCl.kill(sys.argv[1])
