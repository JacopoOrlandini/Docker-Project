import docker as dk

client = dk.from_env()

client.images.build(path="./", tag="serverapp")
print("builded image")
