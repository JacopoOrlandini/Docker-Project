import docker as dk
import datetime
from datetime import timedelta
client = dk.from_env()

d = {"status":"running"}
containers = client.containers.list(filters=d)

avgTime = 0
# Finestra di tempo 3 minuti
WindowInMinutes = 4 * 60
sum = 0
counter = 0

new = datetime.datetime.now()
d = timedelta(seconds=(WindowInMinutes+60*60))    # fuso orario +1, devo togliere un ora
new = new-d # finestra temporale del passato

for c in containers:
    creation_date = c.attrs["Created"]
    new1 = datetime.datetime.now()
    d1 = timedelta(seconds=(60*60))    # fuso orario +1, devo togliere un ora
    new1 = new1 -d1
    old = datetime.datetime.strptime(creation_date[:-4], '%Y-%m-%dT%H:%M:%S.%f')    # da quanto e' attivo un container
    Te = new1 - old
    if old > new:
        sum += Te.seconds
        counter +=1
if counter == 0:
    print(0)
else:
    print (sum/counter)
