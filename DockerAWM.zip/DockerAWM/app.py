import sys
import os 
import socket
from flask import Flask, send_file
import time

app = Flask(__name__)


@app.route("/start_task")
def hello():
    def F(n):
        if n == 0: return 0
        elif n == 1: return 1
        else: return F(n-1)+F(n-2)
    start = time.time()
    data = []
    for i in xrange(35):
        data.append(F(i))
    html = "<b>Tempo di esecuzione totale: {name}</b>"\
           "<b>Hostname:</b> {hostname}" \
           "<b>Visits:</b> {visits}"
    return html.format(name=time.time()-start, hostname=socket.gethostname(), visits="Finished")



@app.route("/")
def main():
    return str(socket.gethostname())

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=80)
