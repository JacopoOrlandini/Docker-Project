import docker
client = docker.from_env()

lCl = docker.APIClient(base_url='unix://var/run/docker.sock')

containers = client.containers.list()

for i in containers:
    lCl.kill(str(i.id))
lCl.prune_containers()